# Disaster Management System

ResQ Command is an academic disaster response application built with Angular,
Spring Boot and MySQL. It includes registration, sign in, a dashboard, incident
management, affected people records and user profiles. Photographs are bundled
locally in frontend/public/images.

## Requirements

- Windows with PowerShell and Git
- Java JDK 17 (JAVA_HOME set to the JDK folder)
- Node.js 20 and npm
- MySQL 8 running on localhost port 3306
- Internet for the first dependency installation

## Download from the department repository

Sign in to GitHub with the account associated with your college email.
Open https://github.com/cse-department-projects/MRU-CSE-2nd-Year-Projects
and locate your team's accepted submission. Clone the repository or download
its ZIP and extract it. Open the project folder containing backend and frontend
in VS Code. Run the commands below from that project folder.

If the team's pull request is still pending, the department must confirm whether
the submitted branch is acceptable for the examination.

## Start the backend

Start the MySQL service before starting Spring Boot. In a VS Code PowerShell
terminal, configure the credentials for the MySQL installation on that computer:

```powershell
cd backend
$env:DB_USERNAME = 'root'
$env:DB_PASSWORD = Read-Host 'Enter your local MySQL password'
.\mvnw.cmd spring-boot:run
```

The API listens at http://localhost:8080. With the default configuration,
the application creates disaster_db and its tables if the MySQL user has
the required permissions. Keep this terminal running.

## Start the frontend

Open a second terminal at the project folder:

```powershell
cd frontend
npm.cmd ci
npm.cmd run dev
```

Open http://127.0.0.1:4200. Keep both terminals and MySQL running.
On later runs, npm ci is unnecessary unless dependencies have changed.

## Examination demonstration

1. Show the team's submitted code in the department GitHub repository.
2. Download or clone that submission and open its project folder.
3. Start MySQL, the backend and the frontend as described above.
4. Register a demonstration account and show the dashboard.
5. Create an incident and search/filter the incident list.
6. Add a person linked to the incident and update their safety status.
7. Show the updated dashboard, profile, and light/dark theme toggle.
8. Sign out and show the return to the landing page.

The database is local to the demonstration computer. A fresh machine starts
with its own database; GitHub does not copy existing local database records.
External Google News searches require internet access; bundled photos do not.

## Build verification

```powershell
cd frontend
npm.cmd ci
npm.cmd run build
```

In a separate terminal at the project folder:

```powershell
cd backend
.\mvnw.cmd -DskipTests package
```

## Troubleshooting

- Backend unreachable: check that Spring Boot completed startup on port 8080.
- Database access denied: check MySQL is running and DB_USERNAME/DB_PASSWORD.
- Java errors: verify java -version and JAVA_HOME point to JDK 17.
- Frontend command errors: use npm.cmd in Windows PowerShell.
- Port already in use: stop an old instance before starting a second copy.

## Academic scope

This is a demonstration project. Browser route guards and sign in screens are
not a complete production authorization system. Use demonstration data for the
exam and do not upload real affected-person records or personal credentials.
