import { Routes } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { LandingComponent } from './components/landing/landing.component';
import { PersonListComponent } from './components/person-list/person-list.component';
import { IncidentListComponent } from './components/incident-list/incident-list.component';
import { SigninComponent } from './components/auth/signin.component';
import { SignupComponent } from './components/auth/signup.component';
import { ProfileComponent } from './components/auth/profile.component';
import { ForgotPasswordComponent } from './components/auth/forgot-password.component';
import { authGuard } from './guards/auth.guard';

export const routes: Routes = [
    { path: '', component: LandingComponent },
    { path: 'dashboard', component: DashboardComponent, canActivate: [authGuard] },
    { path: 'persons', component: PersonListComponent, canActivate: [authGuard] },
    { path: 'incidents', component: IncidentListComponent, canActivate: [authGuard] },
    { path: 'signin', component: SigninComponent },
    { path: 'signup', component: SignupComponent },
    { path: 'forgot-password', component: ForgotPasswordComponent },
    { path: 'profile', component: ProfileComponent, canActivate: [authGuard] },
    { path: '**', redirectTo: '/' }
];
