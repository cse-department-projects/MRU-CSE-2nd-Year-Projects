import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationEnd, Router, RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { filter, Observable } from 'rxjs';
import { AuthService } from './services/auth.service';
import { ThemeMode, ThemeService } from './services/theme.service';
import { User } from './models/user.model';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive
  ],
  templateUrl: './app.html',   // or './app.component.html'
  styleUrls: ['./app.css']     // or './app.component.css'
})
export class AppComponent {
  title = 'Disaster Management System';
  currentUser$: Observable<User | null>;
  currentTheme$: Observable<ThemeMode>;
  menuOpen = false;
  isLandingPage = false;

  constructor(
    private authService: AuthService,
    private router: Router,
    private themeService: ThemeService
  ) {
    this.currentUser$ = this.authService.currentUser$;
    this.currentTheme$ = this.themeService.theme$;
    this.updateShellVisibility(this.router.url);

    this.router.events
      .pipe(filter((event): event is NavigationEnd => event instanceof NavigationEnd))
      .subscribe(event => this.updateShellVisibility(event.urlAfterRedirects));
  }

  toggleMenu() {
    this.menuOpen = !this.menuOpen;
  }

  closeMenu() {
    this.menuOpen = false;
  }

  toggleTheme() {
    this.themeService.toggleTheme();
  }

  private updateShellVisibility(url: string) {
    this.isLandingPage = url === '/' || url.startsWith('/?') || url.startsWith('/#');

    if (this.isLandingPage) {
      this.closeMenu();
    }
  }
}
