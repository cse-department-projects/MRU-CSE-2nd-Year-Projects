import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
    selector: 'app-forgot-password',
    standalone: true,
    imports: [CommonModule, FormsModule, RouterLink],
    templateUrl: './forgot-password.component.html',
    styleUrls: ['./auth.component.css']
})
export class ForgotPasswordComponent {
    request = {
        email: '',
        newPassword: ''
    };
    errorMessage = '';
    successMessage = '';
    loading = false;

    constructor(private authService: AuthService) {}

    resetPassword() {
        this.errorMessage = '';
        this.successMessage = '';

        if (!this.request.email || !this.request.newPassword) {
            this.errorMessage = 'Email and new password are required.';
            return;
        }

        if (this.request.newPassword.length < 6) {
            this.errorMessage = 'New password must be at least 6 characters.';
            return;
        }

        this.loading = true;
        this.authService.forgotPassword(this.request).subscribe({
            next: response => {
                this.loading = false;
                this.successMessage = response.message;
                this.request.newPassword = '';
            },
            error: error => {
                this.loading = false;
                this.errorMessage = error.error?.message || 'Could not reset password.';
            }
        });
    }
}
