import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../../services/auth.service';
import { ThemeMode, ThemeService } from '../../services/theme.service';
import { User } from '../../models/user.model';

@Component({
    selector: 'app-landing',
    standalone: true,
    imports: [CommonModule, RouterLink],
    templateUrl: './landing.component.html',
    styleUrls: ['./landing.component.css']
})
export class LandingComponent {
    currentUser$: Observable<User | null>;
    currentTheme$: Observable<ThemeMode>;

    constructor(private authService: AuthService, private themeService: ThemeService) {
        this.currentUser$ = this.authService.currentUser$;
        this.currentTheme$ = this.themeService.theme$;
    }

    features = [
        {
            title: 'Preparedness Planning',
            text: 'Organize hazard information, response readiness, and public safety priorities before an emergency escalates.'
        },
        {
            title: 'Response Coordination',
            text: 'Create incidents, update severity, monitor status, and keep operational details visible to responders.'
        },
        {
            title: 'Relief and Recovery',
            text: 'Track affected people, connect them to incidents, and support follow-up with clear saved records.'
        }
    ];

    operationSteps = [
        {
            title: 'Prepare',
            text: 'Keep response information, people data, and location awareness ready before incidents grow.'
        },
        {
            title: 'Respond',
            text: 'Register incidents, assign severity, update status, and see priority information quickly.'
        },
        {
            title: 'Monitor',
            text: 'Use dashboard summaries and image-backed news to understand changing field conditions.'
        },
        {
            title: 'Recover',
            text: 'Maintain affected people records and response history for follow-up and recovery planning.'
        }
    ];

    newsCards = [
        {
            image: '/images/flood-watch.jpg',
            tag: 'Flood Watch',
            title: 'Rising water levels near low-lying communities',
            text: 'Use incident news links to gather photo-backed context before assigning support teams.'
        },
        {
            image: '/images/disaster-hero.jpg',
            tag: 'Field Update',
            title: 'Road access and shelter status changing quickly',
            text: 'Keep response teams aligned with changing conditions and visible people records.'
        },
        {
            image: '/images/preparedness.jpg',
            tag: 'Preparedness',
            title: 'Community readiness improves with organized data',
            text: 'A single command view makes follow-up faster when pressure rises.'
        }
    ];

    stats = [
        { value: '24/7', label: 'preparedness and response focus' },
        { value: '4', label: 'response workflow stages' },
        { value: 'MySQL', label: 'secure persistent records' }
    ];

    scrollToSection(sectionId: string) {
        document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    toggleTheme() {
        this.themeService.toggleTheme();
    }
}
