import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export type ThemeMode = 'light' | 'dark';

@Injectable({
    providedIn: 'root'
})
export class ThemeService {
    private readonly storageKey = 'resq-theme';
    private readonly themeSubject = new BehaviorSubject<ThemeMode>(this.readTheme());
    theme$ = this.themeSubject.asObservable();

    constructor() {
        this.applyTheme(this.themeSubject.value);
    }

    toggleTheme() {
        this.setTheme(this.themeSubject.value === 'dark' ? 'light' : 'dark');
    }

    private setTheme(theme: ThemeMode) {
        localStorage.setItem(this.storageKey, theme);
        this.themeSubject.next(theme);
        this.applyTheme(theme);
    }

    private readTheme(): ThemeMode {
        const savedTheme = localStorage.getItem(this.storageKey);
        return savedTheme === 'dark' ? 'dark' : 'light';
    }

    private applyTheme(theme: ThemeMode) {
        document.documentElement.setAttribute('data-theme', theme);
        document.body.classList.toggle('dark-theme', theme === 'dark');
    }
}
