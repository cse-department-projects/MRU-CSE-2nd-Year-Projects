# DisasterVision – AI-Based Disaster Damage Assessment

Python (Flask) backend · Java assessment service · SQL database (SQLite)

## Run
```
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

The database (`disastervision.db`) is created automatically from `schema.sql`.
Java (JDK) is optional: if `java`/`javac` are installed, Module 5 runs in
`java/DamageAssessor.java`; otherwise an identical Python fallback is used.

## Demo logins
| Role      | Email                        | Password |
|-----------|------------------------------|----------|
| Admin     | admin@disastervision.com     | admin123 |
| Authority | authority@disastervision.com | auth123  |

Admin: upload + analyse images. Authority: view results, dashboard, generate reports.

## Structure
```
app.py            Flask routes (auth, upload, analyze, result, dashboard, history, reports)
ai_engine.py      Module 2 preprocessing, Module 3 detection, Module 4 classification
assessor.py       Python <-> Java bridge (Module 5)
java/DamageAssessor.java   Overall damage level + affected area %
schema.sql        6 tables: Users, Images, Damage_Detections, Damage_Classifications, Assessments, Reports
templates/ static/         Frontend pages and CSS
```

## Using a trained deep-learning model
`ai_engine.predict_tile(features)` is the single place the detector lives. It currently uses an
explainable image-analysis model (edges, texture, debris/burn/water colour). Replace it with your
CNN / YOLO inference (return `(object_type, damage_score 0..1)`) and nothing else changes.

## Notes
- Two columns were added to `Assessments` (`disaster_type`, `confidence`) for the Assessment Result page.
- Before deploying, set a real `SECRET_KEY` environment variable.
