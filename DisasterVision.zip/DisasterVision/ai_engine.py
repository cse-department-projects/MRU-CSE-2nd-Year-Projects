"""
DisasterVision AI engine (Modules 2, 3 and 4).

Module 2  preprocess()  - denoise, contrast, sharpen, resize, normalise
Module 3  detect()      - splits the image into grid tiles and finds structures
                          (building / road / bridge / other) with a confidence
Module 4  classify()    - labels each detection No / Minor / Moderate / Severe

The detector here is a lightweight, explainable computer-vision model based on
edge density, texture, debris colour, burn/dark pixels and water coverage.
It needs only Pillow + NumPy.  To use a trained deep-learning model instead,
replace `predict_tile()` (see README) - the rest of the system stays the same.
"""
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageOps

SIZE = 512          # working resolution
GRID = 8            # 8 x 8 = 64 tiles
LEVELS = ["No Damage", "Minor Damage", "Moderate Damage", "Severe Damage"]
COLORS = {
    "No Damage": (46, 160, 67),
    "Minor Damage": (240, 180, 0),
    "Moderate Damage": (240, 120, 0),
    "Severe Damage": (210, 30, 30),
}


# ---------------------------------------------------------------- Module 2
def preprocess(img: Image.Image) -> Image.Image:
    img = ImageOps.exif_transpose(img).convert("RGB")
    img = img.resize((SIZE, SIZE), Image.LANCZOS)                  # resize
    img = img.filter(ImageFilter.MedianFilter(3))                  # remove noise
    img = ImageOps.autocontrast(img, cutoff=1)                     # brightness/contrast
    img = img.filter(ImageFilter.UnsharpMask(radius=2, percent=120, threshold=3))  # sharpness
    return img


def normalise(img: Image.Image) -> np.ndarray:
    """float32 array in [0,1] - the form fed to the detector."""
    return np.asarray(img, dtype=np.float32) / 255.0


# ---------------------------------------------------------------- Module 3/4
def tile_features(tile: np.ndarray) -> dict:
    r, g, b = tile[..., 0], tile[..., 1], tile[..., 2]
    gray = tile.mean(axis=2)
    mx, mn = tile.max(axis=2), tile.min(axis=2)
    sat = (mx - mn) / (mx + 1e-6)

    gx = np.abs(np.diff(gray, axis=1))[:-1, :]
    gy = np.abs(np.diff(gray, axis=0))[:, :-1]
    edge = float(((gx + gy) > 0.18).mean())

    return {
        "edge": edge,
        "texture": float(gray.std()),
        "debris": float(((sat < 0.28) & (gray > 0.22) & (gray < 0.78)).mean()
                        * 0.5 + ((r > g) & (g > b) & ((r - b) > 0.06) & ((r - b) < 0.35)).mean() * 0.5),
        "dark": float((gray < 0.18).mean()),
        "fire": float(((r > 0.6) & (r > g * 1.3) & (g > b)).mean()),
        "water": float(((b > r + 0.06) & (b >= g * 0.95)).mean()),
        "green": float(((g > r * 1.05) & (g > b * 1.05)).mean()),
        "gray": float(((sat < 0.2) & (gray > 0.25)).mean()),
    }


def predict_tile(f: dict):
    """Return (object_type, damage_score 0..1) for one tile.
    Replace this function to plug in a trained CNN / YOLO model."""
    # object type
    if f["green"] > 0.5 and f["edge"] < 0.10:
        obj = "other"                      # vegetation / open land
    elif f["gray"] > 0.55 and f["texture"] < 0.12 and f["edge"] < 0.10:
        obj = "road"
    elif f["gray"] > 0.40 and f["water"] > 0.15:
        obj = "bridge"
    elif f["edge"] > 0.08:
        obj = "building"
    else:
        obj = "other"

    edge_n = min(f["edge"] / 0.30, 1.0)
    tex_n = min(f["texture"] / 0.28, 1.0)
    score = (0.38 * edge_n + 0.24 * f["debris"] + 0.18 * tex_n
             + 0.10 * min(f["dark"] * 3, 1.0) + 0.10 * min(f["fire"] * 4, 1.0)
             + 0.10 * min(f["water"] * 1.5, 1.0))
    if obj == "other" and f["green"] > 0.5:
        score *= 0.4
    return obj, float(min(score, 1.0))


def score_to_level(score: float):
    cuts = [0.22, 0.40, 0.58]
    if score < cuts[0]:
        lvl, nearest = 0, abs(score - cuts[0])
    elif score < cuts[1]:
        lvl, nearest = 1, min(abs(score - cuts[0]), abs(score - cuts[1]))
    elif score < cuts[2]:
        lvl, nearest = 2, min(abs(score - cuts[1]), abs(score - cuts[2]))
    else:
        lvl, nearest = 3, abs(score - cuts[2])
    confidence = round(min(0.60 + nearest * 1.8, 0.98), 3)   # far from a boundary = surer
    return LEVELS[lvl], confidence


def guess_disaster(totals: dict, mean_score: float) -> str:
    if mean_score < 0.20:
        return "No major disaster detected"
    if totals["water"] > 0.22:
        return "Flood"
    if totals["fire"] > 0.06 or totals["dark"] > 0.25:
        return "Wildfire / Fire"
    if totals["debris"] > 0.35 and totals["edge"] > 0.15:
        return "Earthquake / Structural collapse"
    return "Storm / Cyclone"


def analyze(path: str, out_dir: str, stem: str) -> dict:
    """Run the full pipeline on one image file."""
    original = Image.open(path)
    pre = preprocess(original)
    arr = normalise(pre)
    step = SIZE // GRID

    detections, feats_all = [], []
    for gy in range(GRID):
        for gx in range(GRID):
            x1, y1 = gx * step, gy * step
            tile = arr[y1:y1 + step, x1:x1 + step]
            f = tile_features(tile)
            feats_all.append(f)
            obj, score = predict_tile(f)
            # skip clear open-land/vegetation tiles so they do not dilute the result
            if obj == "other" and f["green"] > 0.5 and f["edge"] < 0.10:
                continue
            level, conf = score_to_level(score)
            detections.append({
                "detected_object": obj,
                "bbox": (x1, y1, x1 + step, y1 + step),
                "confidence": conf,
                "damage_level": level,
                "score": round(score, 3),
            })

    if not detections:                               # fall back to all tiles
        for i, f in enumerate(feats_all):
            gx, gy = i % GRID, i // GRID
            obj, score = predict_tile(f)
            level, conf = score_to_level(score)
            x1, y1 = gx * step, gy * step
            detections.append({"detected_object": obj, "bbox": (x1, y1, x1 + step, y1 + step),
                               "confidence": conf, "damage_level": level, "score": round(score, 3)})

    totals = {k: float(np.mean([f[k] for f in feats_all])) for k in feats_all[0]}
    mean_score = float(np.mean([d["score"] for d in detections]))

    # annotated overlay
    overlay = Image.new("RGBA", pre.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    for d in detections:
        if d["damage_level"] == "No Damage":
            continue
        c = COLORS[d["damage_level"]]
        draw.rectangle(d["bbox"], fill=c + (85,), outline=c + (255,), width=2)
    annotated = Image.alpha_composite(pre.convert("RGBA"), overlay).convert("RGB")

    pre_name, ann_name = f"{stem}_pre.jpg", f"{stem}_annotated.jpg"
    pre.save(f"{out_dir}/{pre_name}", quality=90)
    annotated.save(f"{out_dir}/{ann_name}", quality=90)

    return {
        "preprocessed_file": pre_name,
        "annotated_file": ann_name,
        "disaster_type": guess_disaster(totals, mean_score),
        "detections": detections,
    }
