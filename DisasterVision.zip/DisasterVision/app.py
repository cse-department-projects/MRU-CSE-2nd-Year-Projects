"""DisasterVision - AI-Based Disaster Damage Assessment (Flask backend)."""
import os
import sqlite3
from datetime import datetime
from functools import wraps

from flask import (Flask, abort, flash, g, redirect, render_template, request,
                   send_from_directory, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

import ai_engine
import assessor

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE, "disastervision.db")
UPLOAD_DIR = os.path.join(BASE, "uploads")
PROC_DIR = os.path.join(BASE, "processed")
REPORT_DIR = os.path.join(BASE, "reports")
ALLOWED = {"png", "jpg", "jpeg", "bmp", "webp", "tif", "tiff"}
for d in (UPLOAD_DIR, PROC_DIR, REPORT_DIR):
    os.makedirs(d, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-in-production")
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024

LEVEL_CLASS = {"No Damage": "no", "Minor Damage": "minor",
               "Moderate Damage": "moderate", "Severe Damage": "severe"}
RECOMMEND = {
    "Severe Damage": "Highest priority. Deploy rescue teams, medical aid and heavy equipment immediately; "
                     "restrict public access to the area.",
    "Moderate Damage": "High priority. Begin structural inspections, clear access roads and arrange "
                       "temporary shelter and relief supplies.",
    "Minor Damage": "Medium priority. Schedule repairs and inspections; monitor for further deterioration.",
    "No Damage": "Low priority. No immediate action needed; continue routine monitoring.",
}


@app.template_filter("lvl")
def lvl_filter(level):
    return LEVEL_CLASS.get(level, "no")


# ------------------------------------------------------------------ database
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)
    with open(os.path.join(BASE, "schema.sql")) as f:
        db.executescript(f.read())
    if db.execute("SELECT COUNT(*) FROM Users").fetchone()[0] == 0:
        db.executemany(
            "INSERT INTO Users (name,email,password,role) VALUES (?,?,?,?)",
            [("System Admin", "admin@disastervision.com", generate_password_hash("admin123"), "Admin"),
             ("Disaster Authority", "authority@disastervision.com", generate_password_hash("auth123"), "Authority")])
    db.commit()
    db.close()


# ------------------------------------------------------------------ auth
def login_required(role=None):
    def deco(fn):
        @wraps(fn)
        def wrapper(*a, **kw):
            if "user_id" not in session:
                flash("Please sign in to continue.", "warn")
                return redirect(url_for("login", next=request.path))
            if role and session.get("role") != role:
                flash(f"That page is only available to the {role} role.", "error")
                return redirect(url_for("dashboard"))
            return fn(*a, **kw)
        return wrapper
    return deco


@app.context_processor
def inject_user():
    return {"current_user": session.get("name"), "current_role": session.get("role")}


# ------------------------------------------------------------------ public pages
@app.route("/")
def home():
    return render_template("home.html")


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/how-it-works")
def how_it_works():
    return render_template("how.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        user = get_db().execute("SELECT * FROM Users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password"], request.form["password"]):
            session.clear()
            session.update(user_id=user["user_id"], name=user["name"], role=user["role"])
            nxt = request.args.get("next", "")
            return redirect(nxt if nxt.startswith("/") else url_for("dashboard"))
        flash("Invalid email or password.", "error")
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"].strip()
        email = request.form["email"].strip().lower()
        pw = request.form["password"]
        role = request.form.get("role", "Authority")
        if role not in ("Admin", "Authority"):
            role = "Authority"
        if not name or "@" not in email or len(pw) < 6:
            flash("Enter a name, a valid email and a password of at least 6 characters.", "error")
        else:
            try:
                get_db().execute("INSERT INTO Users (name,email,password,role) VALUES (?,?,?,?)",
                                 (name, email, generate_password_hash(pw), role))
                get_db().commit()
                flash("Account created. Please sign in.", "ok")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("That email is already registered.", "error")
    return render_template("register.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been signed out.", "ok")
    return redirect(url_for("home"))


# ------------------------------------------------------------------ Module 1: data collection
@app.route("/upload", methods=["GET", "POST"])
@login_required("Admin")
def upload():
    if request.method == "POST":
        f = request.files.get("image")
        location = request.form.get("location", "").strip()
        if not f or not f.filename:
            flash("Choose an image to upload.", "error")
        elif f.filename.rsplit(".", 1)[-1].lower() not in ALLOWED:
            flash("Unsupported file type. Use PNG, JPG, BMP, WEBP or TIFF.", "error")
        else:
            name = datetime.now().strftime("%Y%m%d%H%M%S_") + secure_filename(f.filename)
            f.save(os.path.join(UPLOAD_DIR, name))
            db = get_db()
            cur = db.execute("INSERT INTO Images (uploaded_by,image_path,location) VALUES (?,?,?)",
                             (session["user_id"], name, location or "Not specified"))
            db.commit()
            flash("Image uploaded. Ready for analysis.", "ok")
            return redirect(url_for("analyze", image_id=cur.lastrowid))
    return render_template("upload.html")


# ------------------------------------------------------------------ Modules 2-5: analysis
@app.route("/analyze/<int:image_id>", methods=["GET", "POST"])
@login_required("Admin")
def analyze(image_id):
    db = get_db()
    img = db.execute("SELECT * FROM Images WHERE image_id=?", (image_id,)).fetchone()
    if not img:
        abort(404)
    done = db.execute("SELECT 1 FROM Assessments WHERE image_id=?", (image_id,)).fetchone()
    if request.method == "POST" and not done:
        res = ai_engine.analyze(os.path.join(UPLOAD_DIR, img["image_path"]), PROC_DIR, f"img{image_id}")
        worst_cls, worst_rank = None, -1
        for d in res["detections"]:
            cur = db.execute(
                "INSERT INTO Damage_Detections (image_id,detected_object,bbox_coordinates,confidence_score) "
                "VALUES (?,?,?,?)",
                (image_id, d["detected_object"], ",".join(map(str, d["bbox"])), d["confidence"]))
            c = db.execute("INSERT INTO Damage_Classifications (detection_id,damage_level) VALUES (?,?)",
                           (cur.lastrowid, d["damage_level"]))
            rank = ai_engine.LEVELS.index(d["damage_level"])
            if rank > worst_rank:
                worst_rank, worst_cls = rank, c.lastrowid
        summary = assessor.assess([d["damage_level"] for d in res["detections"]])   # Java service
        conf = sum(d["confidence"] for d in res["detections"]) / len(res["detections"])
        db.execute(
            "INSERT INTO Assessments (image_id,classification_id,overall_damage_level,"
            "affected_area_percentage,disaster_type,confidence) VALUES (?,?,?,?,?,?)",
            (image_id, worst_cls, summary["overall"], summary["affected"], res["disaster_type"], round(conf, 3)))
        db.commit()
        return redirect(url_for("result", image_id=image_id))
    if done:
        return redirect(url_for("result", image_id=image_id))
    return render_template("analyze.html", img=img)


@app.route("/result/<int:image_id>")
@login_required()
def result(image_id):
    db = get_db()
    img = db.execute("SELECT i.*, u.name AS uploader FROM Images i JOIN Users u ON u.user_id=i.uploaded_by "
                     "WHERE image_id=?", (image_id,)).fetchone()
    a = db.execute("SELECT * FROM Assessments WHERE image_id=?", (image_id,)).fetchone()
    if not img or not a:
        flash("This image has not been analysed yet.", "warn")
        return redirect(url_for("history"))
    dets = db.execute(
        "SELECT d.*, c.damage_level FROM Damage_Detections d "
        "JOIN Damage_Classifications c ON c.detection_id=d.detection_id "
        "WHERE d.image_id=? ORDER BY c.damage_level='Severe Damage' DESC, "
        "c.damage_level='Moderate Damage' DESC, d.confidence_score DESC", (image_id,)).fetchall()
    counts = {k: 0 for k in LEVEL_CLASS}
    for d in dets:
        counts[d["damage_level"]] += 1
    report = db.execute("SELECT * FROM Reports WHERE assessment_id=? ORDER BY report_id DESC",
                        (a["assessment_id"],)).fetchone()
    return render_template("result.html", img=img, a=a, dets=dets, counts=counts, report=report,
                           advice=RECOMMEND[a["overall_damage_level"]], pre=f"img{image_id}_pre.jpg",
                           ann=f"img{image_id}_annotated.jpg")


# ------------------------------------------------------------------ dashboard / history
@app.route("/dashboard")
@login_required()
def dashboard():
    db = get_db()
    one = lambda q: db.execute(q).fetchone()[0]
    stats = {
        "images": one("SELECT COUNT(*) FROM Images"),
        "assessments": one("SELECT COUNT(*) FROM Assessments"),
        "detections": one("SELECT COUNT(*) FROM Damage_Detections"),
        "reports": one("SELECT COUNT(*) FROM Reports"),
        "avg_area": round(one("SELECT COALESCE(AVG(affected_area_percentage),0) FROM Assessments"), 1),
    }
    dist = {k: 0 for k in LEVEL_CLASS}
    for r in db.execute("SELECT overall_damage_level lv, COUNT(*) n FROM Assessments GROUP BY lv"):
        dist[r["lv"]] = r["n"]
    biggest = max(dist.values()) or 1
    recent = db.execute(
        "SELECT i.image_id, i.location, a.overall_damage_level, a.affected_area_percentage, a.assessed_at "
        "FROM Assessments a JOIN Images i ON i.image_id=a.image_id ORDER BY a.assessment_id DESC LIMIT 6"
    ).fetchall()
    pending = db.execute("SELECT COUNT(*) FROM Images WHERE image_id NOT IN (SELECT image_id FROM Assessments)"
                         ).fetchone()[0]
    return render_template("dashboard.html", stats=stats, dist=dist, biggest=biggest,
                           recent=recent, pending=pending)


@app.route("/history")
@login_required()
def history():
    db = get_db()
    rows = db.execute(
        "SELECT i.image_id, i.image_path, i.location, i.uploaded_at, u.name uploader, "
        "a.overall_damage_level, a.affected_area_percentage, a.disaster_type, a.confidence "
        "FROM Images i JOIN Users u ON u.user_id=i.uploaded_by "
        "LEFT JOIN Assessments a ON a.image_id=i.image_id ORDER BY i.image_id DESC").fetchall()
    reports = db.execute(
        "SELECT r.*, u.name AS author, a.image_id FROM Reports r "
        "JOIN Users u ON u.user_id=r.generated_by JOIN Assessments a ON a.assessment_id=r.assessment_id "
        "ORDER BY r.report_id DESC").fetchall()
    return render_template("history.html", rows=rows, reports=reports)


# ------------------------------------------------------------------ reports
@app.route("/report/<int:assessment_id>", methods=["POST"])
@login_required()
def make_report(assessment_id):
    db = get_db()
    a = db.execute("SELECT * FROM Assessments WHERE assessment_id=?", (assessment_id,)).fetchone()
    if not a:
        abort(404)
    img = db.execute("SELECT * FROM Images WHERE image_id=?", (a["image_id"],)).fetchone()
    dets = db.execute(
        "SELECT d.detected_object obj, c.damage_level lv FROM Damage_Detections d "
        "JOIN Damage_Classifications c ON c.detection_id=d.detection_id WHERE d.image_id=?",
        (a["image_id"],)).fetchall()
    counts = {k: 0 for k in LEVEL_CLASS}
    by_obj = {}
    for d in dets:
        counts[d["lv"]] += 1
        by_obj.setdefault(d["obj"], {k: 0 for k in LEVEL_CLASS})[d["lv"]] += 1
    html = render_template("report.html", a=a, img=img, counts=counts, by_obj=by_obj,
                           total=len(dets), advice=RECOMMEND[a["overall_damage_level"]],
                           author=session["name"], now=datetime.now().strftime("%d %b %Y, %H:%M"),
                           ann=f"img{a['image_id']}_annotated.jpg")
    fname = f"report_{assessment_id}_{datetime.now().strftime('%Y%m%d%H%M%S')}.html"
    with open(os.path.join(REPORT_DIR, fname), "w", encoding="utf-8") as f:
        f.write(html)
    db.execute("INSERT INTO Reports (assessment_id,report_file_path,generated_by) VALUES (?,?,?)",
               (assessment_id, fname, session["user_id"]))
    db.commit()
    flash("Report generated.", "ok")
    return redirect(url_for("result", image_id=a["image_id"]))


@app.route("/files/reports/<name>")
@login_required()
def report_file(name):
    return send_from_directory(REPORT_DIR, name)


@app.route("/files/uploads/<name>")
@login_required()
def upload_file(name):
    return send_from_directory(UPLOAD_DIR, name)


@app.route("/files/processed/<name>")
@login_required()
def processed_file(name):
    return send_from_directory(PROC_DIR, name)


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
