"""Bridge between Flask (Python) and the Java assessment service (Module 5).
If Java is not installed, an identical Python implementation is used."""
import os
import shutil
import subprocess

BASE = os.path.dirname(os.path.abspath(__file__))
JAVA_SRC = os.path.join(BASE, "java", "DamageAssessor.java")
JAVA_OUT = os.path.join(BASE, "java")


def _weight(level):
    l = level.lower()
    return 3 if l.startswith("severe") else 2 if l.startswith("moderate") else 1 if l.startswith("minor") else 0


def _python_assess(levels):
    total = len(levels)
    if total == 0:
        return {"overall": "No Damage", "affected": 0.0, "total": 0, "severity_index": 0.0}
    w = [_weight(x) for x in levels]
    affected = 100.0 * sum(1 for x in w if x > 0) / total
    index = 100.0 * sum(w) / (3.0 * total)
    severe_share = 100.0 * sum(1 for x in w if x == 3) / total
    if severe_share >= 30 or index >= 60:
        overall = "Severe Damage"
    elif index >= 35:
        overall = "Moderate Damage"
    elif index >= 12:
        overall = "Minor Damage"
    else:
        overall = "No Damage"
    return {"overall": overall, "affected": round(affected, 2), "total": total,
            "severity_index": round(index, 2)}


def _java_ready():
    if not (shutil.which("java") and shutil.which("javac")):
        return False
    cls = os.path.join(JAVA_OUT, "DamageAssessor.class")
    if not os.path.exists(cls):
        r = subprocess.run(["javac", "-d", JAVA_OUT, JAVA_SRC], capture_output=True)
        return r.returncode == 0
    return True


def assess(levels):
    """levels: list of damage-level strings. Returns dict + which engine ran."""
    if _java_ready():
        try:
            r = subprocess.run(["java", "-cp", JAVA_OUT, "DamageAssessor"],
                               input="\n".join(levels), capture_output=True,
                               text=True, timeout=15)
            if r.returncode == 0:
                kv = dict(line.split("=", 1) for line in r.stdout.splitlines() if "=" in line)
                return {"overall": kv["overall"], "affected": float(kv["affected"]),
                        "total": int(kv["total"]), "severity_index": float(kv["severity_index"]),
                        "engine": "java"}
        except Exception:
            pass
    out = _python_assess(levels)
    out["engine"] = "python"
    return out
