import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * DisasterVision - Module 5 (Damage Assessment) in Java.
 *
 * Reads one damage level per line from standard input
 * (No Damage / Minor Damage / Moderate Damage / Severe Damage)
 * and prints the overall assessment as key=value lines:
 *
 *   overall=Moderate Damage
 *   affected=42.19
 *   total=64
 *   severity_index=38.54
 *
 * Compile:  javac -d java java/DamageAssessor.java
 * Run:      echo "Severe Damage" | java -cp java DamageAssessor
 */
public class DamageAssessor {

    static int weight(String level) {
        String l = level.trim().toLowerCase();
        if (l.startsWith("severe"))   return 3;
        if (l.startsWith("moderate")) return 2;
        if (l.startsWith("minor"))    return 1;
        return 0;
    }

    public static void main(String[] args) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        int total = 0, affected = 0, severe = 0, weighted = 0;
        String line;
        while ((line = in.readLine()) != null) {
            if (line.trim().isEmpty()) continue;
            int w = weight(line);
            total++;
            weighted += w;
            if (w > 0) affected++;
            if (w == 3) severe++;
        }

        if (total == 0) {
            System.out.println("overall=No Damage");
            System.out.println("affected=0.00");
            System.out.println("total=0");
            System.out.println("severity_index=0.00");
            return;
        }

        double affectedPct   = 100.0 * affected / total;
        double severityIndex = 100.0 * weighted / (3.0 * total);
        double severeShare   = 100.0 * severe / total;

        String overall;
        if (severeShare >= 30 || severityIndex >= 60) overall = "Severe Damage";
        else if (severityIndex >= 35)                 overall = "Moderate Damage";
        else if (severityIndex >= 12)                 overall = "Minor Damage";
        else                                          overall = "No Damage";

        System.out.println("overall=" + overall);
        System.out.printf("affected=%.2f%n", affectedPct);
        System.out.println("total=" + total);
        System.out.printf("severity_index=%.2f%n", severityIndex);
    }
}
