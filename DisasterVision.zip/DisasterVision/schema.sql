-- DisasterVision database schema (SQLite) -- follows the ER diagram

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS Users (
    user_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    email       TEXT NOT NULL UNIQUE,
    password    TEXT NOT NULL,                              -- hashed, never plain text
    role        TEXT NOT NULL CHECK (role IN ('Admin','Authority')),
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS Images (
    image_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    uploaded_by  INTEGER NOT NULL REFERENCES Users(user_id),
    image_path   TEXT NOT NULL,
    location     TEXT,
    uploaded_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS Damage_Detections (
    detection_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    image_id         INTEGER NOT NULL REFERENCES Images(image_id) ON DELETE CASCADE,
    detected_object  TEXT NOT NULL CHECK (detected_object IN ('building','road','bridge','other')),
    bbox_coordinates TEXT NOT NULL,                         -- "x1,y1,x2,y2"
    confidence_score REAL NOT NULL,
    detected_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS Damage_Classifications (
    classification_id INTEGER PRIMARY KEY AUTOINCREMENT,
    detection_id      INTEGER NOT NULL REFERENCES Damage_Detections(detection_id) ON DELETE CASCADE,
    damage_level      TEXT NOT NULL CHECK (damage_level IN
                        ('No Damage','Minor Damage','Moderate Damage','Severe Damage')),
    classified_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS Assessments (
    assessment_id          INTEGER PRIMARY KEY AUTOINCREMENT,
    image_id               INTEGER NOT NULL REFERENCES Images(image_id) ON DELETE CASCADE,
    classification_id      INTEGER REFERENCES Damage_Classifications(classification_id),
    overall_damage_level   TEXT NOT NULL CHECK (overall_damage_level IN
                             ('No Damage','Minor Damage','Moderate Damage','Severe Damage')),
    affected_area_percentage REAL NOT NULL,
    -- two extra columns used by the "Assessment Result" screen
    disaster_type          TEXT,
    confidence             REAL,
    assessed_at            TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS Reports (
    report_id        INTEGER PRIMARY KEY AUTOINCREMENT,
    assessment_id    INTEGER NOT NULL REFERENCES Assessments(assessment_id) ON DELETE CASCADE,
    report_file_path TEXT NOT NULL,
    generated_by     INTEGER NOT NULL REFERENCES Users(user_id),
    generated_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_det_image   ON Damage_Detections(image_id);
CREATE INDEX IF NOT EXISTS idx_cls_det     ON Damage_Classifications(detection_id);
CREATE INDEX IF NOT EXISTS idx_assess_img  ON Assessments(image_id);
