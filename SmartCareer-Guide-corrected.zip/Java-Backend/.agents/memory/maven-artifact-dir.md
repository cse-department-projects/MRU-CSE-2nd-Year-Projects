---
name: Maven artifact working directory
description: Development Maven workflows run from the artifact directory, while production build commands run from the workspace root.
---

The artifact's `[services.development] run` command executes with the artifact directory as its working directory. Use bare Maven commands there, such as `mvn spring-boot:run`.

The production build command was observed executing from the workspace root. Its Maven POM and output JAR paths must therefore be relative to the workspace root, for example `mvn -f artifacts/api-server/pom.xml package` and `java -jar artifacts/api-server/target/career-saathi-api-1.0.0.jar`.

**Why:** Development workflow logs and production deployment logs use different working directories; using one path convention for both caused the API deployment build to fail.

**How to apply:** Keep development workflow commands relative to the artifact directory, but use workspace-root-relative paths for production build/run arguments. If deployment logs show a different working directory, follow the logs and revise this rule.
