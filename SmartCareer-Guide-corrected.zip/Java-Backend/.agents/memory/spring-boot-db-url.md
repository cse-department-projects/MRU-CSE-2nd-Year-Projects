---
name: Spring Boot DATABASE_URL fix
description: Replit's DATABASE_URL uses postgresql:// scheme; JDBC requires jdbc:postgresql://. Must convert with a custom DataSource bean.
---

Replit's `DATABASE_URL` env var has the format:
`postgresql://user:password@host/dbname?sslmode=disable`

JDBC rejects this — it needs `jdbc:postgresql://host/dbname?...` with credentials passed separately.

**Why:** PostgreSQL JDBC driver's `DriverManager` does not accept the `postgresql://` scheme, only `jdbc:postgresql://`.

**How to apply:** Create `DataSourceConfig.java` with a `@Bean @Primary DataSource` that parses the URI manually and constructs a HikariCP DataSource with the correct JDBC URL. Do NOT set `spring.datasource.url=${DATABASE_URL}` in `application.properties` — this bypasses the conversion and fails at startup.

The conversion logic:
1. Replace `postgres://` or `postgresql://` with `http://` temporarily
2. Parse with `java.net.URI`
3. Reconstruct as `jdbc:postgresql://host:port/path?query`
4. Extract username/password from `uri.getUserInfo()`
5. Pass to `HikariConfig.setUsername()` / `setPassword()` separately
