# Run SmartCareer Guide on Windows

These steps run the web app and its Spring Boot API locally from VS Code. They use a local PostgreSQL database; Replit's database connection is not available on your laptop.

## 1. Get the project onto your laptop

In Replit, open the file tree's three-dot menu and choose **Download as zip**. Unzip the download, then open the extracted project folder in VS Code. Open the folder that contains `pnpm-workspace.yaml`, not one of the folders inside `artifacts`.

Replit's instructions: [Download project files](https://docs.replit.com/help/projects-and-files).

## 2. Install the tools

Install these for Windows x64:

- Node.js 24 LTS
- Java JDK 19
- Apache Maven 3.8 or newer
- PostgreSQL 15 or newer

In a new VS Code PowerShell terminal, verify they are on `PATH`:

```powershell
node --version
npm --version
java -version
mvn --version
```

Install the workspace's pinned pnpm version:

```powershell
npm install --global pnpm@10.26.1
pnpm --version
```

## 3. Install the project packages

From the project root in VS Code:

```powershell
pnpm install --frozen-lockfile
```

## 4. Create a local database

In pgAdmin, create a database named `smartcareer`. The API creates its tables and seed data when it starts.

## 5. Start the API

Open a VS Code terminal and run:

```powershell
Set-Location .\artifacts\api-server
$pgPassword = Read-Host "Password for your local PostgreSQL user"
$encodedPassword = [System.Uri]::EscapeDataString($pgPassword)
$env:DATABASE_URL = "postgresql://postgres:$encodedPassword@127.0.0.1:5432/smartcareer"
mvn spring-boot:run
```

If your PostgreSQL username is not `postgres`, change it in the `DATABASE_URL` line. Keep this local database password private; do not commit it or send it in chat.

The API runs at `http://localhost:8080/api`.

## 6. Start the web app

Open a second VS Code terminal at the project root:

```powershell
$env:PORT = "5173"
$env:BASE_PATH = "/"
$env:LOCAL_API_TARGET = "http://127.0.0.1:8080"
pnpm --filter @workspace/career-guide run dev
```

Open `http://localhost:5173` in your browser. The local Vite proxy forwards `/api` requests to the API. Replit runs without `LOCAL_API_TARGET`, so this local setting does not replace Replit's routing.

## Mobile app

The mobile artifact uses Expo and needs a separate Android/iOS setup. These instructions cover the web app and API first.