package com.careersaathi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CareerSaathiApplication {
    public static void main(String[] args) {
        SpringApplication.run(CareerSaathiApplication.class, args);
    }
}
