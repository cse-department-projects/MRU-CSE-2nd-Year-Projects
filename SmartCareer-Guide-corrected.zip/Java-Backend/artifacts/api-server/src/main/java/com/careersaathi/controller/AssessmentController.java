package com.careersaathi.controller;

import com.careersaathi.model.*;
import com.careersaathi.service.AssessmentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/assessments")
public class AssessmentController {
    private final AssessmentService service;

    public AssessmentController(AssessmentService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Assessment startAssessment(@RequestBody AssessmentInput input) {
        return service.startAssessment(input);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Assessment> getAssessment(@PathVariable int id) {
        Assessment assessment = service.getAssessment(id);
        if (assessment == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(assessment);
    }

    @PostMapping("/{id}/submit")
    public ResponseEntity<AssessmentResult> submit(
        @PathVariable int id,
        @RequestBody AssessmentSubmission submission
    ) {
        AssessmentResult result = service.submitAssessment(id, submission);
        return ResponseEntity.ok(result);
    }
}
