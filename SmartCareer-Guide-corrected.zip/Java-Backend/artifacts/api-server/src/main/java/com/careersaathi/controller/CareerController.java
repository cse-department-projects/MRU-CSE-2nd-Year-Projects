package com.careersaathi.controller;

import com.careersaathi.model.Career;
import com.careersaathi.model.CareerDetail;
import com.careersaathi.model.CareerRecommendation;
import com.careersaathi.service.CareerService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/careers")
public class CareerController {
    private final CareerService service;

    public CareerController(CareerService service) {
        this.service = service;
    }

    @GetMapping
    public List<Career> listCareers(
        @RequestParam(required = false) String cluster,
        @RequestParam(required = false) String stream,
        @RequestParam(required = false) String search
    ) {
        return service.listCareers(cluster, stream, search);
    }

    @GetMapping("/recommendations")
    public List<CareerRecommendation> getRecommendations(
        @RequestParam(required = false) String currentClass,
        @RequestParam(required = false) String stream,
        @RequestParam(required = false) List<String> interests,
        @RequestParam(required = false) List<String> skills,
        @RequestParam(required = false) List<String> goals
    ) {
        return service.getRecommendations(currentClass, stream, interests, skills, goals);
    }

    @GetMapping("/trending")
    public List<Career> getTrending() {
        return service.getTrendingCareers();
    }

    @GetMapping("/{id}")
    public ResponseEntity<CareerDetail> getCareer(@PathVariable int id) {
        CareerDetail career = service.getCareer(id);
        if (career == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(career);
    }
}
