package com.careersaathi.controller;

import com.careersaathi.model.ChatMessage;
import com.careersaathi.model.ChatResponse;
import com.careersaathi.service.ChatService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/chat")
public class ChatController {
    private final ChatService service;

    public ChatController(ChatService service) {
        this.service = service;
    }

    @PostMapping
    public ChatResponse chat(@RequestBody ChatMessage input) {
        return service.chat(
            input.getMessage(),
            input.getSessionId(),
            input.getLanguage(),
            input.getStudentName(),
            input.getStudentClass(),
            input.getStudentStream(),
            input.getStudentDistrict()
        );
    }
}
