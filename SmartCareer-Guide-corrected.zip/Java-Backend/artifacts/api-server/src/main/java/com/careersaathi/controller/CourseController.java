package com.careersaathi.controller;

import com.careersaathi.model.Course;
import com.careersaathi.repository.CourseRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/courses")
public class CourseController {
    private final CourseRepository repository;

    public CourseController(CourseRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<Course> listCourses(
        @RequestParam(required = false) Integer careerId,
        @RequestParam(required = false) String stream,
        @RequestParam(required = false) String level,
        @RequestParam(required = false) String search
    ) {
        return repository.findAll(careerId, stream, level, search);
    }
}