package com.careersaathi.controller;

import com.careersaathi.model.EntranceExam;
import com.careersaathi.service.EntranceExamService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/entrance-exams")
public class EntranceExamController {
    private final EntranceExamService service;

    public EntranceExamController(EntranceExamService service) {
        this.service = service;
    }

    @GetMapping
    public List<EntranceExam> list(
        @RequestParam(required = false) String level,
        @RequestParam(required = false) String stream,
        @RequestParam(required = false) String search
    ) {
        return service.list(level, stream, search);
    }
}
