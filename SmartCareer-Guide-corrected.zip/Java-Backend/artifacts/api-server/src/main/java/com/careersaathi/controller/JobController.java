package com.careersaathi.controller;

import com.careersaathi.model.Job;
import com.careersaathi.model.JobStats;
import com.careersaathi.repository.JobRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/jobs")
public class JobController {
    private final JobRepository repo;

    public JobController(JobRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Job> listJobs(
        @RequestParam(required = false) String type,
        @RequestParam(required = false) String location,
        @RequestParam(required = false) Boolean remote,
        @RequestParam(required = false) Integer careerId
    ) {
        return repo.findAll(type, location, remote);
    }

    @GetMapping("/stats")
    public JobStats getStats() {
        JobStats stats = new JobStats();
        stats.setTotalJobs(repo.countByType("job"));
        stats.setTotalInternships(repo.countByType("internship"));
        stats.setTopLocations(List.of("Hyderabad", "Remote", "Warangal", "Karimnagar", "Nizamabad"));
        stats.setTopRoles(List.of("Software Engineer", "Data Analyst", "Content Writer", "Civil Engineer", "Digital Marketer"));
        stats.setAverageStipend("12,000/month");
        return stats;
    }
}
