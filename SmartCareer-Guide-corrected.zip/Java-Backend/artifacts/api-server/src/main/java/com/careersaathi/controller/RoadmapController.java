package com.careersaathi.controller;

import com.careersaathi.model.Roadmap;
import com.careersaathi.service.RoadmapService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/roadmaps")
public class RoadmapController {
    private final RoadmapService service;

    public RoadmapController(RoadmapService service) {
        this.service = service;
    }

    @GetMapping("/{careerId}")
    public ResponseEntity<Roadmap> getRoadmap(@PathVariable int careerId) {
        Roadmap roadmap = service.getRoadmap(careerId);
        if (roadmap == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(roadmap);
    }
}
