package com.careersaathi.controller;

import com.careersaathi.model.Scholarship;
import com.careersaathi.repository.ScholarshipRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/scholarships")
public class ScholarshipController {
    private final ScholarshipRepository repo;

    public ScholarshipController(ScholarshipRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Scholarship> listScholarships(
        @RequestParam(required = false) String category,
        @RequestParam(required = false) String level,
        @RequestParam(required = false) String state
    ) {
        return repo.findAll(category, level, state);
    }
}
