package com.careersaathi.controller;

import com.careersaathi.model.StudentWorkspace;
import com.careersaathi.service.StudentWorkspaceService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/students")
public class StudentWorkspaceController {
    private final StudentWorkspaceService service;

    public StudentWorkspaceController(StudentWorkspaceService service) {
        this.service = service;
    }

    @GetMapping("/{studentId}/workspace")
    public StudentWorkspace getWorkspace(@PathVariable UUID studentId) {
        return service.get(studentId.toString());
    }

    @PutMapping("/{studentId}/workspace")
    public StudentWorkspace saveWorkspace(
        @PathVariable UUID studentId,
        @RequestBody StudentWorkspace workspace
    ) {
        return service.save(studentId.toString(), workspace);
    }
}
