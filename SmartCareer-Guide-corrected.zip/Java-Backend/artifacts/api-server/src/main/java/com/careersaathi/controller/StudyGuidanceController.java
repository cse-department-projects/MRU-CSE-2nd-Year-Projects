package com.careersaathi.controller;

import com.careersaathi.model.StudyGuidance;
import com.careersaathi.service.StudyGuidanceService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/study-guidance")
public class StudyGuidanceController {
    private final StudyGuidanceService service;

    public StudyGuidanceController(StudyGuidanceService service) {
        this.service = service;
    }

    @GetMapping
    public List<StudyGuidance> list(@RequestParam(required = false) String stage) {
        return service.list(stage);
    }
}
