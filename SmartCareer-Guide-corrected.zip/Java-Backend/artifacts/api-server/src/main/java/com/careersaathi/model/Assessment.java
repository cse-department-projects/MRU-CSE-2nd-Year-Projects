package com.careersaathi.model;

import java.util.List;

public class Assessment {
    private Integer id;
    private String userName;
    private String status;
    private List<Question> questions;
    private AssessmentResult result;

    public Assessment() {}

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public List<Question> getQuestions() { return questions; }
    public void setQuestions(List<Question> questions) { this.questions = questions; }

    public AssessmentResult getResult() { return result; }
    public void setResult(AssessmentResult result) { this.result = result; }
}
