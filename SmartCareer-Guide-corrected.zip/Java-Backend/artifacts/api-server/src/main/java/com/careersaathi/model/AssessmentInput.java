package com.careersaathi.model;

public class AssessmentInput {
    private String userName;
    private String currentClass;
    private String studentStream;
    private String preferredLanguage;

    public AssessmentInput() {}

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    public String getCurrentClass() { return currentClass; }
    public void setCurrentClass(String currentClass) { this.currentClass = currentClass; }

    public String getStudentStream() { return studentStream; }
    public void setStudentStream(String studentStream) { this.studentStream = studentStream; }

    public String getPreferredLanguage() { return preferredLanguage; }
    public void setPreferredLanguage(String preferredLanguage) { this.preferredLanguage = preferredLanguage; }
}
