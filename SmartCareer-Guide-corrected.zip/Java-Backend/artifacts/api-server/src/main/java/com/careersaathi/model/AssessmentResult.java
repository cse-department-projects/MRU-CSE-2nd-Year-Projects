package com.careersaathi.model;

import java.util.List;

public class AssessmentResult {
    private String personalityType;
    private String personalityLabel;
    private String description;
    private List<String> careerClusters;
    private List<Career> topCareers;
    private List<String> strengths;

    public AssessmentResult() {}

    public String getPersonalityType() { return personalityType; }
    public void setPersonalityType(String personalityType) { this.personalityType = personalityType; }

    public String getPersonalityLabel() { return personalityLabel; }
    public void setPersonalityLabel(String personalityLabel) { this.personalityLabel = personalityLabel; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public List<String> getCareerClusters() { return careerClusters; }
    public void setCareerClusters(List<String> careerClusters) { this.careerClusters = careerClusters; }

    public List<Career> getTopCareers() { return topCareers; }
    public void setTopCareers(List<Career> topCareers) { this.topCareers = topCareers; }

    public List<String> getStrengths() { return strengths; }
    public void setStrengths(List<String> strengths) { this.strengths = strengths; }
}
