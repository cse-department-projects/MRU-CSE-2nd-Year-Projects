package com.careersaathi.model;

import java.util.List;

public class AssessmentSubmission {
    private List<Answer> answers;

    public AssessmentSubmission() {}

    public List<Answer> getAnswers() { return answers; }
    public void setAnswers(List<Answer> answers) { this.answers = answers; }

    public static class Answer {
        private Integer questionId;
        private String optionId;

        public Answer() {}

        public Integer getQuestionId() { return questionId; }
        public void setQuestionId(Integer questionId) { this.questionId = questionId; }

        public String getOptionId() { return optionId; }
        public void setOptionId(String optionId) { this.optionId = optionId; }
    }
}
