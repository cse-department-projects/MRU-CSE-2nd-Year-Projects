package com.careersaathi.model;

import java.util.List;

public class Career {
    private Integer id;
    private String title;
    private String cluster;
    private List<String> streams;
    private String salaryRange;
    private String demandLevel;
    private String description;
    private String iconEmoji;
    private List<String> tags;
    private List<String> skills;

    public Career() {}

    public Career(Integer id, String title, String cluster, List<String> streams,
                  String salaryRange, String demandLevel, String description,
                  String iconEmoji, List<String> tags) {
        this.id = id;
        this.title = title;
        this.cluster = cluster;
        this.streams = streams;
        this.salaryRange = salaryRange;
        this.demandLevel = demandLevel;
        this.description = description;
        this.iconEmoji = iconEmoji;
        this.tags = tags;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getCluster() { return cluster; }
    public void setCluster(String cluster) { this.cluster = cluster; }

    public List<String> getStreams() { return streams; }
    public void setStreams(List<String> streams) { this.streams = streams; }

    public String getSalaryRange() { return salaryRange; }
    public void setSalaryRange(String salaryRange) { this.salaryRange = salaryRange; }

    public String getDemandLevel() { return demandLevel; }
    public void setDemandLevel(String demandLevel) { this.demandLevel = demandLevel; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getIconEmoji() { return iconEmoji; }
    public void setIconEmoji(String iconEmoji) { this.iconEmoji = iconEmoji; }

    public List<String> getTags() { return tags; }
    public void setTags(List<String> tags) { this.tags = tags; }

    public List<String> getSkills() { return skills; }
    public void setSkills(List<String> skills) { this.skills = skills; }
}
