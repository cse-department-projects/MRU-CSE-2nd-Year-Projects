package com.careersaathi.model;

import java.util.List;

public class CareerDetail extends Career {
    private List<String> entryPaths;
    private List<String> localOpportunities;
    private Double averageSalaryLPA;
    private String growthRate;

    public CareerDetail() {}

    public List<String> getEntryPaths() { return entryPaths; }
    public void setEntryPaths(List<String> entryPaths) { this.entryPaths = entryPaths; }

    public List<String> getLocalOpportunities() { return localOpportunities; }
    public void setLocalOpportunities(List<String> localOpportunities) { this.localOpportunities = localOpportunities; }

    public Double getAverageSalaryLPA() { return averageSalaryLPA; }
    public void setAverageSalaryLPA(Double averageSalaryLPA) { this.averageSalaryLPA = averageSalaryLPA; }

    public String getGrowthRate() { return growthRate; }
    public void setGrowthRate(String growthRate) { this.growthRate = growthRate; }
}
