package com.careersaathi.model;

public class ChatMessage {
    private String message;
    private String sessionId;
    private String language;
    private String studentName;
    private String studentClass;
    private String studentStream;
    private String studentDistrict;

    public ChatMessage() {}

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getSessionId() { return sessionId; }
    public void setSessionId(String sessionId) { this.sessionId = sessionId; }

    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public String getStudentClass() { return studentClass; }
    public void setStudentClass(String studentClass) { this.studentClass = studentClass; }

    public String getStudentStream() { return studentStream; }
    public void setStudentStream(String studentStream) { this.studentStream = studentStream; }

    public String getStudentDistrict() { return studentDistrict; }
    public void setStudentDistrict(String studentDistrict) { this.studentDistrict = studentDistrict; }
}
