package com.careersaathi.model;

import java.util.List;

public class ChatResponse {
    private String message;
    private String sessionId;
    private List<String> suggestedQuestions;
    private List<Career> relatedCareers;

    public ChatResponse() {}

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getSessionId() { return sessionId; }
    public void setSessionId(String sessionId) { this.sessionId = sessionId; }

    public List<String> getSuggestedQuestions() { return suggestedQuestions; }
    public void setSuggestedQuestions(List<String> suggestedQuestions) { this.suggestedQuestions = suggestedQuestions; }

    public List<Career> getRelatedCareers() { return relatedCareers; }
    public void setRelatedCareers(List<Career> relatedCareers) { this.relatedCareers = relatedCareers; }
}
