package com.careersaathi.model;

import java.util.List;

public class Course {
    private int id;
    private String title;
    private String provider;
    private String category;
    private String level;
    private List<String> skills;
    private String duration;
    private String cost;
    private String format;
    private String description;
    private List<String> streams;
    private List<Integer> careerIds;
    private String url;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getProvider() { return provider; }
    public void setProvider(String provider) { this.provider = provider; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getLevel() { return level; }
    public void setLevel(String level) { this.level = level; }
    public List<String> getSkills() { return skills; }
    public void setSkills(List<String> skills) { this.skills = skills; }
    public String getDuration() { return duration; }
    public void setDuration(String duration) { this.duration = duration; }
    public String getCost() { return cost; }
    public void setCost(String cost) { this.cost = cost; }
    public String getFormat() { return format; }
    public void setFormat(String format) { this.format = format; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public List<String> getStreams() { return streams; }
    public void setStreams(List<String> streams) { this.streams = streams; }
    public List<Integer> getCareerIds() { return careerIds; }
    public void setCareerIds(List<Integer> careerIds) { this.careerIds = careerIds; }
    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
}