package com.careersaathi.model;

import java.util.List;

public class Dashboard {
    private List<Career> recentCareers;
    private List<Career> trendingCareers;
    private List<Deadline> upcomingDeadlines;
    private QuickStats quickStats;

    public Dashboard() {}

    public List<Career> getRecentCareers() { return recentCareers; }
    public void setRecentCareers(List<Career> recentCareers) { this.recentCareers = recentCareers; }

    public List<Career> getTrendingCareers() { return trendingCareers; }
    public void setTrendingCareers(List<Career> trendingCareers) { this.trendingCareers = trendingCareers; }

    public List<Deadline> getUpcomingDeadlines() { return upcomingDeadlines; }
    public void setUpcomingDeadlines(List<Deadline> upcomingDeadlines) { this.upcomingDeadlines = upcomingDeadlines; }

    public QuickStats getQuickStats() { return quickStats; }
    public void setQuickStats(QuickStats quickStats) { this.quickStats = quickStats; }
}
