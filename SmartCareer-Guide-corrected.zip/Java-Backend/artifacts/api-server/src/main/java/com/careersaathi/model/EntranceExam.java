package com.careersaathi.model;

import java.util.ArrayList;
import java.util.List;

public class EntranceExam {
    private Integer id;
    private String name;
    private List<String> levels = new ArrayList<>();
    private List<String> streams = new ArrayList<>();
    private String eligibility;
    private String deadline;
    private String deadlineNote;
    private String applicationUrl;
    private String conductingAuthority;

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public List<String> getLevels() { return levels; }
    public void setLevels(List<String> levels) { this.levels = levels; }

    public List<String> getStreams() { return streams; }
    public void setStreams(List<String> streams) { this.streams = streams; }

    public String getEligibility() { return eligibility; }
    public void setEligibility(String eligibility) { this.eligibility = eligibility; }

    public String getDeadline() { return deadline; }
    public void setDeadline(String deadline) { this.deadline = deadline; }

    public String getDeadlineNote() { return deadlineNote; }
    public void setDeadlineNote(String deadlineNote) { this.deadlineNote = deadlineNote; }

    public String getApplicationUrl() { return applicationUrl; }
    public void setApplicationUrl(String applicationUrl) { this.applicationUrl = applicationUrl; }

    public String getConductingAuthority() { return conductingAuthority; }
    public void setConductingAuthority(String conductingAuthority) { this.conductingAuthority = conductingAuthority; }
}
