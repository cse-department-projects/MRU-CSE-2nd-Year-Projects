package com.careersaathi.model;

import java.util.List;

public class JobStats {
    private Integer totalJobs;
    private Integer totalInternships;
    private List<String> topLocations;
    private List<String> topRoles;
    private String averageStipend;

    public JobStats() {}

    public Integer getTotalJobs() { return totalJobs; }
    public void setTotalJobs(Integer totalJobs) { this.totalJobs = totalJobs; }

    public Integer getTotalInternships() { return totalInternships; }
    public void setTotalInternships(Integer totalInternships) { this.totalInternships = totalInternships; }

    public List<String> getTopLocations() { return topLocations; }
    public void setTopLocations(List<String> topLocations) { this.topLocations = topLocations; }

    public List<String> getTopRoles() { return topRoles; }
    public void setTopRoles(List<String> topRoles) { this.topRoles = topRoles; }

    public String getAverageStipend() { return averageStipend; }
    public void setAverageStipend(String averageStipend) { this.averageStipend = averageStipend; }
}
