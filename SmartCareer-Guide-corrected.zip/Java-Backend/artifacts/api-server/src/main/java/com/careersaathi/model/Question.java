package com.careersaathi.model;

import java.util.List;

public class Question {
    private Integer id;
    private String text;
    private String category;
    private List<QuestionOption> options;

    public Question() {}

    public Question(Integer id, String text, String category, List<QuestionOption> options) {
        this.id = id;
        this.text = text;
        this.category = category;
        this.options = options;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getText() { return text; }
    public void setText(String text) { this.text = text; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public List<QuestionOption> getOptions() { return options; }
    public void setOptions(List<QuestionOption> options) { this.options = options; }
}
