package com.careersaathi.model;

public class QuickStats {
    private Integer totalCareers;
    private Integer totalJobs;
    private Integer totalScholarships;
    private Integer totalInternships;

    public QuickStats() {}

    public QuickStats(Integer totalCareers, Integer totalJobs, Integer totalScholarships, Integer totalInternships) {
        this.totalCareers = totalCareers;
        this.totalJobs = totalJobs;
        this.totalScholarships = totalScholarships;
        this.totalInternships = totalInternships;
    }

    public Integer getTotalCareers() { return totalCareers; }
    public void setTotalCareers(Integer totalCareers) { this.totalCareers = totalCareers; }

    public Integer getTotalJobs() { return totalJobs; }
    public void setTotalJobs(Integer totalJobs) { this.totalJobs = totalJobs; }

    public Integer getTotalScholarships() { return totalScholarships; }
    public void setTotalScholarships(Integer totalScholarships) { this.totalScholarships = totalScholarships; }

    public Integer getTotalInternships() { return totalInternships; }
    public void setTotalInternships(Integer totalInternships) { this.totalInternships = totalInternships; }
}
