package com.careersaathi.model;

import java.util.List;

public class Roadmap {
    private Integer careerId;
    private String careerTitle;
    private List<RoadmapPhase> phases;

    public Roadmap() {}

    public Integer getCareerId() { return careerId; }
    public void setCareerId(Integer careerId) { this.careerId = careerId; }

    public String getCareerTitle() { return careerTitle; }
    public void setCareerTitle(String careerTitle) { this.careerTitle = careerTitle; }

    public List<RoadmapPhase> getPhases() { return phases; }
    public void setPhases(List<RoadmapPhase> phases) { this.phases = phases; }
}
