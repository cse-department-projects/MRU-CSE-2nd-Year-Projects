package com.careersaathi.model;

import java.util.List;

public class RoadmapPhase {
    private Integer id;
    private String title;
    private String duration;
    private List<RoadmapStep> steps;

    public RoadmapPhase() {}

    public RoadmapPhase(Integer id, String title, String duration, List<RoadmapStep> steps) {
        this.id = id;
        this.title = title;
        this.duration = duration;
        this.steps = steps;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDuration() { return duration; }
    public void setDuration(String duration) { this.duration = duration; }

    public List<RoadmapStep> getSteps() { return steps; }
    public void setSteps(List<RoadmapStep> steps) { this.steps = steps; }
}
