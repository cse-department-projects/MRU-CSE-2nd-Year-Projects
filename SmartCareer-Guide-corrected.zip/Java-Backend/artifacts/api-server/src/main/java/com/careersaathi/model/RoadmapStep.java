package com.careersaathi.model;

import java.util.List;

public class RoadmapStep {
    private Integer id;
    private String title;
    private String description;
    private List<String> resourceLinks;
    private Integer estimatedHours;
    private String difficulty;

    public RoadmapStep() {}

    public RoadmapStep(Integer id, String title, String description,
                       List<String> resourceLinks, Integer estimatedHours, String difficulty) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.resourceLinks = resourceLinks;
        this.estimatedHours = estimatedHours;
        this.difficulty = difficulty;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public List<String> getResourceLinks() { return resourceLinks; }
    public void setResourceLinks(List<String> resourceLinks) { this.resourceLinks = resourceLinks; }

    public Integer getEstimatedHours() { return estimatedHours; }
    public void setEstimatedHours(Integer estimatedHours) { this.estimatedHours = estimatedHours; }

    public String getDifficulty() { return difficulty; }
    public void setDifficulty(String difficulty) { this.difficulty = difficulty; }
}
