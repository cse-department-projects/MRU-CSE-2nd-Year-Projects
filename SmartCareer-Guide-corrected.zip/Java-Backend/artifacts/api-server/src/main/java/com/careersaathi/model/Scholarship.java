package com.careersaathi.model;

import java.util.List;

public class Scholarship {
    private Integer id;
    private String name;
    private String provider;
    private List<String> level;
    private List<String> categories;
    private String amount;
    private String description;
    private String eligibility;
    private String deadline;
    private String deadlineNote;
    private String applyUrl;
    private String state;

    public Scholarship() {}

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getProvider() { return provider; }
    public void setProvider(String provider) { this.provider = provider; }

    public List<String> getLevel() { return level; }
    public void setLevel(List<String> level) { this.level = level; }

    public List<String> getCategories() { return categories; }
    public void setCategories(List<String> categories) { this.categories = categories; }

    public String getAmount() { return amount; }
    public void setAmount(String amount) { this.amount = amount; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getEligibility() { return eligibility; }
    public void setEligibility(String eligibility) { this.eligibility = eligibility; }

    public String getDeadline() { return deadline; }
    public void setDeadline(String deadline) { this.deadline = deadline; }

    public String getDeadlineNote() { return deadlineNote; }
    public void setDeadlineNote(String deadlineNote) { this.deadlineNote = deadlineNote; }

    public String getApplyUrl() { return applyUrl; }
    public void setApplyUrl(String applyUrl) { this.applyUrl = applyUrl; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }
}
