package com.careersaathi.model;

import java.util.ArrayList;
import java.util.List;

public class StudentProfile {
    private String currentClass = "";
    private String stream = "";
    private List<String> interests = new ArrayList<>();
    private List<String> skills = new ArrayList<>();
    private List<String> goals = new ArrayList<>();

    public String getCurrentClass() { return currentClass; }
    public void setCurrentClass(String currentClass) { this.currentClass = currentClass; }

    public String getStream() { return stream; }
    public void setStream(String stream) { this.stream = stream; }

    public List<String> getInterests() { return interests; }
    public void setInterests(List<String> interests) { this.interests = interests; }

    public List<String> getSkills() { return skills; }
    public void setSkills(List<String> skills) { this.skills = skills; }

    public List<String> getGoals() { return goals; }
    public void setGoals(List<String> goals) { this.goals = goals; }
}
