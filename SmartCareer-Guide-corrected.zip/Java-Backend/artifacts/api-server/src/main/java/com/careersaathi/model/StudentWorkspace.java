package com.careersaathi.model;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class StudentWorkspace {
    private boolean exists;
    private StudentProfile profile = new StudentProfile();
    private Map<String, List<String>> roadmapProgress = new LinkedHashMap<>();
    private Map<String, List<String>> skillGapProgress = new LinkedHashMap<>();
    private String updatedAt;

    public boolean isExists() { return exists; }
    public void setExists(boolean exists) { this.exists = exists; }

    public StudentProfile getProfile() { return profile; }
    public void setProfile(StudentProfile profile) { this.profile = profile; }

    public Map<String, List<String>> getRoadmapProgress() { return roadmapProgress; }
    public void setRoadmapProgress(Map<String, List<String>> roadmapProgress) { this.roadmapProgress = roadmapProgress; }

    public Map<String, List<String>> getSkillGapProgress() { return skillGapProgress; }
    public void setSkillGapProgress(Map<String, List<String>> skillGapProgress) { this.skillGapProgress = skillGapProgress; }

    public String getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(String updatedAt) { this.updatedAt = updatedAt; }
}
