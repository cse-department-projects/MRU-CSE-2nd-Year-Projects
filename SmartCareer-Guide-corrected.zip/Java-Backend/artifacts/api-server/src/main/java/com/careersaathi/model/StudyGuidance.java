package com.careersaathi.model;

import java.util.ArrayList;
import java.util.List;

public class StudyGuidance {
    private String stage;
    private String title;
    private String overview;
    private List<String> streamOptions = new ArrayList<>();
    private List<String> courseOptions = new ArrayList<>();
    private List<Integer> entranceExamIds = new ArrayList<>();
    private List<String> higherEducationOptions = new ArrayList<>();
    private List<String> careerPaths = new ArrayList<>();
    private List<StudyLink> officialLinks = new ArrayList<>();

    public String getStage() { return stage; }
    public void setStage(String stage) { this.stage = stage; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getOverview() { return overview; }
    public void setOverview(String overview) { this.overview = overview; }

    public List<String> getStreamOptions() { return streamOptions; }
    public void setStreamOptions(List<String> streamOptions) { this.streamOptions = streamOptions; }

    public List<String> getCourseOptions() { return courseOptions; }
    public void setCourseOptions(List<String> courseOptions) { this.courseOptions = courseOptions; }

    public List<Integer> getEntranceExamIds() { return entranceExamIds; }
    public void setEntranceExamIds(List<Integer> entranceExamIds) { this.entranceExamIds = entranceExamIds; }

    public List<String> getHigherEducationOptions() { return higherEducationOptions; }
    public void setHigherEducationOptions(List<String> higherEducationOptions) { this.higherEducationOptions = higherEducationOptions; }

    public List<String> getCareerPaths() { return careerPaths; }
    public void setCareerPaths(List<String> careerPaths) { this.careerPaths = careerPaths; }

    public List<StudyLink> getOfficialLinks() { return officialLinks; }
    public void setOfficialLinks(List<StudyLink> officialLinks) { this.officialLinks = officialLinks; }
}
