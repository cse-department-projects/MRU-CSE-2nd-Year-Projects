package com.careersaathi.repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Map;

@Repository
public class AssessmentRepository {
    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper = new ObjectMapper();

    public AssessmentRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public int create(String userName, String currentClass, String studentStream, String preferredLanguage) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO assessments (user_name, current_class, student_stream, preferred_language, status) VALUES (?, ?, ?, ?, 'in_progress')",
                Statement.RETURN_GENERATED_KEYS
            );
            ps.setString(1, userName);
            ps.setString(2, currentClass);
            ps.setString(3, studentStream);
            ps.setString(4, preferredLanguage != null ? preferredLanguage : "english");
            return ps;
        }, keyHolder);
        Map<String, Object> keys = keyHolder.getKeys();
        return keys != null ? ((Number) keys.get("id")).intValue() : 0;
    }

    public void complete(int id, String resultJson) {
        jdbc.update(
            "UPDATE assessments SET status = 'completed', result = ?::jsonb WHERE id = ?",
            resultJson, id
        );
    }

    public Map<String, Object> findById(int id) {
        try {
            return jdbc.queryForMap("SELECT * FROM assessments WHERE id = ?", id);
        } catch (Exception e) {
            return null;
        }
    }
}
