package com.careersaathi.repository;

import com.careersaathi.model.Career;
import com.careersaathi.model.CareerDetail;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@Repository
public class CareerRepository {
    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper = new ObjectMapper();

    public CareerRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    private List<String> parseJson(String json) {
        try {
            if (json == null) return new ArrayList<>();
            return mapper.readValue(json, new TypeReference<List<String>>() {});
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    private RowMapper<Career> careerRowMapper() {
        return (rs, row) -> {
            Career c = new Career();
            c.setId(rs.getInt("id"));
            c.setTitle(rs.getString("title"));
            c.setCluster(rs.getString("cluster"));
            c.setStreams(parseJson(rs.getString("streams")));
            c.setSalaryRange(rs.getString("salary_range"));
            c.setDemandLevel(rs.getString("demand_level"));
            c.setDescription(rs.getString("description"));
            c.setIconEmoji(rs.getString("icon_emoji"));
            c.setTags(parseJson(rs.getString("tags")));
            c.setSkills(parseJson(rs.getString("skills")));
            return c;
        };
    }

    private RowMapper<CareerDetail> careerDetailRowMapper() {
        return (rs, row) -> {
            CareerDetail c = new CareerDetail();
            c.setId(rs.getInt("id"));
            c.setTitle(rs.getString("title"));
            c.setCluster(rs.getString("cluster"));
            c.setStreams(parseJson(rs.getString("streams")));
            c.setSalaryRange(rs.getString("salary_range"));
            c.setDemandLevel(rs.getString("demand_level"));
            c.setDescription(rs.getString("description"));
            c.setIconEmoji(rs.getString("icon_emoji"));
            c.setTags(parseJson(rs.getString("tags")));
            c.setSkills(parseJson(rs.getString("skills")));
            c.setEntryPaths(parseJson(rs.getString("entry_paths")));
            c.setLocalOpportunities(parseJson(rs.getString("local_opportunities")));
            double avg = rs.getDouble("average_salary_lpa");
            c.setAverageSalaryLPA(rs.wasNull() ? null : avg);
            c.setGrowthRate(rs.getString("growth_rate"));
            return c;
        };
    }

    public List<Career> findAll(String cluster, String stream, String search) {
        StringBuilder sql = new StringBuilder("SELECT * FROM careers WHERE 1=1");
        List<Object> params = new ArrayList<>();
        if (cluster != null && !cluster.isBlank()) {
            sql.append(" AND LOWER(cluster) = LOWER(?)");
            params.add(cluster);
        }
        if (stream != null && !stream.isBlank()) {
            sql.append(" AND streams::text ILIKE ?");
            params.add("%" + stream + "%");
        }
        if (search != null && !search.isBlank()) {
            sql.append(" AND (LOWER(title) LIKE LOWER(?) OR LOWER(description) LIKE LOWER(?))");
            params.add("%" + search + "%");
            params.add("%" + search + "%");
        }
        sql.append(" ORDER BY id");
        return jdbc.query(sql.toString(), careerRowMapper(), params.toArray());
    }

    public List<Career> findTrending() {
        return jdbc.query(
            "SELECT * FROM careers WHERE demand_level = 'high' ORDER BY id LIMIT 6",
            careerRowMapper()
        );
    }

    public CareerDetail findById(int id) {
        List<CareerDetail> results = jdbc.query(
            "SELECT * FROM careers WHERE id = ?", careerDetailRowMapper(), id
        );
        return results.isEmpty() ? null : results.get(0);
    }

    public List<Career> findByIds(List<Integer> ids) {
        if (ids.isEmpty()) return new ArrayList<>();
        String placeholders = String.join(",", ids.stream().map(i -> "?").toList());
        return jdbc.query(
            "SELECT * FROM careers WHERE id IN (" + placeholders + ") ORDER BY id",
            careerRowMapper(), ids.toArray()
        );
    }

    public int count() {
        Integer count = jdbc.queryForObject("SELECT COUNT(*) FROM careers", Integer.class);
        return count != null ? count : 0;
    }
}
