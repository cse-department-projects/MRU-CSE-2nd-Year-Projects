package com.careersaathi.repository;

import com.careersaathi.model.Course;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class CourseRepository {
    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper = new ObjectMapper();

    public CourseRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    private <T> List<T> parseJson(String json, TypeReference<List<T>> type) {
        try {
            if (json == null) return new ArrayList<>();
            return mapper.readValue(json, type);
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    private RowMapper<Course> mapper() {
        return (rs, row) -> {
            Course course = new Course();
            course.setId(rs.getInt("id"));
            course.setTitle(rs.getString("title"));
            course.setProvider(rs.getString("provider"));
            course.setCategory(rs.getString("category"));
            course.setLevel(rs.getString("level"));
            course.setSkills(parseJson(rs.getString("skills"), new TypeReference<List<String>>() {}));
            course.setDuration(rs.getString("duration"));
            course.setCost(rs.getString("cost"));
            course.setFormat(rs.getString("format"));
            course.setDescription(rs.getString("description"));
            course.setStreams(parseJson(rs.getString("streams"), new TypeReference<List<String>>() {}));
            course.setCareerIds(parseJson(rs.getString("career_ids"), new TypeReference<List<Integer>>() {}));
            course.setUrl(rs.getString("url"));
            return course;
        };
    }

    public List<Course> findAll(Integer careerId, String stream, String level, String search) {
        StringBuilder sql = new StringBuilder("SELECT * FROM courses WHERE 1=1");
        List<Object> params = new ArrayList<>();
        if (careerId != null) {
            sql.append(" AND career_ids::text LIKE ?");
            params.add("%" + careerId + "%");
        }
        if (stream != null && !stream.isBlank()) {
            sql.append(" AND (streams::text ILIKE ? OR streams::text ILIKE '%All%')");
            params.add("%" + stream + "%");
        }
        if (level != null && !level.isBlank()) {
            sql.append(" AND LOWER(level) = LOWER(?)");
            params.add(level);
        }
        if (search != null && !search.isBlank()) {
            sql.append(" AND (LOWER(title) LIKE LOWER(?) OR LOWER(category) LIKE LOWER(?) OR LOWER(description) LIKE LOWER(?))");
            String term = "%" + search + "%";
            params.add(term);
            params.add(term);
            params.add(term);
        }
        sql.append(" ORDER BY CASE level WHEN 'beginner' THEN 1 WHEN 'intermediate' THEN 2 ELSE 3 END, id");
        return jdbc.query(sql.toString(), mapper(), params.toArray());
    }
}