package com.careersaathi.repository;

import com.careersaathi.model.EntranceExam;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class EntranceExamRepository {
    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper = new ObjectMapper();

    public EntranceExamRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    private List<String> parseStrings(String json) {
        try {
            if (json == null) return new ArrayList<>();
            return mapper.readValue(json, new TypeReference<List<String>>() {});
        } catch (Exception e) {
            throw new IllegalStateException("Unable to read entrance exam data", e);
        }
    }

    private RowMapper<EntranceExam> rowMapper() {
        return (rs, row) -> {
            EntranceExam exam = new EntranceExam();
            exam.setId(rs.getInt("id"));
            exam.setName(rs.getString("name"));
            exam.setLevels(parseStrings(rs.getString("levels")));
            exam.setStreams(parseStrings(rs.getString("streams")));
            exam.setEligibility(rs.getString("eligibility"));
            exam.setDeadline(rs.getString("deadline"));
            exam.setDeadlineNote(rs.getString("deadline_note"));
            exam.setApplicationUrl(rs.getString("application_url"));
            exam.setConductingAuthority(rs.getString("conducting_authority"));
            return exam;
        };
    }

    public List<EntranceExam> findAll(String level, String stream, String search) {
        StringBuilder sql = new StringBuilder("SELECT * FROM entrance_exams WHERE 1=1");
        List<Object> params = new ArrayList<>();
        if (level != null && !level.isBlank()) {
            sql.append(" AND levels::text ILIKE ?");
            params.add("%" + level.trim() + "%");
        }
        if (stream != null && !stream.isBlank()) {
            sql.append(" AND streams::text ILIKE ?");
            params.add("%" + stream.trim() + "%");
        }
        if (search != null && !search.isBlank()) {
            sql.append(" AND (LOWER(name) LIKE LOWER(?) OR LOWER(eligibility) LIKE LOWER(?))");
            params.add("%" + search.trim() + "%");
            params.add("%" + search.trim() + "%");
        }
        sql.append(" ORDER BY id");
        return jdbc.query(sql.toString(), rowMapper(), params.toArray());
    }
}
