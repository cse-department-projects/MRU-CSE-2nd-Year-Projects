package com.careersaathi.repository;

import com.careersaathi.model.Job;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class JobRepository {
    private final JdbcTemplate jdbc;

    public JobRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    private RowMapper<Job> rowMapper() {
        return (rs, row) -> {
            Job j = new Job();
            j.setId(rs.getInt("id"));
            j.setTitle(rs.getString("title"));
            j.setCompany(rs.getString("company"));
            j.setType(rs.getString("type"));
            j.setLocation(rs.getString("location"));
            j.setRemote(rs.getBoolean("remote"));
            j.setStipend(rs.getString("stipend"));
            j.setDescription(rs.getString("description"));
            j.setEligibility(rs.getString("eligibility"));
            j.setApplyUrl(rs.getString("apply_url"));
            j.setDeadline(rs.getString("deadline"));
            j.setTrustScore(rs.getInt("trust_score"));
            return j;
        };
    }

    public List<Job> findAll(String type, String location, Boolean remote) {
        StringBuilder sql = new StringBuilder("SELECT * FROM jobs WHERE 1=1");
        List<Object> params = new ArrayList<>();
        if (type != null && !type.isBlank()) {
            sql.append(" AND type = ?");
            params.add(type);
        }
        if (location != null && !location.isBlank()) {
            sql.append(" AND LOWER(location) LIKE LOWER(?)");
            params.add("%" + location + "%");
        }
        if (remote != null) {
            sql.append(" AND remote = ?");
            params.add(remote);
        }
        sql.append(" ORDER BY trust_score DESC");
        return jdbc.query(sql.toString(), rowMapper(), params.toArray());
    }

    public int countByType(String type) {
        Integer count = jdbc.queryForObject(
            "SELECT COUNT(*) FROM jobs WHERE type = ?", Integer.class, type
        );
        return count != null ? count : 0;
    }

    public int count() {
        Integer count = jdbc.queryForObject("SELECT COUNT(*) FROM jobs", Integer.class);
        return count != null ? count : 0;
    }
}
