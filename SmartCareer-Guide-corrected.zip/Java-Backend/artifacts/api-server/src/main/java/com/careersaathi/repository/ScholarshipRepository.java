package com.careersaathi.repository;

import com.careersaathi.model.Scholarship;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class ScholarshipRepository {
    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper = new ObjectMapper();

    public ScholarshipRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    private List<String> parseJson(String json) {
        try {
            if (json == null) return new ArrayList<>();
            return mapper.readValue(json, new TypeReference<List<String>>() {});
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    private RowMapper<Scholarship> rowMapper() {
        return (rs, row) -> {
            Scholarship s = new Scholarship();
            s.setId(rs.getInt("id"));
            s.setName(rs.getString("name"));
            s.setProvider(rs.getString("provider"));
            s.setLevel(parseJson(rs.getString("level")));
            s.setCategories(parseJson(rs.getString("categories")));
            s.setAmount(rs.getString("amount"));
            s.setDescription(rs.getString("description"));
            s.setEligibility(rs.getString("eligibility"));
            s.setDeadline(rs.getString("deadline"));
            s.setDeadlineNote(rs.getString("deadline_note"));
            s.setApplyUrl(rs.getString("apply_url"));
            s.setState(rs.getString("state"));
            return s;
        };
    }

    public List<Scholarship> findAll(String category, String level, String state) {
        StringBuilder sql = new StringBuilder("SELECT * FROM scholarships WHERE 1=1");
        List<Object> params = new ArrayList<>();
        if (category != null && !category.isBlank()) {
            sql.append(" AND categories::text ILIKE ?");
            params.add("%" + category + "%");
        }
        if (level != null && !level.isBlank()) {
            sql.append(" AND level::text ILIKE ?");
            params.add("%" + level + "%");
        }
        if (state != null && !state.isBlank()) {
            sql.append(" AND (LOWER(state) = LOWER(?) OR state IS NULL)");
            params.add(state);
        }
        sql.append(" ORDER BY id");
        return jdbc.query(sql.toString(), rowMapper(), params.toArray());
    }

    public int count() {
        Integer count = jdbc.queryForObject("SELECT COUNT(*) FROM scholarships", Integer.class);
        return count != null ? count : 0;
    }
}
