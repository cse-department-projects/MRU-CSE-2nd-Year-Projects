package com.careersaathi.repository;

import com.careersaathi.model.StudentWorkspace;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
public class StudentWorkspaceRepository {
    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper = new ObjectMapper();

    public StudentWorkspaceRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public StudentWorkspace findByStudentId(String studentId) {
        List<StudentWorkspace> rows = jdbc.query(
            "SELECT workspace_json::text AS workspace_json, updated_at FROM student_workspaces WHERE student_id = ?",
            (rs, row) -> {
                try {
                    StudentWorkspace workspace = mapper.readValue(rs.getString("workspace_json"), StudentWorkspace.class);
                    Timestamp updatedAt = rs.getTimestamp("updated_at");
                    workspace.setExists(true);
                    workspace.setUpdatedAt(updatedAt == null ? null : updatedAt.toInstant().toString());
                    return workspace;
                } catch (Exception e) {
                    throw new IllegalStateException("Unable to read saved student progress", e);
                }
            },
            studentId
        );
        if (!rows.isEmpty()) return rows.get(0);
        return new StudentWorkspace();
    }

    public StudentWorkspace save(String studentId, StudentWorkspace workspace) {
        try {
            String payload = mapper.writeValueAsString(workspace);
            jdbc.update(
                "INSERT INTO student_workspaces (student_id, workspace_json, updated_at) VALUES (?, CAST(? AS jsonb), NOW()) " +
                    "ON CONFLICT (student_id) DO UPDATE SET workspace_json = EXCLUDED.workspace_json, updated_at = NOW()",
                studentId,
                payload
            );
            return findByStudentId(studentId);
        } catch (Exception e) {
            throw new IllegalStateException("Unable to save student progress", e);
        }
    }
}
