package com.careersaathi.repository;

import com.careersaathi.model.StudyGuidance;
import com.careersaathi.model.StudyLink;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class StudyGuidanceRepository {
    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper = new ObjectMapper();

    public StudyGuidanceRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    private List<String> parseStrings(String json) {
        try {
            if (json == null) return new ArrayList<>();
            return mapper.readValue(json, new TypeReference<List<String>>() {});
        } catch (Exception e) {
            throw new IllegalStateException("Unable to read study guidance data", e);
        }
    }

    private List<Integer> parseIntegers(String json) {
        try {
            if (json == null) return new ArrayList<>();
            return mapper.readValue(json, new TypeReference<List<Integer>>() {});
        } catch (Exception e) {
            throw new IllegalStateException("Unable to read study guidance exam references", e);
        }
    }

    private List<StudyLink> parseLinks(String json) {
        try {
            if (json == null) return new ArrayList<>();
            return mapper.readValue(json, new TypeReference<List<StudyLink>>() {});
        } catch (Exception e) {
            throw new IllegalStateException("Unable to read study guidance official links", e);
        }
    }

    private RowMapper<StudyGuidance> rowMapper() {
        return (rs, row) -> {
            StudyGuidance guidance = new StudyGuidance();
            guidance.setStage(rs.getString("stage"));
            guidance.setTitle(rs.getString("title"));
            guidance.setOverview(rs.getString("overview"));
            guidance.setStreamOptions(parseStrings(rs.getString("stream_options")));
            guidance.setCourseOptions(parseStrings(rs.getString("course_options")));
            guidance.setEntranceExamIds(parseIntegers(rs.getString("entrance_exam_ids")));
            guidance.setHigherEducationOptions(parseStrings(rs.getString("higher_education_options")));
            guidance.setCareerPaths(parseStrings(rs.getString("career_paths")));
            guidance.setOfficialLinks(parseLinks(rs.getString("official_links")));
            return guidance;
        };
    }

    public List<StudyGuidance> findAll(String stage) {
        if (stage == null || stage.isBlank()) {
            return jdbc.query("SELECT * FROM study_guidance ORDER BY CASE stage WHEN 'after-10th' THEN 1 WHEN 'after-12th' THEN 2 WHEN 'after-diploma' THEN 3 ELSE 4 END", rowMapper());
        }
        return jdbc.query("SELECT * FROM study_guidance WHERE stage = ?", rowMapper(), stage.trim().toLowerCase());
    }
}
