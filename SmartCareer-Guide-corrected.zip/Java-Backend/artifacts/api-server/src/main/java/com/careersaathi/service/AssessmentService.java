package com.careersaathi.service;

import com.careersaathi.model.*;
import com.careersaathi.repository.AssessmentRepository;
import com.careersaathi.repository.CareerRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class AssessmentService {
    private final AssessmentRepository repo;
    private final CareerRepository careerRepo;
    private final ObjectMapper mapper = new ObjectMapper();

    private static final List<Question> QUESTIONS = List.of(
        new Question(1, "When you solve a problem, which approach do you prefer?",
            "logical", List.of(
                new QuestionOption("a", "Break it into logical steps and analyze each part"),
                new QuestionOption("b", "Use data/numbers to find the best solution"),
                new QuestionOption("c", "Discuss with others and brainstorm ideas"),
                new QuestionOption("d", "Visualize the solution and sketch it out")
            )),
        new Question(2, "Which school subject excites you the most?",
            "interest", List.of(
                new QuestionOption("a", "Mathematics or Physics"),
                new QuestionOption("b", "Biology or Chemistry"),
                new QuestionOption("c", "Social Studies or Languages"),
                new QuestionOption("d", "Drawing, Craft or Music")
            )),
        new Question(3, "Imagine you have to build something. What would you build?",
            "spatial", List.of(
                new QuestionOption("a", "A useful app or computer program"),
                new QuestionOption("b", "A solution to a health or environment problem"),
                new QuestionOption("c", "A community center or school"),
                new QuestionOption("d", "A creative artwork or product design")
            )),
        new Question(4, "How do you prefer to spend your free time?",
            "interest", List.of(
                new QuestionOption("a", "Reading, coding, solving puzzles or quizzes"),
                new QuestionOption("b", "Experimenting, gardening, or researching"),
                new QuestionOption("c", "Volunteering, teaching, or talking with people"),
                new QuestionOption("d", "Creating art, music, writing, or crafts")
            )),
        new Question(5, "Which future goal resonates most with you?",
            "interest", List.of(
                new QuestionOption("a", "Work at a top tech company or start my own startup"),
                new QuestionOption("b", "Make a difference in healthcare or science"),
                new QuestionOption("c", "Teach, guide others, or work in government"),
                new QuestionOption("d", "Express myself through creative work and design")
            ))
    );

    private static final List<Question> MPC_QUESTIONS = List.of(
        new Question(1, "Which MPC project would you most enjoy taking on?",
            "interest", List.of(
                new QuestionOption("a", "Build an app, circuit, or technical tool and work out how it functions"),
                new QuestionOption("b", "Run an experiment and explain the science or mathematics behind the result"),
                new QuestionOption("c", "Organize a team to solve a practical problem for other people"),
                new QuestionOption("d", "Design a clear, attractive model that makes a complex idea easier to understand")
            )),
        new Question(2, "When a physics or mathematics problem feels difficult, what do you naturally do first?",
            "logical", List.of(
                new QuestionOption("a", "Break it into steps and test each part"),
                new QuestionOption("b", "Look for evidence, patterns, or a different experiment"),
                new QuestionOption("c", "Talk it through with classmates and share the solution"),
                new QuestionOption("d", "Draw a diagram or find a visual way to understand it")
            )),
        new Question(3, "Which technology topic would you choose for a deeper project?",
            "interest", List.of(
                new QuestionOption("a", "Software, robotics, or how computers work"),
                new QuestionOption("b", "Energy, materials, or how natural systems behave"),
                new QuestionOption("c", "How technology can improve schools or communities"),
                new QuestionOption("d", "How people interact with products, apps, and designed spaces")
            )),
        new Question(4, "In a science-fair team, which role would suit you best?",
            "social", List.of(
                new QuestionOption("a", "Build and test the working model"),
                new QuestionOption("b", "Research the evidence and check whether the results are reliable"),
                new QuestionOption("c", "Coordinate the team and present what the group learned"),
                new QuestionOption("d", "Create the diagrams, visuals, or demonstration")
            )),
        new Question(5, "What would make you proud of a future MPC-related career?",
            "interest", List.of(
                new QuestionOption("a", "Creating reliable technology that solves hard problems"),
                new QuestionOption("b", "Discovering something new through science or research"),
                new QuestionOption("c", "Using technical knowledge to help people and communities"),
                new QuestionOption("d", "Making useful ideas easier to use, see, or experience")
            ))
    );

    private static final List<Question> BIPC_QUESTIONS = List.of(
        new Question(1, "Which BiPC learning activity sounds most interesting to you?",
            "interest", List.of(
                new QuestionOption("a", "Use data and careful steps to understand how a treatment or process works"),
                new QuestionOption("b", "Investigate living systems, health, or the natural world"),
                new QuestionOption("c", "Explain health information and support people in making decisions"),
                new QuestionOption("d", "Create a clear visual guide about a science or health topic")
            )),
        new Question(2, "If you were exploring a health question, what would you most want to do?",
            "logical", List.of(
                new QuestionOption("a", "Compare measurements and look for a reliable pattern"),
                new QuestionOption("b", "Study the biological cause and check scientific evidence"),
                new QuestionOption("c", "Listen to people and understand how the issue affects them"),
                new QuestionOption("d", "Find a more engaging way to explain the issue to others")
            )),
        new Question(3, "Which project would you choose for a biology or chemistry assignment?",
            "interest", List.of(
                new QuestionOption("a", "Build a simple tool to organize observations or results"),
                new QuestionOption("b", "Study a plant, organism, medicine, or health process"),
                new QuestionOption("c", "Plan a community wellbeing or health-awareness activity"),
                new QuestionOption("d", "Make an illustrated science story or learning resource")
            )),
        new Question(4, "What would you do when an experiment gives an unexpected result?",
            "logical", List.of(
                new QuestionOption("a", "Check the steps and repeat the measurements carefully"),
                new QuestionOption("b", "Research possible biological or chemical explanations"),
                new QuestionOption("c", "Ask the group what they noticed and compare observations"),
                new QuestionOption("d", "Show the result in a new diagram or model to see it differently")
            )),
        new Question(5, "What impact would you most like a future science or health career to have?",
            "interest", List.of(
                new QuestionOption("a", "Improve systems that make health services more accurate"),
                new QuestionOption("b", "Advance knowledge about health, life, or the environment"),
                new QuestionOption("c", "Help people directly through care, teaching, or outreach"),
                new QuestionOption("d", "Make important science easier for everyone to understand")
            ))
    );

    private static final List<Question> SCIENCE_QUESTIONS = List.of(
        new Question(1, "Which science project would you most enjoy?",
            "interest", List.of(
                new QuestionOption("a", "Build a tool or model to organize and analyze results"),
                new QuestionOption("b", "Investigate a scientific question and test an explanation"),
                new QuestionOption("c", "Work with others to explain how science affects people"),
                new QuestionOption("d", "Create a clear visual model of a scientific idea")
            )),
        new Question(2, "When reading a research result, what do you most want to check?",
            "logical", List.of(
                new QuestionOption("a", "The data, calculations, and method used"),
                new QuestionOption("b", "The evidence and whether the conclusion follows from it"),
                new QuestionOption("c", "How the finding could be communicated and applied"),
                new QuestionOption("d", "A different way to represent or explain the result")
            )),
        new Question(3, "Which part of a science investigation would you choose?",
            "interest", List.of(
                new QuestionOption("a", "Set up a reliable way to collect and compare data"),
                new QuestionOption("b", "Explore a research question in depth"),
                new QuestionOption("c", "Coordinate a group and share findings with an audience"),
                new QuestionOption("d", "Design the diagrams, model, or presentation")
            )),
        new Question(4, "What do you do when two sources disagree about a scientific topic?",
            "logical", List.of(
                new QuestionOption("a", "Compare their data and methods step by step"),
                new QuestionOption("b", "Look for stronger evidence and additional research"),
                new QuestionOption("c", "Discuss the disagreement and explain it in plain language"),
                new QuestionOption("d", "Create a visual comparison that makes the claims easier to assess")
            )),
        new Question(5, "What impact would you most want from a science career?",
            "interest", List.of(
                new QuestionOption("a", "Develop accurate tools and systems for scientific work"),
                new QuestionOption("b", "Discover reliable knowledge that answers important questions"),
                new QuestionOption("c", "Help people use science to make informed decisions"),
                new QuestionOption("d", "Make complex discoveries understandable and engaging")
            ))
    );

    private static final List<Question> COMMERCE_QUESTIONS = List.of(
        new Question(1, "Which Commerce project would you most enjoy?",
            "interest", List.of(
                new QuestionOption("a", "Analyze a company’s numbers and explain what they mean"),
                new QuestionOption("b", "Research a market and test why customers make certain choices"),
                new QuestionOption("c", "Create a business idea and persuade a team to work on it"),
                new QuestionOption("d", "Build a brand story and design how a product is presented")
            )),
        new Question(2, "When comparing two business ideas, what do you naturally look at first?",
            "logical", List.of(
                new QuestionOption("a", "The budget, risks, and evidence behind each option"),
                new QuestionOption("b", "The research, customer needs, and trends that could shape them"),
                new QuestionOption("c", "The people involved and how to bring them together"),
                new QuestionOption("d", "The original angle that could make one idea stand out")
            )),
        new Question(3, "Which task would you choose during a student business challenge?",
            "interest", List.of(
                new QuestionOption("a", "Prepare the spreadsheet and track the project’s progress"),
                new QuestionOption("b", "Interview customers and summarize what the research shows"),
                new QuestionOption("c", "Coordinate the team and present the pitch"),
                new QuestionOption("d", "Create the name, visuals, and story for the idea")
            )),
        new Question(4, "A small project is over budget. What is your first move?",
            "logical", List.of(
                new QuestionOption("a", "Review the figures and identify where the gap started"),
                new QuestionOption("b", "Find out what changed and gather more information"),
                new QuestionOption("c", "Talk with the team and agree on a practical plan"),
                new QuestionOption("d", "Rework the idea so it can succeed with fewer resources")
            )),
        new Question(5, "Which future Commerce achievement would feel most meaningful?",
            "interest", List.of(
                new QuestionOption("a", "Make sound financial decisions using clear evidence"),
                new QuestionOption("b", "Understand markets and help organizations adapt"),
                new QuestionOption("c", "Lead a team or build a useful business"),
                new QuestionOption("d", "Create a distinctive brand, product, or customer experience")
            ))
    );

    private static final List<Question> ARTS_QUESTIONS = List.of(
        new Question(1, "Which Arts or Humanities project would you most enjoy?",
            "interest", List.of(
                new QuestionOption("a", "Organize information and uncover patterns in a history or social topic"),
                new QuestionOption("b", "Research how people, cultures, or communities change"),
                new QuestionOption("c", "Teach, advocate, or bring people together around an issue"),
                new QuestionOption("d", "Create a story, artwork, film, or design that communicates an idea")
            )),
        new Question(2, "When you read about a social issue, what do you most want to do?",
            "logical", List.of(
                new QuestionOption("a", "Compare sources and build a clear, evidence-based explanation"),
                new QuestionOption("b", "Investigate the history and causes behind it"),
                new QuestionOption("c", "Talk with people affected and find a constructive response"),
                new QuestionOption("d", "Express the issue in a form that makes people notice it")
            )),
        new Question(3, "Which class activity would you choose?",
            "interest", List.of(
                new QuestionOption("a", "Analyze a text, argument, or collection of historical evidence"),
                new QuestionOption("b", "Explore why people think and behave in different ways"),
                new QuestionOption("c", "Lead a discussion, event, or community activity"),
                new QuestionOption("d", "Write, perform, illustrate, or design something original")
            )),
        new Question(4, "How would you respond to a difficult question with no simple answer?",
            "logical", List.of(
                new QuestionOption("a", "Separate facts from assumptions and structure an argument"),
                new QuestionOption("b", "Research different perspectives before drawing a conclusion"),
                new QuestionOption("c", "Listen to people with different experiences and find common ground"),
                new QuestionOption("d", "Use a creative work to explore the different sides of the question")
            )),
        new Question(5, "What would make an Arts or Humanities career feel worthwhile?",
            "interest", List.of(
                new QuestionOption("a", "Make complex information clear and useful"),
                new QuestionOption("b", "Help society better understand people and change"),
                new QuestionOption("c", "Support, teach, or represent people and communities"),
                new QuestionOption("d", "Create work that moves people or changes how they see something")
            ))
    );

    private static final Map<String, PersonalityProfile> PROFILES = new HashMap<>();

    static {
        PROFILES.put("a", new PersonalityProfile(
            "ANALYTICAL_BUILDER",
            "Analytical Builder",
            "You think logically, love solving complex problems, and enjoy building systems and technology. You're drawn to precision and efficiency.",
            List.of("Technology", "Engineering", "Finance"),
            List.of(1, 2, 6, 9), // career IDs
            List.of("Problem solving", "Logical thinking", "Attention to detail", "Technical aptitude")
        ));
        PROFILES.put("b", new PersonalityProfile(
            "SCIENTIFIC_HEALER",
            "Scientific Healer",
            "You're driven by curiosity about the natural world and a desire to improve lives. You combine analytical thinking with empathy.",
            List.of("Healthcare", "Science", "Biotechnology"),
            List.of(4, 10, 6),
            List.of("Scientific curiosity", "Empathy", "Research skills", "Attention to detail")
        ));
        PROFILES.put("c", new PersonalityProfile(
            "SOCIAL_LEADER",
            "Social Leader",
            "You're a natural communicator who thrives on connecting with people and making a positive impact on communities.",
            List.of("Education", "Business", "Government"),
            List.of(7, 8, 5),
            List.of("Communication", "Leadership", "Empathy", "Organization")
        ));
        PROFILES.put("d", new PersonalityProfile(
            "CREATIVE_VISIONARY",
            "Creative Visionary",
            "You see the world through a creative lens and want to express ideas through art, design, or storytelling.",
            List.of("Design", "Media", "Business"),
            List.of(8, 7, 2),
            List.of("Creativity", "Visual thinking", "Innovation", "Expression")
        ));
    }

    public AssessmentService(AssessmentRepository repo, CareerRepository careerRepo) {
        this.repo = repo;
        this.careerRepo = careerRepo;
    }

    public Assessment startAssessment(AssessmentInput input) {
        int id = repo.create(input.getUserName(), input.getCurrentClass(), input.getStudentStream(), input.getPreferredLanguage());
        Assessment assessment = new Assessment();
        assessment.setId(id);
        assessment.setUserName(input.getUserName());
        assessment.setStatus("in_progress");
        assessment.setQuestions(questionsForStream(input.getStudentStream()));
        return assessment;
    }

    public Assessment getAssessment(int id) {
        Map<String, Object> row = repo.findById(id);
        if (row == null) return null;
        Assessment assessment = new Assessment();
        assessment.setId(id);
        assessment.setUserName((String) row.get("user_name"));
        assessment.setStatus((String) row.get("status"));
        assessment.setQuestions(questionsForStream((String) row.get("student_stream")));
        return assessment;
    }

    private List<Question> questionsForStream(String stream) {
        if (stream == null || stream.isBlank() || stream.equalsIgnoreCase("Not decided yet")) return QUESTIONS;
        String normalized = stream.toLowerCase(Locale.ROOT);
        if (normalized.contains("mpc")) return MPC_QUESTIONS;
        if (normalized.contains("bipc") || normalized.contains("medical") || normalized.contains("health")
            || normalized.contains("agriculture") || normalized.contains("veterinary")) return BIPC_QUESTIONS;
        if (normalized.contains("commerce") || normalized.contains("management") || normalized.contains("bba")
            || normalized.contains("bca")) return COMMERCE_QUESTIONS;
        if (normalized.contains("arts") || normalized.contains("humanities") || normalized.contains("law")
            || normalized.contains("design") || normalized.contains("media") || normalized.contains("education")) return ARTS_QUESTIONS;
        if (normalized.contains("science")) return SCIENCE_QUESTIONS;
        if (normalized.contains("engineering") || normalized.contains("technology") || normalized.contains("technical")) return MPC_QUESTIONS;
        return QUESTIONS;
    }

    public AssessmentResult submitAssessment(int id, AssessmentSubmission submission) {
        Map<String, Long> counts = new HashMap<>();
        counts.put("a", 0L);
        counts.put("b", 0L);
        counts.put("c", 0L);
        counts.put("d", 0L);

        if (submission.getAnswers() != null) {
            for (AssessmentSubmission.Answer ans : submission.getAnswers()) {
                String opt = ans.getOptionId();
                counts.merge(opt, 1L, Long::sum);
            }
        }

        String dominant = counts.entrySet().stream()
            .max(Map.Entry.comparingByValue())
            .map(Map.Entry::getKey)
            .orElse("a");

        PersonalityProfile profile = PROFILES.getOrDefault(dominant, PROFILES.get("a"));

        List<Career> topCareers = careerRepo.findByIds(profile.careerIds);

        AssessmentResult result = new AssessmentResult();
        result.setPersonalityType(profile.type);
        result.setPersonalityLabel(profile.label);
        result.setDescription(profile.description);
        result.setCareerClusters(profile.clusters);
        result.setTopCareers(topCareers);
        result.setStrengths(profile.strengths);

        try {
            repo.complete(id, mapper.writeValueAsString(result));
        } catch (Exception e) {
            // log error
        }

        return result;
    }

    private record PersonalityProfile(
        String type,
        String label,
        String description,
        List<String> clusters,
        List<Integer> careerIds,
        List<String> strengths
    ) {}
}
