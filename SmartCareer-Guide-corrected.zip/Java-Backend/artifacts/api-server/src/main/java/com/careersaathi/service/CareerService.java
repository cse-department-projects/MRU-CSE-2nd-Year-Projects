package com.careersaathi.service;

import com.careersaathi.model.Career;
import com.careersaathi.model.CareerDetail;
import com.careersaathi.model.CareerRecommendation;
import com.careersaathi.repository.CareerRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CareerService {
    private final CareerRepository repo;

    public CareerService(CareerRepository repo) {
        this.repo = repo;
    }

    public List<Career> listCareers(String cluster, String stream, String search) {
        return repo.findAll(cluster, stream, search);
    }

    public List<Career> getTrendingCareers() {
        return repo.findTrending();
    }

    public CareerDetail getCareer(int id) {
        return repo.findById(id);
    }

    public List<CareerRecommendation> getRecommendations(
        String currentClass, String stream, List<String> interests, List<String> skills, List<String> goals
    ) {
        List<String> normalizedInterests = cleanList(interests);
        List<String> normalizedSkills = cleanList(skills);
        List<String> normalizedGoals = cleanList(goals);
        String normalizedStream = normalize(stream);

        return repo.findAll(null, null, null).stream()
            .map(career -> {
                CareerDetail detail = repo.findById(career.getId());
                if (detail == null) return null;
                return scoreCareer(detail, currentClass, normalizedStream, normalizedInterests, normalizedSkills, normalizedGoals);
            })
            .filter(recommendation -> recommendation != null)
            .sorted((a, b) -> {
                int byScore = Integer.compare(b.getMatchPercentage(), a.getMatchPercentage());
                if (byScore != 0) return byScore;
                return a.getCareer().getTitle().compareToIgnoreCase(b.getCareer().getTitle());
            })
            .limit(3)
            .toList();
    }

    private CareerRecommendation scoreCareer(
        CareerDetail career, String currentClass, String stream, List<String> interests,
        List<String> skills, List<String> goals
    ) {
        List<String> careerStreams = career.getStreams() == null ? List.of() : career.getStreams();
        List<String> requiredSkills = career.getSkills() == null ? List.of() : career.getSkills();
        List<String> tags = career.getTags() == null ? List.of() : career.getTags();
        String careerText = normalize(String.join(" ",
            career.getTitle(), career.getCluster(), career.getDescription(),
            String.join(" ", tags), String.join(" ", requiredSkills)));

        int streamScore = stream.isBlank()
            ? 0
            : careerStreams.stream().map(CareerService::normalize).filter(candidate -> !candidate.isBlank()).anyMatch(candidate ->
                candidate.equals(stream) || candidate.contains(stream) || stream.contains(candidate))
                ? 25 : 4;
        int educationScore = educationScore(currentClass, career.getEntryPaths());

        List<String> matchedInterests = interests.stream()
            .filter(interest -> matchesPreference(interest, careerText))
            .toList();
        int interestScore = interests.isEmpty() ? 0 : (int) Math.round(25.0 * matchedInterests.size() / interests.size());

        List<String> matchedSkills = requiredSkills.stream()
            .filter(required -> skills.stream().anyMatch(studentSkill -> sameSkill(required, studentSkill)))
            .toList();
        int skillScore = skills.isEmpty() || requiredSkills.isEmpty()
            ? 0
            : (int) Math.round(20.0 * matchedSkills.size() / requiredSkills.size());

        List<String> matchedGoals = goals.stream()
            .filter(goal -> goalMatches(goal, career, careerText))
            .toList();
        int goalScore = goals.isEmpty() ? 0 : (int) Math.round(10.0 * matchedGoals.size() / goals.size());

        CareerRecommendation recommendation = new CareerRecommendation();
        recommendation.setCareer(career);
        recommendation.setMatchPercentage(Math.max(0, Math.min(100, streamScore + educationScore + interestScore + skillScore + goalScore)));
        recommendation.setMatchedSkills(matchedSkills);
        recommendation.setMissingSkills(requiredSkills.stream()
            .filter(required -> skills.stream().noneMatch(studentSkill -> sameSkill(required, studentSkill)))
            .limit(8)
            .toList());

        List<String> reasons = new java.util.ArrayList<>();
        if (educationScore >= 15 && career.getEntryPaths() != null && !career.getEntryPaths().isEmpty()) {
            reasons.add("There is an education route from your current level, including " + career.getEntryPaths().get(0) + ".");
        }
        if (streamScore == 25) reasons.add("Your selected stream is listed for this career.");
        if (!matchedInterests.isEmpty()) reasons.add("It connects with your interest in " + matchedInterests.get(0) + ".");
        if (!matchedSkills.isEmpty()) reasons.add("You already list " + matchedSkills.get(0) + ", a skill used in this field.");
        if (!matchedGoals.isEmpty()) reasons.add("It supports your goal of " + matchedGoals.get(0).toLowerCase() + ".");
        if (reasons.isEmpty()) {
            reasons.add("This is one of the career paths available in the career guide.");
        }
        if (interests.isEmpty() || skills.isEmpty() || goals.isEmpty()) {
            reasons.add("Add your interests, skills, and goals to make this estimate more personal.");
        }
        recommendation.setReasons(reasons);
        return recommendation;
    }

    private int educationScore(String currentClass, List<String> entryPaths) {
        String level = normalize(currentClass);
        if (level.isBlank()) return 0;
        String paths = entryPaths == null ? "" : normalize(String.join(" ", entryPaths));
        if (level.contains("diploma")) {
            return paths.contains("diploma") || paths.contains("lateral") ? 20 : 6;
        }
        if (level.contains("post graduate") || level.equals("pg") || level.contains("graduate")) {
            return 20;
        }
        if (level.contains("degree") || level.contains("college") || level.contains("ug")) {
            return 18;
        }
        if (level.contains("class 12") || level.contains("inter")) {
            return paths.contains("class 12") || paths.contains("after 12") || paths.contains("b ")
                || paths.contains("b.") || paths.contains("degree") || paths.contains("foundation")
                ? 20 : 12;
        }
        if (level.contains("class 10") || level.contains("ssc") || level.contains("after 10")) {
            return paths.contains("diploma") || paths.contains("class 10") ? 16 : 10;
        }
        return 12;
    }

    private boolean goalMatches(String goal, CareerDetail career, String careerText) {
        String normalizedGoal = normalize(goal);
        if (normalizedGoal.contains("high earning") || normalizedGoal.contains("financial growth")) {
            return career.getAverageSalaryLPA() != null && career.getAverageSalaryLPA() >= 10.0;
        }
        if (normalizedGoal.contains("stable")) {
            return containsAny(careerText, List.of("government", "public service", "teacher", "education", "healthcare"));
        }
        if (normalizedGoal.contains("help people")) {
            return containsAny(careerText, List.of("health", "patient", "education", "community", "public service", "care"));
        }
        if (normalizedGoal.contains("creative")) {
            return containsAny(careerText, List.of("design", "media", "marketing", "content", "visual", "creator"));
        }
        if (normalizedGoal.contains("business")) {
            return containsAny(careerText, List.of("business", "entrepreneur", "startup", "management", "marketing"));
        }
        if (normalizedGoal.contains("research")) {
            return containsAny(careerText, List.of("research", "science", "agricultural", "data", "ai", "analyst"));
        }
        if (normalizedGoal.contains("public service")) {
            return containsAny(careerText, List.of("government", "public", "law", "policy", "teacher"));
        }
        return matchesPreference(goal, careerText);
    }

    private boolean matchesPreference(String preference, String careerText) {
        String value = normalize(preference);
        List<String> terms;
        if (value.contains("technology") || value.contains("coding")) {
            terms = List.of("technology", "tech", "software", "coding", "programming", "ai", "computer", "cybersecurity");
        } else if (value.contains("health") || value.contains("biology")) {
            terms = List.of("health", "biology", "medical", "medicine", "patient", "pharma", "care");
        } else if (value.contains("engineering") || value.contains("building")) {
            terms = List.of("engineering", "engineer", "construction", "building", "infrastructure", "technical");
        } else if (value.contains("finance") || value.contains("numbers")) {
            terms = List.of("finance", "accounting", "financial", "tax", "audit", "analytics", "statistics");
        } else if (value.contains("business") || value.contains("entrepreneur")) {
            terms = List.of("business", "entrepreneur", "startup", "marketing", "management", "commerce");
        } else if (value.contains("teach") || value.contains("mentor")) {
            terms = List.of("education", "teaching", "teacher", "mentor", "learning");
        } else if (value.contains("law") || value.contains("public")) {
            terms = List.of("law", "legal", "public service", "policy", "government");
        } else if (value.contains("design") || value.contains("media")) {
            terms = List.of("design", "media", "visual", "creative", "content", "marketing");
        } else if (value.contains("agriculture") || value.contains("environment")) {
            terms = List.of("agriculture", "agricultural", "environment", "food", "crop", "veterinary");
        } else if (value.contains("science") || value.contains("research")) {
            terms = List.of("science", "research", "scientist", "biology", "data", "ai");
        } else {
            terms = List.of(value);
        }
        return containsAny(careerText, terms);
    }

    private boolean containsAny(String text, List<String> terms) {
        return terms.stream().map(CareerService::normalize).filter(term -> term.length() > 2)
            .anyMatch(text::contains);
    }

    private boolean sameSkill(String required, String selected) {
        String a = normalize(required);
        String b = normalize(selected);
        return !a.isBlank() && (a.equals(b) || (Math.min(a.length(), b.length()) >= 5 && (a.contains(b) || b.contains(a))));
    }

    private List<String> cleanList(List<String> values) {
        if (values == null) return List.of();
        return values.stream()
            .filter(value -> value != null && !value.isBlank())
            .map(String::trim)
            .distinct()
            .limit(30)
            .toList();
    }

    private static String normalize(String value) {
        if (value == null) return "";
        return value.toLowerCase(java.util.Locale.ROOT)
            .replaceAll("[^a-z0-9 ]", " ")
            .replaceAll("\\s+", " ")
            .trim();
    }

    public int count() {
        return repo.count();
    }
}
