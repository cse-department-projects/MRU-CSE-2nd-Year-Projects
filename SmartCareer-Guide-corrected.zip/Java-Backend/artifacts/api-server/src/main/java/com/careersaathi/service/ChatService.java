package com.careersaathi.service;

import com.careersaathi.model.Career;
import com.careersaathi.model.ChatMessage;
import com.careersaathi.model.ChatResponse;
import com.careersaathi.repository.CareerRepository;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ChatService {
    private final CareerRepository careerRepo;
    private final JdbcTemplate jdbc;

    public ChatService(CareerRepository careerRepo, JdbcTemplate jdbc) {
        this.careerRepo = careerRepo;
        this.jdbc = jdbc;
    }

    public ChatResponse chat(String message, String sessionId, String language,
                             String studentName, String studentClass,
                             String studentStream, String studentDistrict) {
        if (sessionId == null || sessionId.isBlank()) {
            sessionId = UUID.randomUUID().toString();
            jdbc.update("INSERT INTO chat_sessions (id) VALUES (?) ON CONFLICT DO NOTHING", sessionId);
        }

        jdbc.update("INSERT INTO chat_messages (session_id, role, content) VALUES (?, 'user', ?)", sessionId, message);

        String lang = (language != null) ? language.toLowerCase() : "english";
        String responseText = generateResponse(message, lang, studentName, studentClass, studentStream, studentDistrict);

        jdbc.update("INSERT INTO chat_messages (session_id, role, content) VALUES (?, 'assistant', ?)", sessionId, responseText);

        ChatResponse response = new ChatResponse();
        response.setMessage(responseText);
        response.setSessionId(sessionId);
        response.setSuggestedQuestions(getSuggestedQuestions(message, studentStream, lang));
        response.setRelatedCareers(getRelatedCareers(message, studentStream));
        return response;
    }

    private String firstName(String name) {
        if (name == null || name.isBlank()) return null;
        return name.trim().split("\\s+")[0];
    }

    private String generateResponse(String message, String lang,
                                    String name, String cls, String stream, String district) {
        String lower = message.toLowerCase();
        String fn = firstName(name);
        String loc = (district != null && !district.isBlank() && !district.equals("Outside Telangana")) ? district : "Hyderabad";

        // ══════════════════════════════════════════════
        // TELUGU RESPONSES
        // ══════════════════════════════════════════════
        if ("telugu".equals(lang)) {
            String addr = fn != null ? fn + "! " : "";

            if (lower.contains("after 12th") || lower.contains("12 tarvata") || lower.contains("inter tarvata")
                    || lower.contains("emi cheyali") || lower.contains("options") || lower.contains("what to do")) {
                if (stream != null && stream.contains("MPC")) {
                    return "అద్భుతమైన ప్రశ్న, " + addr + "MPC విద్యార్థిగా మీకు ఉన్న అత్యుత్తమ ఆప్షన్లు:\n\n" +
                        "1. B.Tech / B.E. — EAMCET ద్వారా (తెలంగాణ ఇంజనీరింగ్ ప్రవేశ పరీక్ష)\n" +
                        "   - టాప్ బ్రాంచ్‌లు: CSE, ECE, Mechanical, Civil\n" +
                        "   - టాప్ కళాశాలలు: JNTUH, CBIT, MGIT, VNRVJIET\n\n" +
                        "2. B.Sc (Mathematics/Physics) — పరిశోధన లేదా బోధన కోసం\n\n" +
                        "3. JEE Mains/Advanced — IIT, NIT, IIIT ల కోసం\n" +
                        "   - IIIT హైదరాబాద్ CSE కోసం అత్యుత్తమం\n\n" +
                        "4. NDA — సైన్యం/నౌకాదళం/వాయుసేనకు ఆసక్తి ఉంటే\n\n" +
                        "TS ePass స్కాలర్‌షిప్ కోసం epass.telangana.gov.in లో దరఖాస్తు చేయండి!";
                }
                if (stream != null && stream.contains("BiPC")) {
                    return "BiPC తర్వాత మీకు ఉన్న అవకాశాలు, " + addr + "\n\n" +
                        "1. MBBS — NEET ద్వారా (neet.nta.nic.in లో రిజిస్ట్రేషన్)\n" +
                        "   - తెలంగాణలో ప్రభుత్వ మెడికల్ కళాశాలలు:\n" +
                        "     ఉస్మానియా మెడికల్ కళాశాల, గాంధీ మెడికల్ కళాశాల, కాకతీయ మెడికల్ కళాశాల\n\n" +
                        "2. B.Pharm / D.Pharm — మంచి జీతం, తక్కువ వ్యవధి\n\n" +
                        "3. B.Sc Nursing — ఆసుపత్రులలో అధిక డిమాండ్\n\n" +
                        "4. B.Sc Agriculture — PJTSAU హైదరాబాద్‌లో అందిస్తుంది\n\n" +
                        "TS ePass స్కాలర్‌షిప్ ప్రభుత్వ మెడికల్ కళాశాల ఫీజులను కవర్ చేస్తుంది!";
                }
                return "12వ తర్వాత మీ ఆప్షన్లు స్ట్రీమ్ మీద ఆధారపడతాయి:\n\n" +
                    "Science (MPC): B.Tech EAMCET ద్వారా, JEE IIT/NIT కోసం\n" +
                    "Science (BiPC): MBBS NEET ద్వారా, B.Pharm, B.Sc Nursing\n" +
                    "Commerce: B.Com, BBA, CA Foundation, IBPS Banking\n" +
                    "Arts: BA, LLB, Journalism, UPSC/TSPSC Civil Services\n\n" +
                    "TS ePass స్కాలర్‌షిప్ కోసం September 30 కి ముందు దరఖాస్తు చేయండి!";
            }

            if (lower.contains("scholarship") || lower.contains("epass") || lower.contains("fee") || lower.contains("స్కాలర్")) {
                return "అద్భుతమైన ప్రశ్న, " + addr + "తెలంగాణలో అందుబాటులో ఉన్న స్కాలర్‌షిప్‌లు:\n\n" +
                    "1. TS ePass — SC/ST/BC/EWS విద్యార్థులకు. పూర్తి ట్యూషన్ + నిర్వహణ ఖర్చులు\n" +
                    "   దరఖాస్తు: epass.telangana.gov.in | గడువు: సెప్టెంబర్ 30\n\n" +
                    "2. PM Yasasvi — OBC/EBC విద్యార్థులకు (₹75,000–1,25,000/సంవత్సరం)\n\n" +
                    "3. PMKVY — ఉచిత నైపుణ్య శిక్షణ + ₹8,000 బహుమతి\n\n" +
                    "4. Vidyalakshmi — PSB బ్యాంకుల నుండి ₹10 లక్షల వరకు విద్యా రుణాలు\n\n" +
                    "త్వరగా దరఖాస్తు చేయండి! TS ePass గడువు సాధారణంగా సెప్టెంబర్ 30.";
            }

            if (lower.contains("software") || lower.contains("coding") || lower.contains("programming") || lower.contains("it")) {
                return "Software/IT " + loc + "లో అత్యుత్తమ కెరీర్ ఎంపిక! " + addr + "మీ రోడ్‌మ్యాప్:\n\n" +
                    "1. Python లేదా Java నేర్చుకోండి (NPTEL, YouTube లో ఉచితంగా)\n" +
                    "2. Data Structures & Algorithms అభ్యసించండి\n" +
                    "3. GitHub లో 2-3 ప్రాజెక్టులు నిర్మించండి\n" +
                    "4. Internshala, TCS iON లో ఇంటర్న్‌షిప్ చేయండి\n" +
                    "5. HITEC City కంపెనీలలో campus placements కోసం సిద్ధం అవ్వండి\n\n" +
                    loc + "లో టాప్ కంపెనీలు: TCS, Infosys, Microsoft, Google, Amazon, Wipro\n" +
                    "Fresher జీతం: 3.5–6 LPA | అనుభవజ్ఞులు: 15–30 LPA";
            }

            if (lower.contains("doctor") || lower.contains("mbbs") || lower.contains("neet") || lower.contains("medical")) {
                return "MBBS ఒక గొప్ప కెరీర్. " + addr + "\n\n" +
                    "ప్రవేశ పరీక్ష: NEET UG — neet.nta.nic.in లో రిజిస్ట్రేషన్\n" +
                    "వ్యవధి: 5.5 సంవత్సరాలు (4.5 MBBS + 1 ఇంటర్న్‌షిప్)\n\n" +
                    "తెలంగాణలో ప్రభుత్వ మెడికల్ కళాశాలలు:\n" +
                    "- ఉస్మానియా మెడికల్ కళాశాల, హైదరాబాద్\n" +
                    "- గాంధీ మెడికల్ కళాశాల, హైదరాబాద్\n" +
                    "- కాకతీయ మెడికల్ కళాశాల, వరంగల్\n\n" +
                    "ఫీజులు: ప్రభుత్వ కళాశాలలు: ₹15,000–30,000/సంవత్సరం\n" +
                    "TS ePass స్కాలర్‌షిప్ ఫీజులను కవర్ చేయగలదు!";
            }

            if (lower.contains("government") || lower.contains("sarkari") || lower.contains("tspsc") || lower.contains("upsc") || lower.contains("ప్రభుత్వ")) {
                return "ప్రభుత్వ ఉద్యోగాలు గొప్ప స్థిరత్వాన్ని అందిస్తాయి! " + addr + "\n\n" +
                    "రాష్ట్ర స్థాయి (TSPSC): Group-1, Group-2, Group-3 పరీక్షలు\n" +
                    "కేంద్ర స్థాయి: UPSC Civil Services (IAS/IPS), SSC, IBPS Banking\n" +
                    "బోధన: DSC ద్వారా పాఠశాల ఉపాధ్యాయులు\n" +
                    "పోలీసు: TS Police SI, Constable పరీక్షలు\n\n" +
                    loc + "లో మంచి కోచింగ్ సెంటర్లు: వంగవీటి, Brain Tree, ALS\n" +
                    "ప్రయోజనాలు: ఉద్యోగ భద్రత, పెన్షన్, గృహ భత్యం, వైద్య సౌకర్యాలు.";
            }

            // Default Telugu
            String streamLine = (stream != null && !stream.isBlank() && !stream.equals("Not decided yet"))
                ? "\n\nమీరు " + stream + " చదువుతున్నారు కాబట్టి నేను మీకు సంబంధిత కెరీర్‌లు, పరీక్షలు గురించి సలహా ఇవ్వగలను." : "";
            return (fn != null ? "నమస్తే, " + fn + "! " : "నమస్తే! ") +
                "నేను SmartCareer Guide, మీ వ్యక్తిగత కెరీర్ కౌన్సెలర్.\n\n" +
                "నేను మీకు ఇవి సహాయపడగలను:\n" +
                "- 10వ, 12వ, డిగ్రీ తర్వాత కెరీర్ ఆప్షన్లు\n" +
                "- TS ePass, PMKVY స్కాలర్‌షిప్‌లు\n" +
                "- NEET, JEE, EAMCET, TSPSC పరీక్షలు\n" +
                "- " + loc + "లో జీతాలు, కళాశాలలు, అవకాశాలు" + streamLine + "\n\n" +
                "ఏదైనా అడగండి!";
        }

        // ══════════════════════════════════════════════
        // HINDI RESPONSES
        // ══════════════════════════════════════════════
        if ("hindi".equals(lang)) {
            String addr = fn != null ? fn + "! " : "";

            if (lower.contains("after 12th") || lower.contains("12 ke baad") || lower.contains("12th ke baad")
                    || lower.contains("kya kare") || lower.contains("options") || lower.contains("what to do")) {
                if (stream != null && stream.contains("MPC")) {
                    return "बढ़िया सवाल, " + addr + "MPC student के लिए बेहतरीन options:\n\n" +
                        "1. B.Tech / B.E. — EAMCET के ज़रिये (Telangana Engineering Entrance)\n" +
                        "   - Top branches: CSE, ECE, Mechanical, Civil\n" +
                        "   - Top colleges: JNTUH, CBIT, MGIT, VNRVJIET\n\n" +
                        "2. B.Sc (Maths/Physics) — Research या Teaching के लिए\n\n" +
                        "3. JEE Mains/Advanced — IIT, NIT, IIIT के लिए\n" +
                        "   - IIIT Hyderabad CSE के लिए बेहतरीन है\n\n" +
                        "4. NDA — Army/Navy/Air Force में रुचि हो तो\n\n" +
                        "TS ePass scholarship के लिए epass.telangana.gov.in पर apply करें!";
                }
                if (stream != null && stream.contains("BiPC")) {
                    return "BiPC के बाद आपके पास बहुत अच्छे options हैं, " + addr + "\n\n" +
                        "1. MBBS — NEET के ज़रिये (neet.nta.nic.in पर registration)\n" +
                        "   Telangana के Government Medical Colleges:\n" +
                        "   Osmania Medical College, Gandhi Medical College, Kakatiya Medical College\n\n" +
                        "2. B.Pharm / D.Pharm — अच्छी salary, कम duration\n\n" +
                        "3. B.Sc Nursing — Hospitals में high demand\n\n" +
                        "4. B.Sc Agriculture — PJTSAU Hyderabad में available\n\n" +
                        "TS ePass scholarship government medical college की fees cover करती है!";
                }
                return "12वीं के बाद आपके options stream पर depend करते हैं:\n\n" +
                    "Science (MPC): B.Tech EAMCET के ज़रिये, JEE IIT/NIT के लिए\n" +
                    "Science (BiPC): MBBS NEET के ज़रिये, B.Pharm, B.Sc Nursing\n" +
                    "Commerce: B.Com, BBA, CA Foundation, IBPS Banking\n" +
                    "Arts: BA, LLB, Journalism, UPSC/TSPSC Civil Services\n\n" +
                    "TS ePass scholarship के लिए 30 September से पहले apply करें!";
            }

            if (lower.contains("scholarship") || lower.contains("epass") || lower.contains("fee")) {
                return "बढ़िया सवाल, " + addr + "Telangana में उपलब्ध scholarships:\n\n" +
                    "1. TS ePass — SC/ST/BC/EWS students के लिए। पूरी tuition + maintenance\n" +
                    "   Apply: epass.telangana.gov.in | Deadline: 30 September\n\n" +
                    "2. PM Yasasvi — OBC/EBC students के लिए (₹75,000–1,25,000/साल)\n\n" +
                    "3. PMKVY — Free skill training + ₹8,000 इनाम\n\n" +
                    "4. Vidyalakshmi — PSB banks से ₹10 Lakh तक education loan\n\n" +
                    "जल्दी apply करें! TS ePass deadline आमतौर पर 30 September होती है।";
            }

            if (lower.contains("software") || lower.contains("coding") || lower.contains("programming") || lower.contains("it job")) {
                return "Software/IT " + loc + " में सबसे अच्छा career है! " + addr + "आपका roadmap:\n\n" +
                    "1. Python या Java सीखें (NPTEL, YouTube पर free)\n" +
                    "2. Data Structures & Algorithms पढ़ें (LeetCode, GeeksForGeeks)\n" +
                    "3. GitHub पर 2-3 projects बनाएं\n" +
                    "4. Internshala, TCS iON पर internship करें\n" +
                    "5. HITEC City companies में campus placements की तैयारी करें\n\n" +
                    loc + " में top companies: TCS, Infosys, Microsoft, Google, Amazon, Wipro\n" +
                    "Fresher salary: 3.5–6 LPA | Experienced: 15–30 LPA";
            }

            if (lower.contains("doctor") || lower.contains("mbbs") || lower.contains("neet") || lower.contains("medical")) {
                return "MBBS एक शानदार career है। " + addr + "\n\n" +
                    "Entrance exam: NEET UG — neet.nta.nic.in पर register करें\n" +
                    "Duration: 5.5 साल (4.5 MBBS + 1 internship)\n\n" +
                    "Telangana में Government Medical Colleges:\n" +
                    "- Osmania Medical College, Hyderabad\n" +
                    "- Gandhi Medical College, Hyderabad\n" +
                    "- Kakatiya Medical College, Warangal\n\n" +
                    "Fees: Govt colleges: ₹15,000–30,000/साल | Private: ₹10–25 Lakh/साल\n" +
                    "TS ePass scholarship government college fees cover करती है!";
            }

            if (lower.contains("government job") || lower.contains("sarkari") || lower.contains("tspsc") || lower.contains("upsc")) {
                return "Government jobs में बेहतरीन stability है! " + addr + "\n\n" +
                    "State level (TSPSC): Group-1, Group-2, Group-3 exams — tspsc.gov.in\n" +
                    "Central level: UPSC Civil Services (IAS/IPS), SSC, IBPS Banking\n" +
                    "Teaching: DSC के ज़रिये school teachers\n" +
                    "Police: TS Police SI, Constable exams\n\n" +
                    loc + " में coaching centers: Vangaveeti, Brain Tree, ALS\n" +
                    "फायदे: Job security, pension, housing allowance, medical benefits.";
            }

            if (lower.contains("ai") || lower.contains("machine learning") || lower.contains("data science")) {
                return "AI/ML Hyderabad में 45%+ growth के साथ fastest growing field है! " + addr + "\n\n" +
                    "1. Python और Mathematics (linear algebra, statistics) सीखें\n" +
                    "2. NumPy, Pandas, Scikit-learn — Kaggle पर free\n" +
                    "3. Andrew Ng का ML course (Coursera — free audit)\n" +
                    "4. Kaggle competitions में participate करें\n" +
                    "5. Target: Microsoft AI Center, Google India, Amazon Alexa\n\n" +
                    "IIIT Hyderabad का AI program excellent है। IIIT graduates 20–40 LPA पाते हैं!";
            }

            // Default Hindi
            String streamLine = (stream != null && !stream.isBlank() && !stream.equals("Not decided yet"))
                ? "\n\nआप " + stream + " पढ़ रहे हैं, इसलिए मैं आपकी stream के अनुसार tailored advice दे सकता हूँ।" : "";
            return (fn != null ? "नमस्ते, " + fn + "! " : "नमस्ते! ") +
                "मैं SmartCareer Guide हूँ, आपका personal career counselor।\n\n" +
                "मैं इनमें मदद कर सकता हूँ:\n" +
                "- 10वीं, 12वीं, graduation के बाद career options\n" +
                "- TS ePass, PMKVY scholarships\n" +
                "- NEET, JEE, EAMCET, TSPSC, UPSC exams\n" +
                "- " + loc + " में salaries, colleges, opportunities" + streamLine + "\n\n" +
                "कुछ भी पूछें — हिंदी, English या Telugu में!";
        }

        // ══════════════════════════════════════════════
        // ENGLISH RESPONSES (default)
        // ══════════════════════════════════════════════
        String addr = fn != null ? fn + "! " : "";

        if (lower.contains("after 12th") || lower.contains("after inter") || lower.contains("12th ke baad") || lower.contains("inter tarvata")
                || lower.contains("what to do") || lower.contains("what can i do") || lower.contains("options after")) {
            if (stream != null && stream.contains("MPC")) {
                return "Great question, " + addr + "As an MPC student, here are your top options after Inter:\n\n" +
                    "1. B.Tech / B.E. via EAMCET (Engineering entrance)\n" +
                    "   - Top branches: CSE, ECE, Mechanical, Civil\n" +
                    "   - Top colleges in Telangana: JNTUH, CBIT, MGIT, VNRVJIET\n\n" +
                    "2. B.Sc (Maths/Physics/Statistics) — good for research or teaching\n\n" +
                    "3. JEE Mains / Advanced — for IITs, NITs, IIITs\n" +
                    "   - IIIT Hyderabad is excellent for CSE (very competitive)\n\n" +
                    "4. NDA (Army/Navy/Air Force) — if you're interested in defence\n\n" +
                    "Apply for TS ePass at epass.telangana.gov.in to cover your college fees!";
            }
            if (stream != null && stream.contains("BiPC")) {
                return "After BiPC Inter, " + addr + "your options are:\n\n" +
                    "1. MBBS via NEET — register at neet.nta.nic.in\n" +
                    "   - Government medical colleges: Osmania (Hyderabad), Gandhi (Hyderabad), Kakatiya (Warangal)\n\n" +
                    "2. B.Pharm / D.Pharm — good salary, shorter duration\n\n" +
                    "3. B.Sc Nursing — high demand, great job security in hospitals\n\n" +
                    "4. B.Sc Agriculture / Horticulture — PJTSAU offers this in Hyderabad\n\n" +
                    "TS ePass covers most government medical/pharmacy college fees!";
            }
            if (stream != null && stream.contains("Commerce")) {
                return "After Commerce Inter, " + addr + "here are your best paths:\n\n" +
                    "1. CA (Chartered Accountant) — most respected finance career\n" +
                    "   - Register with ICAI: icai.org | Foundation → Intermediate → Final\n\n" +
                    "2. B.Com / B.Com (Hons) — base degree for most finance roles\n\n" +
                    "3. BBA (Bachelor of Business Administration) — great for management\n\n" +
                    "4. IBPS / Banking exams — clerk or PO in government banks\n\n" +
                    "Hyderabad has strong CA coaching centres in Ameerpet and Secunderabad!";
            }
            if (stream != null && stream.contains("Arts")) {
                return "Arts stream has many exciting careers, " + addr + "\n\n" +
                    "1. BA (History, Political Science, Economics, Sociology)\n\n" +
                    "2. LLB / BA LLB — Law is booming, especially corporate law\n" +
                    "   - NALSAR Hyderabad is a top national law school in Telangana!\n\n" +
                    "3. Journalism / Mass Communication — MCRC Hyderabad is excellent\n\n" +
                    "4. Design (Fashion, Graphic, Interior) — creative and high-paying\n\n" +
                    "5. UPSC / TSPSC Civil Services — Arts students perform excellently\n\n" +
                    "Many IAS/IPS officers come from Arts backgrounds!";
            }
            return "After 12th, your options depend on your stream:\n\n" +
                "Science (MPC): B.Tech via EAMCET, JEE for IITs/NITs\n" +
                "Science (BiPC): MBBS via NEET, B.Pharm, B.Sc Nursing\n" +
                "Commerce: B.Com, BBA, CA Foundation, IBPS Banking\n" +
                "Arts: BA, LLB, Journalism, UPSC/TSPSC Civil Services\n\n" +
                "Students in " + loc + ": Check TS ePass scholarship — apply before September 30 at epass.telangana.gov.in.";
        }

        if (lower.contains("software") || lower.contains("coding") || lower.contains("programming") || lower.contains("it jobs")) {
            return "Software/IT is the top career choice in " + loc + ". " + addr + "Here's your roadmap:\n\n" +
                "1. Learn Python or Java basics (free on NPTEL, YouTube, Coursera)\n" +
                "2. Study Data Structures & Algorithms (LeetCode, GeeksForGeeks)\n" +
                "3. Build 2-3 projects and host on GitHub\n" +
                "4. Do internships — Internshala, LinkedIn, TCS iON\n" +
                "5. Prepare for campus placements at HITEC City companies\n\n" +
                "Top companies in " + loc + ": TCS, Infosys, Microsoft, Google, Amazon, Wipro\n" +
                "Fresher salary: 3.5–6 LPA | Experienced: 15–30 LPA";
        }

        if (lower.contains("ai") || lower.contains("machine learning") || lower.contains("data science")) {
            return "AI/ML is the fastest growing field — 45%+ year-on-year in Hyderabad! " + addr + "\n\n" +
                "1. Master Python and Mathematics (linear algebra, statistics)\n" +
                "2. Learn NumPy, Pandas, Scikit-learn — free on Kaggle\n" +
                "3. Complete Andrew Ng's ML course (Coursera — free audit)\n" +
                "4. Build Kaggle projects for your portfolio\n" +
                "5. Target: Microsoft AI Center, Google India, Amazon Alexa in Hyderabad\n\n" +
                "IIIT Hyderabad has excellent AI research programs. Many get AI roles at 20–40 LPA!";
        }

        if (lower.contains("scholarship") || lower.contains("epass") || lower.contains("fee reimbursement")) {
            return "Great question, " + addr + "Telangana has excellent scholarship programs:\n\n" +
                "1. TS ePass — For SC/ST/BC/EWS students. Covers full tuition + maintenance.\n" +
                "   Apply at: epass.telangana.gov.in | Deadline: September 30\n\n" +
                "2. TS Merit Scholarship — For top scorers in state universities\n\n" +
                "3. PM Yasasvi — For OBC/EBC students (₹75,000–1,25,000/year)\n\n" +
                "4. PMKVY — Free skill training + ₹8,000 reward\n\n" +
                "5. Vidyalakshmi — Education loans up to ₹10 Lakhs from PSBs\n\n" +
                "Apply early! TS ePass deadline is usually September 30.";
        }

        if (lower.contains("doctor") || lower.contains("mbbs") || lower.contains("neet") || lower.contains("medical")) {
            return "MBBS is a noble and well-paying career. " + addr + "\n\n" +
                "Entrance: NEET UG — register at neet.nta.nic.in\n" +
                "Duration: 5.5 years (4.5 MBBS + 1 year internship)\n\n" +
                "Government medical colleges in Telangana:\n" +
                "- Osmania Medical College, Hyderabad (very prestigious)\n" +
                "- Gandhi Medical College, Hyderabad\n" +
                "- Kakatiya Medical College, Warangal\n\n" +
                "Fees: Govt colleges: ₹15,000–30,000/year | Private: ₹10–25 Lakhs/year\n" +
                "Apply for TS ePass to cover government college fees!";
        }

        if (lower.contains("government job") || lower.contains("sarkari") || lower.contains("tspsc") || lower.contains("upsc")) {
            return "Government jobs offer great stability! " + addr + "\n\n" +
                "State-level (TSPSC): Group-1, Group-2, Group-3 exams — tspsc.gov.in\n" +
                "Central-level: UPSC Civil Services (IAS/IPS), SSC, IBPS Banking\n" +
                "Teaching: DSC (District Selection Committee) for school teachers\n" +
                "Police: TS Police SI, Constable exams\n\n" +
                "Good coaching in " + loc + ": Vangaveeti, Brain Tree, ALS\n" +
                "Benefits: Job security, pension, housing allowance, medical benefits.";
        }

        if (lower.contains("commerce") || lower.contains("ca") || lower.contains("chartered")) {
            return "Commerce opens excellent doors! " + addr + "\n\n" +
                "CA (Chartered Accountant): India's most respected finance qualification\n" +
                "- Register with ICAI: icai.org\n" +
                "- 3 levels: Foundation → Intermediate → Final\n" +
                "- 3-year articleship mandatory\n" +
                "- Fresh CA: 6–10 LPA | Experienced: 15–40 LPA\n\n" +
                "Other careers: BBA, MBA Finance, Banking (IBPS), Digital Marketing\n" +
                "Strong CA community in Hyderabad: Ameerpet, Secunderabad, Banjara Hills.";
        }

        // Personalized default
        String streamLine = "";
        if (stream != null && !stream.isBlank() && !stream.equals("Not decided yet")) {
            streamLine = "\n\nSince you're in " + stream + ", I can give you tailored advice on careers, exams, and colleges that match your stream.";
        }
        String nameLine = fn != null ? "Namaste, " + fn + "! " : "Namaste! ";
        return nameLine + "I am SmartCareer Guide, your personal career guide.\n\n" +
            "I can help you with:\n" +
            "- Career options after 10th, 12th, or graduation\n" +
            "- Scholarships: TS ePass, PMKVY, PM Yasasvi\n" +
            "- Entrance exams: NEET, JEE, EAMCET, TSPSC, UPSC\n" +
            "- Salary ranges and growth prospects in " + loc +
            streamLine + "\n\n" +
            "Ask me anything — in English, Telugu (తెలుగు), or Hindi (हिंदी)!";
    }

    private List<String> getSuggestedQuestions(String message, String stream, String lang) {
        String lower = message.toLowerCase();

        if ("telugu".equals(lang)) {
            if (lower.contains("software") || lower.contains("coding"))
                return List.of("హైదరాబాద్‌లో సాఫ్ట్‌వేర్ ఇంజనీర్ జీతం ఎంత?", "Software job interviews కోసం ఎలా prepare అవ్వాలి?", "తెలంగాణలో ఉత్తమ B.Tech కళాశాలలు ఏవి?");
            if (lower.contains("scholarship") || lower.contains("epass"))
                return List.of("TS ePass కోసం ఎలా దరఖాస్తు చేయాలి?", "General category విద్యార్థులకు స్కాలర్‌షిప్‌లు ఉన్నాయా?", "TS Merit scholarship మొత్తం ఎంత?");
            if (stream != null && stream.contains("MPC"))
                return List.of("తెలంగాణలో ఉత్తమ B.Tech కళాశాలలు ఏవి?", "MPC విద్యార్థులకు స్కాలర్‌షిప్‌లు ఏవి?", "EAMCET కోసం ఇంట్లో నుండి ఎలా చదవాలి?");
            return List.of("12వ తర్వాత ఏమి చేయాలి?", "తెలంగాణలో స్కాలర్‌షిప్‌లు ఏవి?", "Software engineer ఎలా అవ్వాలి?");
        }

        if ("hindi".equals(lang)) {
            if (lower.contains("software") || lower.contains("coding"))
                return List.of("Hyderabad में software engineer की salary कितनी है?", "Software job interviews की तैयारी कैसे करें?", "Telangana में best B.Tech colleges कौन से हैं?");
            if (lower.contains("scholarship") || lower.contains("epass"))
                return List.of("TS ePass के लिए apply कैसे करें?", "General category students के लिए scholarships हैं?", "TS Merit scholarship की amount कितनी है?");
            if (stream != null && stream.contains("MPC"))
                return List.of("Telangana में best B.Tech colleges कौन से हैं?", "MPC students के लिए scholarships कौन सी हैं?", "घर पर EAMCET की तैयारी कैसे करें?");
            return List.of("12वीं के बाद क्या करें?", "Telangana में scholarships कौन सी हैं?", "Software engineer कैसे बनें?");
        }

        // English
        if (lower.contains("software") || lower.contains("coding"))
            return List.of("What is the salary of a software engineer in Hyderabad?", "How to prepare for software job interviews?", "Which B.Tech colleges are best in Telangana?");
        if (lower.contains("scholarship") || lower.contains("epass"))
            return List.of("How to apply for TS ePass?", "What scholarships are available for general category students?", "What is the TS Merit scholarship amount?");
        if (stream != null && stream.contains("MPC"))
            return List.of("What is the EAMCET cutoff for top colleges?", "Which B.Tech branch has the best salary?", "How to crack JEE Mains from Hyderabad?");
        if (stream != null && stream.contains("BiPC"))
            return List.of("How many NEET attempts are allowed?", "Which are the best nursing colleges in Telangana?", "What is the B.Pharm salary in India?");
        return List.of("What careers are best after 12th Science?", "Which scholarships are available in Telangana?", "How to become a software engineer from Hyderabad?");
    }

    private List<Career> getRelatedCareers(String message, String stream) {
        String lower = message.toLowerCase();
        if (lower.contains("software") || lower.contains("coding") || lower.contains("tech") || lower.contains("ai"))
            return careerRepo.findAll("Technology", null, null).stream().limit(3).toList();
        if (lower.contains("doctor") || lower.contains("medical") || lower.contains("health") || lower.contains("mbbs"))
            return careerRepo.findAll("Healthcare", null, null).stream().limit(3).toList();
        if (lower.contains("ca") || lower.contains("finance") || lower.contains("commerce"))
            return careerRepo.findAll("Finance", null, null).stream().limit(3).toList();
        if (stream != null && stream.contains("BiPC"))
            return careerRepo.findAll("Healthcare", null, null).stream().limit(3).toList();
        if (stream != null && stream.contains("Commerce"))
            return careerRepo.findAll("Finance", null, null).stream().limit(3).toList();
        return careerRepo.findTrending().stream().limit(3).toList();
    }
}
