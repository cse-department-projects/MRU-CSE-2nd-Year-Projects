package com.careersaathi.service;

import com.careersaathi.model.*;
import com.careersaathi.repository.CareerRepository;
import com.careersaathi.repository.EntranceExamRepository;
import com.careersaathi.repository.JobRepository;
import com.careersaathi.repository.ScholarshipRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class DashboardService {
    private final CareerRepository careerRepo;
    private final JobRepository jobRepo;
    private final ScholarshipRepository scholarshipRepo;
    private final EntranceExamRepository examRepo;

    public DashboardService(
        CareerRepository careerRepo,
        JobRepository jobRepo,
        ScholarshipRepository scholarshipRepo,
        EntranceExamRepository examRepo
    ) {
        this.careerRepo = careerRepo;
        this.jobRepo = jobRepo;
        this.scholarshipRepo = scholarshipRepo;
        this.examRepo = examRepo;
    }

    public Dashboard getDashboard() {
        Dashboard dashboard = new Dashboard();

        dashboard.setTrendingCareers(careerRepo.findTrending());
        dashboard.setRecentCareers(careerRepo.findAll(null, null, null).stream().limit(4).toList());

        dashboard.setUpcomingDeadlines(examRepo.findAll(null, null, null).stream()
            .filter(exam -> exam.getDeadline() != null && !exam.getDeadline().isBlank())
            .filter(exam -> isUpcomingIsoDate(exam.getDeadline()))
            .map(exam -> new Deadline(exam.getId(), exam.getName(), "exam", exam.getDeadline()))
            .toList());

        int totalJobs = jobRepo.countByType("job");
        int totalInternships = jobRepo.countByType("internship");
        int totalCareers = careerRepo.count();
        int totalScholarships = scholarshipRepo.count();

        dashboard.setQuickStats(new QuickStats(totalCareers, totalJobs, totalScholarships, totalInternships));
        return dashboard;
    }

    private boolean isUpcomingIsoDate(String value) {
        try {
            return !LocalDate.parse(value).isBefore(LocalDate.now());
        } catch (Exception ignored) {
            return false;
        }
    }
}
