package com.careersaathi.service;

import com.careersaathi.model.EntranceExam;
import com.careersaathi.repository.EntranceExamRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EntranceExamService {
    private final EntranceExamRepository repository;

    public EntranceExamService(EntranceExamRepository repository) {
        this.repository = repository;
    }

    public List<EntranceExam> list(String level, String stream, String search) {
        return repository.findAll(level, stream, search);
    }
}
