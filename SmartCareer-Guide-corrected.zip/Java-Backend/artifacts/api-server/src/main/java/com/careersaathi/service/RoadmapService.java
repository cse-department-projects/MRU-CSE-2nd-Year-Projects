package com.careersaathi.service;

import com.careersaathi.model.*;
import com.careersaathi.repository.CareerRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class RoadmapService {
    private final CareerRepository careerRepo;

    public RoadmapService(CareerRepository careerRepo) {
        this.careerRepo = careerRepo;
    }

    public Roadmap getRoadmap(int careerId) {
        CareerDetail career = careerRepo.findById(careerId);
        if (career == null) return null;

        String cluster = career.getCluster();
        List<RoadmapPhase> phases = buildPhasesForCluster(cluster, career.getTitle());

        Roadmap roadmap = new Roadmap();
        roadmap.setCareerId(careerId);
        roadmap.setCareerTitle(career.getTitle());
        roadmap.setPhases(phases);
        return roadmap;
    }

    private List<RoadmapPhase> buildPhasesForCluster(String cluster, String careerTitle) {
        return switch (cluster.toLowerCase()) {
            case "technology" -> technologyRoadmap(careerTitle);
            case "healthcare" -> healthcareRoadmap(careerTitle);
            case "finance" -> financeRoadmap(careerTitle);
            case "education" -> educationRoadmap(careerTitle);
            default -> genericRoadmap(careerTitle);
        };
    }

    private List<RoadmapPhase> technologyRoadmap(String title) {
        return List.of(
            new RoadmapPhase(1, "Foundation (Class 8-10)", "3 years", List.of(
                new RoadmapStep(1, "Build math & logic skills", "Focus on Algebra, Geometry and basic programming concepts. Start with Scratch or block coding.", List.of("https://scratch.mit.edu", "https://www.khanacademy.org"), 5, "beginner"),
                new RoadmapStep(2, "Take CS elective if available", "Choose Computer Science as your 6th optional subject. Practice typing and MS Office basics.", List.of(), 3, "beginner"),
                new RoadmapStep(3, "Participate in Olympiads", "Register for Math Olympiad (IMO), Science Olympiad (NSO). These build competitive thinking.", List.of("https://www.sofworld.org"), 2, "beginner")
            )),
            new RoadmapPhase(2, "Stream & Direction (Class 11-12)", "2 years", List.of(
                new RoadmapStep(4, "Choose Science stream (MPC)", "Take Maths, Physics, Chemistry — the standard path for tech careers.", List.of(), 0, "beginner"),
                new RoadmapStep(5, "Learn Python basics", "Python is the most in-demand first language. Complete at least 30 hours of Python basics.", List.of("https://www.python.org/about/gettingstarted", "https://nptel.ac.in"), 30, "beginner"),
                new RoadmapStep(6, "Build your first project", "Create a small project: a calculator, quiz app, or simple website. Put it on GitHub.", List.of("https://github.com"), 20, "intermediate"),
                new RoadmapStep(7, "Prepare for JEE/EAMCET", "Target NIT/IIT via JEE or Telangana engineering colleges via EAMCET for B.Tech CSE/IT.", List.of("https://jeeadv.ac.in", "https://eapcet.tsche.ac.in"), 0, "advanced")
            )),
            new RoadmapPhase(3, "Degree & Skill Building (B.Tech Years 1-4)", "4 years", List.of(
                new RoadmapStep(8, "Master Data Structures & Algorithms", "DSA is the core of tech interviews. Complete at least 150 problems on LeetCode.", List.of("https://leetcode.com", "https://www.geeksforgeeks.org"), 200, "intermediate"),
                new RoadmapStep(9, "Learn your core stack", "Choose a specialization: Web Dev (React/Node), Data Science (Python/ML), or Java Backend.", List.of("https://www.freecodecamp.org", "https://nptel.ac.in"), 150, "intermediate"),
                new RoadmapStep(10, "Do 1-2 internships", "Apply to AICTE intern programs, TCS iON, Internshala. Real experience is crucial.", List.of("https://internshala.com", "https://aicte-india.org"), 0, "intermediate"),
                new RoadmapStep(11, "Crack placement/job offers", "Prepare for aptitude, coding rounds. Target Hyderabad companies: TCS, Infosys, Wipro, startups.", List.of("https://www.hackerrank.com", "https://www.glassdoor.co.in"), 0, "advanced")
            )),
            new RoadmapPhase(4, "Early Career Growth", "1-2 years post-placement", List.of(
                new RoadmapStep(12, "Get certified", "AWS, Azure, Google Cloud certs significantly boost salary. Start with free tier cloud accounts.", List.of("https://aws.amazon.com/certification", "https://cloud.google.com/certification"), 60, "intermediate"),
                new RoadmapStep(13, "Contribute to open source", "Find a project on GitHub that interests you. Even documentation contributions count.", List.of("https://github.com/explore"), 40, "advanced"),
                new RoadmapStep(14, "Build a portfolio & LinkedIn", "Showcase 3-5 projects on GitHub. Keep LinkedIn updated with skills and achievements.", List.of("https://www.linkedin.com"), 10, "beginner")
            ))
        );
    }

    private List<RoadmapPhase> healthcareRoadmap(String title) {
        return List.of(
            new RoadmapPhase(1, "Foundation (Class 8-10)", "3 years", List.of(
                new RoadmapStep(1, "Strengthen Biology & Chemistry", "These are your core subjects. Focus on cell biology, human anatomy basics, and chemistry reactions.", List.of("https://www.khanacademy.org/science"), 5, "beginner"),
                new RoadmapStep(2, "Volunteer at local clinics/hospitals", "Shadow doctors or nurses. Many PHCs (Primary Health Centers) in Telangana welcome student visits.", List.of(), 10, "beginner")
            )),
            new RoadmapPhase(2, "Stream & Entrance Prep (Class 11-12)", "2 years", List.of(
                new RoadmapStep(3, "Choose Science stream (BiPC)", "Biology, Physics, Chemistry is mandatory for medical careers.", List.of(), 0, "beginner"),
                new RoadmapStep(4, "NEET preparation", "NEET is the single entrance exam for MBBS, BDS, BAMS. Start preparation from Class 11.", List.of("https://neet.nta.nic.in", "https://www.aakash.ac.in"), 0, "advanced"),
                new RoadmapStep(5, "Learn about TS EAMCET BioMaths stream", "For pharmacy and nursing, TS EAMCET BiPC track opens doors to B.Pharm, B.Sc Nursing.", List.of("https://eapcet.tsche.ac.in"), 0, "intermediate")
            )),
            new RoadmapPhase(3, "Professional Degree", "5-6 years", List.of(
                new RoadmapStep(6, "Complete MBBS / B.Pharm / B.Sc Nursing", "Focus on practical training. Hyderabad has NIMS, Osmania Medical College, Gandhi Hospital.", List.of(), 0, "advanced"),
                new RoadmapStep(7, "Internship / Housejob", "1-year mandatory rotational internship after MBBS. Builds core clinical skills.", List.of(), 0, "advanced"),
                new RoadmapStep(8, "Register with Medical Council", "Register with NMC/Telangana Medical Council. This is mandatory to practice.", List.of("https://www.nmc.org.in"), 0, "intermediate")
            )),
            new RoadmapPhase(4, "Specialization & Growth", "2-3 years", List.of(
                new RoadmapStep(9, "Pursue PG (MD/MS) or super-speciality", "Prepare for NEET PG. Top specialties: Radiology, Dermatology, Ortho, Paediatrics.", List.of("https://neetpg.nta.nic.in"), 0, "advanced"),
                new RoadmapStep(10, "Join TS government service or private hospital", "Government doctors get job security + housing + DCRHS benefits. Private hospitals offer higher pay.", List.of("https://dme.telangana.gov.in"), 0, "intermediate")
            ))
        );
    }

    private List<RoadmapPhase> financeRoadmap(String title) {
        return List.of(
            new RoadmapPhase(1, "Foundation (Class 8-10)", "3 years", List.of(
                new RoadmapStep(1, "Build Maths & Accounts foundation", "Focus on arithmetic, percentages, profit/loss, interest calculations — core finance skills.", List.of("https://www.khanacademy.org/math"), 3, "beginner")
            )),
            new RoadmapPhase(2, "Stream Selection (Class 11-12)", "2 years", List.of(
                new RoadmapStep(2, "Choose Commerce stream", "Accounts, Economics, Business Studies form the base for CA/finance careers.", List.of(), 0, "beginner"),
                new RoadmapStep(3, "Register for CA Foundation early", "You can register for CA Foundation after Class 10. Start early!", List.of("https://www.icai.org"), 0, "intermediate")
            )),
            new RoadmapPhase(3, "Professional Qualification", "4-5 years", List.of(
                new RoadmapStep(4, "Clear CA Foundation → Intermediate → Final", "India's toughest professional exam. Average pass rate 15-20%. Persistence and coaching matter.", List.of("https://www.icai.org", "https://boslive.icai.org"), 2000, "advanced"),
                new RoadmapStep(5, "Articleship (3 years)", "Mandatory 3-year practical training under a CA firm. Hyderabad has 1000+ registered CA firms.", List.of(), 0, "intermediate"),
                new RoadmapStep(6, "Learn taxation & GST software", "Tally, SAP FICO, and GST portals are essential for practice.", List.of("https://tallysolutions.com"), 80, "intermediate")
            )),
            new RoadmapPhase(4, "Early Career", "1-2 years", List.of(
                new RoadmapStep(7, "Join a CA firm or corporate finance team", "Big 4 firms (Deloitte, PwC, EY, KPMG) in Hyderabad actively hire fresh CAs.", List.of(), 0, "intermediate"),
                new RoadmapStep(8, "Consider CFA or CPA for global roles", "Adds significant value for roles in investment banking or MNC finance teams.", List.of("https://www.cfainstitute.org"), 300, "advanced")
            ))
        );
    }

    private List<RoadmapPhase> educationRoadmap(String title) {
        return List.of(
            new RoadmapPhase(1, "Foundation", "Class 8-12", List.of(
                new RoadmapStep(1, "Identify your subject passion", "Great teachers excel in a subject they love. Find yours early.", List.of(), 0, "beginner"),
                new RoadmapStep(2, "Practice public speaking", "Join debate clubs, model UN, or youth parliament programs in your school.", List.of(), 10, "beginner")
            )),
            new RoadmapPhase(2, "Graduation", "3-4 years", List.of(
                new RoadmapStep(3, "Complete B.Sc / B.Com / B.A in your subject", "Choose the degree that matches your teaching subject interest.", List.of(), 0, "beginner"),
                new RoadmapStep(4, "Register for B.Ed", "2-year B.Ed degree is mandatory to teach in government/private schools.", List.of("https://ncte.gov.in"), 0, "intermediate")
            )),
            new RoadmapPhase(3, "Certification & Employment", "1-2 years", List.of(
                new RoadmapStep(5, "Clear TET / DSC (Telangana)", "Teacher Eligibility Test (TET) and DSC are required for government school teaching in Telangana.", List.of("https://treirb.telangana.gov.in"), 0, "advanced"),
                new RoadmapStep(6, "Apply to TS Gurukul / TSRJC schools", "Telangana Residential Schools offer excellent pay and facilities. Highly competitive.", List.of(), 0, "intermediate")
            ))
        );
    }

    private List<RoadmapPhase> genericRoadmap(String title) {
        return List.of(
            new RoadmapPhase(1, "Foundation (Class 8-10)", "3 years", List.of(
                new RoadmapStep(1, "Build core subject skills", "Excel in relevant subjects. Read about the career field.", List.of("https://www.swayam.gov.in"), 5, "beginner"),
                new RoadmapStep(2, "Explore through activities", "Join clubs, competitions, and volunteer work related to your career interest.", List.of(), 10, "beginner")
            )),
            new RoadmapPhase(2, "Stream Selection (Class 11-12)", "2 years", List.of(
                new RoadmapStep(3, "Choose the right stream", "Research which stream (Science/Commerce/Arts) aligns with your target career.", List.of(), 0, "beginner"),
                new RoadmapStep(4, "Start building skills early", "Use NPTEL, SWAYAM, Coursera for free introductory courses.", List.of("https://nptel.ac.in", "https://www.swayam.gov.in"), 30, "beginner")
            )),
            new RoadmapPhase(3, "Degree & Professional Training", "3-5 years", List.of(
                new RoadmapStep(5, "Complete relevant degree", "Get into the best institution you can. Focus on learning, not just marks.", List.of(), 0, "intermediate"),
                new RoadmapStep(6, "Do internships", "Practical experience matters more than theory. Do at least 2 internships.", List.of("https://internshala.com"), 0, "intermediate")
            )),
            new RoadmapPhase(4, "Launch Career", "First 1-2 years", List.of(
                new RoadmapStep(7, "Get your first job/gig", "Target entry-level roles. Hyderabad has many opportunities for fresh graduates.", List.of("https://www.naukri.com", "https://www.linkedin.com/jobs"), 0, "intermediate"),
                new RoadmapStep(8, "Keep upskilling", "Technology changes fast. Dedicate 5 hours/week to learning new skills.", List.of("https://www.coursera.org", "https://www.udemy.com"), 20, "intermediate")
            ))
        );
    }
}
