package com.careersaathi.service;

import com.careersaathi.model.StudentProfile;
import com.careersaathi.model.StudentWorkspace;
import com.careersaathi.repository.StudentWorkspaceRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class StudentWorkspaceService {
    private final StudentWorkspaceRepository repository;

    public StudentWorkspaceService(StudentWorkspaceRepository repository) {
        this.repository = repository;
    }

    public StudentWorkspace get(String studentId) {
        return repository.findByStudentId(studentId);
    }

    public StudentWorkspace save(String studentId, StudentWorkspace input) {
        if (input == null) throw new IllegalArgumentException("Workspace data is required");

        StudentProfile submitted = input.getProfile() == null ? new StudentProfile() : input.getProfile();
        StudentProfile profile = new StudentProfile();
        profile.setCurrentClass(cleanText(submitted.getCurrentClass(), 80));
        profile.setStream(cleanText(submitted.getStream(), 80));
        profile.setInterests(cleanList(submitted.getInterests()));
        profile.setSkills(cleanList(submitted.getSkills()));
        profile.setGoals(cleanList(submitted.getGoals()));

        StudentWorkspace workspace = new StudentWorkspace();
        workspace.setExists(true);
        workspace.setProfile(profile);
        workspace.setRoadmapProgress(cleanProgress(input.getRoadmapProgress()));
        workspace.setSkillGapProgress(cleanProgress(input.getSkillGapProgress()));
        return repository.save(studentId, workspace);
    }

    private String cleanText(String text, int maxLength) {
        if (text == null) return "";
        String clean = text.trim();
        return clean.length() > maxLength ? clean.substring(0, maxLength) : clean;
    }

    private List<String> cleanList(List<String> values) {
        if (values == null) return new ArrayList<>();
        return values.stream()
            .filter(value -> value != null && !value.isBlank())
            .map(value -> cleanText(value, 100))
            .distinct()
            .limit(30)
            .toList();
    }

    private Map<String, List<String>> cleanProgress(Map<String, List<String>> values) {
        if (values == null) return new LinkedHashMap<>();
        Map<String, List<String>> result = new LinkedHashMap<>();
        values.entrySet().stream().limit(100).forEach(entry -> {
            String key = cleanText(entry.getKey(), 100);
            if (!key.isBlank()) result.put(key, cleanList(entry.getValue()));
        });
        return result;
    }
}
