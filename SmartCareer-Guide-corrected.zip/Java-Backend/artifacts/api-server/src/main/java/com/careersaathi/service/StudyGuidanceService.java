package com.careersaathi.service;

import com.careersaathi.model.StudyGuidance;
import com.careersaathi.repository.StudyGuidanceRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudyGuidanceService {
    private final StudyGuidanceRepository repository;

    public StudyGuidanceService(StudyGuidanceRepository repository) {
        this.repository = repository;
    }

    public List<StudyGuidance> list(String stage) {
        return repository.findAll(stage);
    }
}
