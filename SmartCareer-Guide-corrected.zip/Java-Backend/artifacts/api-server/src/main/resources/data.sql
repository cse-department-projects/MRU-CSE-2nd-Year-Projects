INSERT INTO careers (title, cluster, streams, salary_range, demand_level, description, icon_emoji, tags, skills, entry_paths, local_opportunities, average_salary_lpa, growth_rate)
SELECT 'Software Engineer', 'Technology', '["Science-MPC","Science-MPC+CS"]', '5-30 LPA', 'high', 'Design, develop and maintain software applications. High demand across Hyderabad''s booming IT corridor with opportunities at TCS, Infosys, Wipro, and hundreds of startups.', NULL, '["coding","tech","it"]', '["Java","Python","DSA","System Design","SQL","Git"]', '["B.Tech CSE/IT","B.Sc Computer Science","Diploma in CS + lateral entry"]', '["HITEC City","Gachibowli","Kondapur","Madhapur"]', 12.5, '25% YoY'
WHERE NOT EXISTS (SELECT 1 FROM careers WHERE title = 'Software Engineer');

INSERT INTO careers (title, cluster, streams, salary_range, demand_level, description, icon_emoji, tags, skills, entry_paths, local_opportunities, average_salary_lpa, growth_rate)
SELECT 'Data Analyst', 'Technology', '["Science-MPC","Commerce","Science-MPC+CS"]', '4-18 LPA', 'high', 'Transform raw data into actionable business insights. Hyderabad hosts analytics centers of Google, Microsoft, Amazon and 200+ analytics firms.', NULL, '["data","analytics","tech"]', '["SQL","Excel","Power BI","Python","Statistics","Tableau"]', '["B.Tech CSE/IT","B.Sc Statistics/Maths","BBA + Analytics cert","Any degree + upskilling"]', '["HITEC City","Gachibowli","Nanakramguda"]', 8.0, '30% YoY'
WHERE NOT EXISTS (SELECT 1 FROM careers WHERE title = 'Data Analyst');

INSERT INTO careers (title, cluster, streams, salary_range, demand_level, description, icon_emoji, tags, skills, entry_paths, local_opportunities, average_salary_lpa, growth_rate)
SELECT 'Civil Engineer', 'Engineering', '["Science-MPC"]', '3-15 LPA', 'medium', 'Plan and supervise construction of infrastructure — roads, bridges, buildings. Strong demand in Telangana due to massive infrastructure push including metro, highways and townships.', NULL, '["construction","infra","government"]', '["AutoCAD","Structural Analysis","Project Management","Surveying","Estimation"]', '["B.Tech Civil Engineering","Diploma in Civil Engineering"]', '["HMDA projects","TSRTC","PWD Telangana","Private builders Hyderabad"]', 6.0, '12% YoY'
WHERE NOT EXISTS (SELECT 1 FROM careers WHERE title = 'Civil Engineer');

INSERT INTO careers (title, cluster, streams, salary_range, demand_level, description, icon_emoji, tags, skills, entry_paths, local_opportunities, average_salary_lpa, growth_rate)
SELECT 'Doctor (MBBS)', 'Healthcare', '["Science-BiPC"]', '8-50 LPA', 'high', 'Diagnose and treat illnesses to restore patient health. High respect, job security and growing demand — especially in Tier-2 Telangana cities like Warangal, Karimnagar, Nalgonda.', NULL, '["medicine","health","government"]', '["Anatomy","Clinical Skills","Patient Care","Pharmacology","Surgery basics"]', '["NEET UG → MBBS (5.5 years)","AIIMS/JIPMER → Specialty","Government Medical Colleges TS"]', '["NIMS Hyderabad","Osmania General Hospital","ESI Hospitals","Private hospitals"]', 15.0, '15% YoY'
WHERE NOT EXISTS (SELECT 1 FROM careers WHERE title = 'Doctor (MBBS)');

INSERT INTO careers (title, cluster, streams, salary_range, demand_level, description, icon_emoji, tags, skills, entry_paths, local_opportunities, average_salary_lpa, growth_rate)
SELECT 'Chartered Accountant', 'Finance', '["Commerce","Science-MPC"]', '6-40 LPA', 'high', 'Manage financial audits, tax advisory and accounting for businesses. One of India''s most prestigious professional qualifications with excellent earning potential.', NULL, '["finance","accounting","ca"]', '["Accounting","Taxation","Audit","Financial Reporting","GST","Tally"]', '["B.Com + CA Foundation → Intermediate → Final","B.Com (Hons) + ICAI route"]', '["Big 4 firms Hyderabad","Telangana govt depts","Banks","SMEs Secunderabad"]', 10.0, '18% YoY'
WHERE NOT EXISTS (SELECT 1 FROM careers WHERE title = 'Chartered Accountant');

INSERT INTO careers (title, cluster, streams, salary_range, demand_level, description, icon_emoji, tags, skills, entry_paths, local_opportunities, average_salary_lpa, growth_rate)
SELECT 'AI/ML Engineer', 'Technology', '["Science-MPC","Science-MPC+CS"]', '8-40 LPA', 'high', 'Build intelligent systems that learn from data. Hyderabad is India''s AI hub — Microsoft AI, Google Brain, Amazon Alexa all have major AI research centers here.', NULL, '["ai","machine-learning","future"]', '["Python","TensorFlow/PyTorch","Linear Algebra","Statistics","Deep Learning","MLOps"]', '["B.Tech CSE with ML specialization","M.Tech AI/ML","B.Sc Maths/Stats + upskilling"]', '["Microsoft Hyderabad","Google India","Amazon","IIIT Hyderabad","AI startups"]', 18.0, '45% YoY'
WHERE NOT EXISTS (SELECT 1 FROM careers WHERE title = 'AI/ML Engineer');

INSERT INTO careers (title, cluster, streams, salary_range, demand_level, description, icon_emoji, tags, skills, entry_paths, local_opportunities, average_salary_lpa, growth_rate)
SELECT 'Teacher / Educator', 'Education', '["Science-MPC","Science-BiPC","Commerce","Arts"]', '2-8 LPA', 'medium', 'Educate and inspire the next generation. Government teaching jobs (DSC) offer stability, while private schools and coaching centres offer good pay in urban Telangana.', NULL, '["education","teaching","government"]', '["Subject Knowledge","Communication","Pedagogy","Classroom Management","Digital Tools"]', '["B.Ed after graduation","D.Ed (Diploma in Education)","TET/DSC qualification"]', '["TS Residential Schools","Navodaya Vidyalayas","Private schools Hyderabad","Coaching centres"]', 4.5, '8% YoY'
WHERE NOT EXISTS (SELECT 1 FROM careers WHERE title = 'Teacher / Educator');

INSERT INTO careers (title, cluster, streams, salary_range, demand_level, description, icon_emoji, tags, skills, entry_paths, local_opportunities, average_salary_lpa, growth_rate)
SELECT 'Digital Marketing Specialist', 'Business', '["Commerce","Arts","Science-MPC","Science-BiPC"]', '3-15 LPA', 'high', 'Grow brands online through SEO, social media, content and paid ads. Stream-agnostic career with high demand from Hyderabad startups and D2C brands.', NULL, '["marketing","digital","startup"]', '["SEO/SEM","Social Media","Google Analytics","Content Writing","Meta Ads","Email Marketing"]', '["Any degree + Google/Meta certifications","BBA Marketing","MBA Digital Marketing"]', '["Hyderabad startups","D2C brands","Digital agencies","Freelance remote"]', 6.0, '35% YoY'
WHERE NOT EXISTS (SELECT 1 FROM careers WHERE title = 'Digital Marketing Specialist');

INSERT INTO careers (title, cluster, streams, salary_range, demand_level, description, icon_emoji, tags, skills, entry_paths, local_opportunities, average_salary_lpa, growth_rate)
SELECT 'Cybersecurity Analyst', 'Technology', '["Science-MPC","Science-MPC+CS"]', '5-25 LPA', 'high', 'Protect organizations from cyber attacks and data breaches. Rapidly growing field as India mandates data protection. CERT-IN and government agencies actively hiring.', NULL, '["security","tech","future"]', '["Networking","Ethical Hacking","VAPT","SIEM Tools","Linux","CEH/CISSP certs"]', '["B.Tech CSE/IT","B.Sc IT + Security certs","Diploma in Cybersecurity"]', '["Cyberabad Police","Banks","IT companies Hyderabad","BFSI sector"]', 9.0, '40% YoY'
WHERE NOT EXISTS (SELECT 1 FROM careers WHERE title = 'Cybersecurity Analyst');

INSERT INTO careers (title, cluster, streams, salary_range, demand_level, description, icon_emoji, tags, skills, entry_paths, local_opportunities, average_salary_lpa, growth_rate)
SELECT 'Pharmacist', 'Healthcare', '["Science-BiPC"]', '2-10 LPA', 'medium', 'Dispense medicines, advise patients on medications and manage drug inventory. Pharma City Hyderabad has huge demand with companies like Dr. Reddy''s, Aurobindo and Sun Pharma.', NULL, '["pharma","health","medicine"]', '["Pharmacology","Drug Interactions","Patient Counseling","Inventory Management","Quality Control"]', '["D.Pharm (Diploma)","B.Pharm (Degree)","M.Pharm (Specialty)"]', '["Pharma City Hyderabad","Apollo Pharmacy","Hospitals","Dr Reddy labs","Retail pharmacies"]', 4.0, '10% YoY'
WHERE NOT EXISTS (SELECT 1 FROM careers WHERE title = 'Pharmacist');

INSERT INTO careers (title, cluster, streams, salary_range, demand_level, description, icon_emoji, tags, skills, entry_paths, local_opportunities, average_salary_lpa, growth_rate)
SELECT 'Agricultural Scientist', 'Agriculture & Veterinary', '["Science-BiPC","Science-MPC"]', 'Varies by role and experience', 'varies', 'Use crop, soil, animal, or food sciences to improve agriculture and food systems. Career paths include field extension, agritech, animal health, and research; requirements vary by specialization.', NULL, '["agriculture","research","food-systems"]', '["Biology","Field research","Data collection","Soil and crop science","Communication"]', '["B.Sc. Agriculture, Horticulture, or Forestry","B.V.Sc. & A.H. for veterinary roles","Agricultural Engineering","Postgraduate study for research roles"]', '["Agricultural universities and research institutes","Agritech and food companies","Agriculture and animal-husbandry departments"]', NULL, NULL
WHERE NOT EXISTS (SELECT 1 FROM careers WHERE title = 'Agricultural Scientist');

INSERT INTO careers (title, cluster, streams, salary_range, demand_level, description, icon_emoji, tags, skills, entry_paths, local_opportunities, average_salary_lpa, growth_rate)
SELECT 'Legal & Public Service Professional', 'Law & Public Service', '["Arts","Commerce","Science-MPC","Science-BiPC"]', 'Varies by role and experience', 'varies', 'Paths span legal practice, compliance, public policy, and public administration. Requirements differ: legal and judiciary roles require law qualifications, while civil-service roles have separate competitive exams.', NULL, '["law","public-service","policy"]', '["Research","Reasoning","Reading and writing","Communication","Civic knowledge"]', '["5-year integrated law degree after Class 12","3-year LL.B. after a bachelor''s degree","Competitive exams for civil-service roles"]', '["Courts and legal-aid organisations","Corporate legal and compliance teams","Public-administration and policy organisations"]', NULL, NULL
WHERE NOT EXISTS (SELECT 1 FROM careers WHERE title = 'Legal & Public Service Professional');

INSERT INTO careers (title, cluster, streams, salary_range, demand_level, description, icon_emoji, tags, skills, entry_paths, local_opportunities, average_salary_lpa, growth_rate)
SELECT 'Visual Designer & Media Creator', 'Design & Media', '["Arts","Commerce","Science-MPC","Science-BiPC"]', 'Varies by role and experience', 'varies', 'Create visual content and digital media for products, organisations, and audiences. Career paths include graphic and UX design, animation, video, journalism, and content production; portfolios and specialization matter.', NULL, '["design","media","creative"]', '["Visual communication","Storytelling","Design tools","Writing","Portfolio development"]', '["Design or visual-communication degree or diploma","Any stream with a focused portfolio","Specialized study in UX, animation, video, or journalism"]', '["Design studios and agencies","Product and media companies","Freelance and independent creator roles"]', NULL, NULL
WHERE NOT EXISTS (SELECT 1 FROM careers WHERE title = 'Visual Designer & Media Creator');

INSERT INTO careers (title, cluster, streams, salary_range, demand_level, description, icon_emoji, tags, skills, entry_paths, local_opportunities, average_salary_lpa, growth_rate)
SELECT 'Research Assistant / Scientist', 'Science & Research', '["Science-MPC","Science-BiPC"]', 'Varies by role and experience', 'varies', 'Investigate questions through experiments, observation, or data analysis in fields such as biology, chemistry, physics, and environmental science. Advanced research roles often require postgraduate study; requirements vary by subject.', NULL, '["science","research","analysis"]', '["Scientific method","Data analysis","Laboratory practice","Technical writing","Critical thinking"]', '["B.Sc. or B.Tech. in a relevant subject for entry roles","M.Sc. or M.Tech. for advanced research roles","Ph.D. for independent research positions"]', '["Universities and research institutes","Testing and diagnostic laboratories","Industry research and development teams"]', NULL, NULL
WHERE NOT EXISTS (SELECT 1 FROM careers WHERE title = 'Research Assistant / Scientist');

INSERT INTO jobs (title, company, type, location, remote, stipend, description, eligibility, apply_url, deadline, trust_score)
SELECT 'Junior Software Developer Intern', 'TCS iON', 'internship', 'Hyderabad', false, '10,000/month', 'Work on real enterprise software projects alongside senior developers. Learn agile methodologies and modern Java/Python stack.', 'B.Tech CSE/IT 2nd-4th year, CGPA > 6.5', 'https://ibegin.tcs.com', 'Aug 30, 2026', 95
WHERE NOT EXISTS (SELECT 1 FROM jobs WHERE title = 'Junior Software Developer Intern' AND company = 'TCS iON');

INSERT INTO jobs (title, company, type, location, remote, stipend, description, eligibility, apply_url, deadline, trust_score)
SELECT 'Data Analytics Intern', 'Deloitte India', 'internship', 'Hyderabad', true, '15,000/month', 'Analyze datasets, create dashboards, support consulting teams with data-driven insights using Power BI and SQL.', 'B.Com/BBA/B.Sc Statistics, good Excel skills', 'https://apply.deloitte.com', 'Sep 15, 2026', 97
WHERE NOT EXISTS (SELECT 1 FROM jobs WHERE title = 'Data Analytics Intern' AND company = 'Deloitte India');

INSERT INTO jobs (title, company, type, location, remote, stipend, description, eligibility, apply_url, deadline, trust_score)
SELECT 'Frontend Developer', 'Startups.AI Hyderabad', 'job', 'Hyderabad', true, NULL, 'Build modern React-based dashboards for AI products. Equity + salary package. Flexible remote work.', 'B.Tech with React experience or strong portfolio', NULL, NULL, 82
WHERE NOT EXISTS (SELECT 1 FROM jobs WHERE title = 'Frontend Developer' AND company = 'Startups.AI Hyderabad');

INSERT INTO jobs (title, company, type, location, remote, stipend, description, eligibility, apply_url, deadline, trust_score)
SELECT 'Content Writer - EdTech', 'Byju''s', 'job', 'Hyderabad', true, NULL, 'Create engaging educational content for K-12 students. Focus on Science and Maths. Work from home available.', 'Any graduate with excellent English writing skills', 'https://byjus.com/careers', 'Oct 1, 2026', 90
WHERE NOT EXISTS (SELECT 1 FROM jobs WHERE title = 'Content Writer - EdTech' AND company = 'Byju''s');

INSERT INTO jobs (title, company, type, location, remote, stipend, description, eligibility, apply_url, deadline, trust_score)
SELECT 'Government Civil Engineer', 'TS Roads & Buildings', 'job', 'Various Districts, Telangana', false, NULL, 'Work on public infrastructure projects including roads, bridges and government buildings across Telangana. Permanent government job with pension.', 'B.Tech Civil, TS State domicile required', 'https://tsrb.gov.in', 'Dec 31, 2026', 99
WHERE NOT EXISTS (SELECT 1 FROM jobs WHERE title = 'Government Civil Engineer' AND company = 'TS Roads & Buildings');

INSERT INTO jobs (title, company, type, location, remote, stipend, description, eligibility, apply_url, deadline, trust_score)
SELECT 'Social Media Freelancer', 'Multiple Clients', 'freelance', 'Remote', true, '5,000-20,000/project', 'Manage Instagram/Facebook pages for local Hyderabad businesses. Flexible hours, great for students.', 'Anyone with social media skills and creativity', NULL, NULL, 75
WHERE NOT EXISTS (SELECT 1 FROM jobs WHERE title = 'Social Media Freelancer' AND company = 'Multiple Clients');

INSERT INTO scholarships (name, provider, level, categories, amount, description, deadline, apply_url, state)
SELECT 'TS ePass', 'Telangana State Government', '["10th","12th","UG","PG","Diploma"]', '["SC","ST","BC","EWS"]', 'Full tuition + maintenance allowance', 'Flagship scholarship for students from reserved categories. Covers full tuition fees and provides maintenance allowance for hostel. One of the largest state scholarship programs in India.', 'Sep 30, 2026', 'https://epass.telangana.gov.in', 'Telangana'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE name = 'TS ePass');

INSERT INTO scholarships (name, provider, level, categories, amount, description, deadline, apply_url, state)
SELECT 'PM Yasasvi Scholarship', 'Ministry of Social Justice, GoI', '["9th","10th","11th","12th"]', '["OBC","EBC","DNT"]', 'Rs 75,000 - 1,25,000/year', 'Central government scholarship for OBC/EBC/DNT students studying in top schools. Merit-cum-means based selection.', 'Oct 31, 2026', 'https://scholarships.gov.in', NULL
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE name = 'PM Yasasvi Scholarship');

INSERT INTO scholarships (name, provider, level, categories, amount, description, deadline, apply_url, state)
SELECT 'PMKVY - Skill India', 'NSDC / Ministry of Skill Dev', '["10th","12th"]', '["General","SC","ST","BC","OBC"]', 'Free skill training + Rs 8,000 reward', 'Pradhan Mantri Kaushal Vikas Yojana provides free certified skill training in 300+ trades. Participants get a stipend and placement assistance.', 'Open enrollment', 'https://pmkvyofficial.org', NULL
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE name = 'PMKVY - Skill India');

INSERT INTO scholarships (name, provider, level, categories, amount, description, deadline, apply_url, state)
SELECT 'Vidyalakshmi Education Loan', 'Indian Banks (PSBs)', '["UG","PG"]', '["General","SC","ST","BC","OBC"]', 'Up to Rs 10 Lakhs (no collateral)', 'Single-window portal to apply for education loans from 38+ banks. No collateral for loans up to 7.5L. Priority to girl students.', 'Rolling applications', 'https://www.vidyalakshmi.co.in', NULL
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE name = 'Vidyalakshmi Education Loan');

INSERT INTO scholarships (name, provider, level, categories, amount, description, deadline, apply_url, state)
SELECT 'TS Merit Scholarship', 'Telangana Education Dept', '["UG","PG"]', '["General"]', 'Rs 10,000 - 20,000/year', 'Merit-based scholarship for top-performing students in Telangana state universities. Based on board exam results.', 'Aug 31, 2026', 'https://telanganaeducation.gov.in', 'Telangana'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE name = 'TS Merit Scholarship');

INSERT INTO scholarships (name, provider, level, categories, amount, description, deadline, apply_url, state)
SELECT 'Inspire Scholarship', 'DST - Government of India', '["11th","12th","UG","PG"]', '["General","SC","ST"]', 'Rs 80,000/year', 'For students pursuing Natural and Basic Sciences. Promotes scientific research careers. Monthly scholarship + annual contingency grant.', 'Nov 30, 2026', 'https://online-inspire.gov.in', NULL
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE name = 'Inspire Scholarship');

UPDATE scholarships
SET eligibility = 'Eligibility depends on Telangana domicile, community, course, income and the current scheme rules. Check the official portal before applying.',
    deadline = NULL,
    deadline_note = 'The 2026–27 portal is open; a final deadline was not verified. Check the portal for the current closing date.',
    apply_url = 'https://telanganaepass.cgg.gov.in/',
    categories = '["SC","ST","BC","EBC","Minority","PwD"]'
WHERE name = 'TS ePass';

UPDATE scholarships
SET eligibility = 'Community, class, school and family-income requirements are scheme-specific. Confirm the current notice on the National Scholarship Portal.',
    deadline = NULL,
    deadline_note = 'National Scholarship Portal deadlines vary by scheme. Check the current application window.',
    apply_url = 'https://scholarships.gov.in/'
WHERE name = 'PM Yasasvi Scholarship';

UPDATE scholarships
SET eligibility = 'Eligibility and any financial incentives depend on the approved course and current scheme terms. Confirm details with the official portal or training provider.',
    deadline = NULL,
    deadline_note = 'Training registration depends on course availability; this is not a fixed scholarship deadline.',
    apply_url = 'https://www.pmkvyofficial.org/'
WHERE name = 'PMKVY - Skill India';

UPDATE scholarships
SET eligibility = 'This is an education-loan portal, not a scholarship. Loan terms and eligibility depend on the selected bank and course.',
    deadline = NULL,
    deadline_note = 'Applications are bank- and course-dependent; review current terms on the official portal.',
    apply_url = 'https://www.vidyalakshmi.co.in/'
WHERE name = 'Vidyalakshmi Education Loan';

UPDATE scholarships
SET eligibility = 'A current Telangana merit-scheme notice and eligibility rules were not verified. Check the official state scholarship portal before relying on this listing.',
    deadline = NULL,
    deadline_note = 'The earlier listed date has passed; the next application cycle is not verified.',
    apply_url = 'https://telanganaepass.cgg.gov.in/'
WHERE name = 'TS Merit Scholarship';

UPDATE scholarships
SET eligibility = 'INSPIRE eligibility depends on the current DST scheme notice, qualifying marks and eligible science degree. Check the official portal.',
    deadline = NULL,
    deadline_note = 'The current application deadline was not verified. Check the latest INSPIRE notice.',
    apply_url = 'https://online-inspire.gov.in/'
WHERE name = 'Inspire Scholarship';

INSERT INTO entrance_exams (id, name, levels, streams, eligibility, deadline, deadline_note, application_url, conducting_authority)
VALUES
    (1, 'TG EAPCET', '["12th"]', '["Science-MPC","Science-BiPC"]', 'Intermediate or equivalent with the subject combination required by the selected engineering, agriculture or pharmacy course.', NULL, 'The next application dates are not verified here. Check the official Telangana notification.', 'https://eapcet.tgche.ac.in/', 'TGCHE / Telangana State Council of Higher Education'),
    (2, 'TG ECET', '["Diploma"]', '["Science-MPC","Engineering"]', 'A relevant diploma or B.Sc. Mathematics qualification may be required for lateral-entry admission; confirm the current prospectus.', NULL, 'The next application dates are not verified here. Check the official Telangana notification.', 'https://ecet.tgche.ac.in/', 'TGCHE / Telangana State Council of Higher Education'),
    (3, 'Telangana POLYCET', '["10th"]', '["Science-MPC","Science-BiPC","Commerce","Arts"]', 'Students who have passed or are appearing for SSC or an equivalent examination; subject and age rules depend on the current prospectus.', NULL, 'Check the official site for the next application schedule and current eligibility.', 'https://www.polycet.sbtet.telangana.gov.in/', 'State Board of Technical Education and Training, Telangana'),
    (4, 'JEE Main', '["12th"]', '["Science-MPC"]', 'Class 12 or equivalent with the subjects required for the chosen engineering programme. Year-of-passing and attempt rules change; check the current bulletin.', NULL, 'Check the current NTA bulletin for session dates and application deadlines.', 'https://jeemain.nta.nic.in/', 'National Testing Agency'),
    (5, 'NEET UG', '["12th"]', '["Science-BiPC"]', 'Class 12 or equivalent with the prescribed Physics, Chemistry and Biology subjects; category and age rules are set in the current bulletin.', NULL, 'Check the current NTA bulletin for application dates and eligibility.', 'https://neet.nta.nic.in/', 'National Testing Agency'),
    (6, 'CUET UG', '["12th"]', '["Science-MPC","Science-BiPC","Commerce","Arts"]', 'Class 12 or equivalent. Subject combinations and minimum marks depend on the participating university and programme.', NULL, 'Check the current NTA notice and the eligibility rules of each university.', 'https://cuet.nta.nic.in/', 'National Testing Agency'),
    (7, 'CLAT UG', '["12th"]', '["Science-MPC","Science-BiPC","Commerce","Arts"]', 'Class 12 or equivalent; minimum marks and category relaxations are defined by the current Consortium notification.', NULL, 'Check the Consortium site for the current application window and exam cycle.', 'https://consortiumofnlus.ac.in/', 'Consortium of National Law Universities'),
    (8, 'ICAI Foundation', '["12th"]', '["Science-MPC","Science-BiPC","Commerce","Arts"]', 'Class 12 or equivalent and registration with ICAI; registration cut-offs and attempt rules apply.', NULL, 'Check ICAI for registration cut-offs and examination dates.', 'https://www.icai.org/', 'Institute of Chartered Accountants of India'),
    (9, 'GATE', '["UG","PG"]', '["Science-MPC","Engineering"]', 'Eligibility depends on the qualifying degree or programme and the current GATE information brochure.', NULL, 'Check the official GATE site for the current application and exam schedule.', 'https://gate2026.iitg.ac.in/', 'GATE organizing institute / IIT Guwahati'),
    (10, 'CAT', '["UG","PG"]', '["Science-MPC","Science-BiPC","Commerce","Arts"]', 'A bachelor degree with the minimum marks prescribed in the current CAT notification; category relaxations apply.', NULL, 'Check the official CAT portal for the current application dates and eligibility.', 'https://iimcat.ac.in/', 'Indian Institutes of Management'),
    (11, 'UPSC Civil Services Examination', '["UG","PG"]', '["Science-MPC","Science-BiPC","Commerce","Arts"]', 'A bachelor degree is generally required. Age, attempt and category rules are defined in the current UPSC notification.', NULL, 'Check the current UPSC annual calendar and examination notification.', 'https://upsc.gov.in/', 'Union Public Service Commission')
ON CONFLICT (id) DO NOTHING;

INSERT INTO study_guidance (stage, title, overview, stream_options, course_options, entrance_exam_ids, higher_education_options, career_paths, official_links)
VALUES
    (
      'after-10th',
      'After Class 10',
      'Compare Intermediate, diploma and vocational routes. Choose based on the subjects you want to study and the kind of work you want to explore; each route can lead to further study.',
      '["Intermediate MPC","Intermediate BiPC","Commerce","Arts and Humanities","Polytechnic Diploma","ITI and vocational training"]',
      '["Two-year Intermediate programme","Engineering or technology diploma","ITI trade certificate","Vocational and skill-based programmes"]',
      '[3]',
      '["Intermediate followed by a degree or professional course","Diploma followed by lateral-entry engineering or a specialist degree","ITI or vocational training followed by apprenticeship and further certifications"]',
      '["Engineering and technology","Healthcare and life sciences","Commerce, finance and business","Design, media and public service","Skilled technical trades"]',
      '[{"label":"Telangana POLYCET","url":"https://www.polycet.sbtet.telangana.gov.in/"}]'
    ),
    (
      'after-12th',
      'After Class 12',
      'Your subject choices, interests and eligibility determine the options open to you. Compare degree, professional, technical and vocational routes before choosing an entrance exam.',
      '["Science MPC","Science BiPC","Commerce","Arts and Humanities","Vocational and skill-based pathways"]',
      '["B.Tech, B.E. and applied science degrees","Medicine, allied health and life-science degrees","B.Com, BBA, economics and professional accounting","Law, humanities, design, education and social sciences"]',
      '[1,4,5,6,7,8]',
      '["Undergraduate degree","Professional qualification such as CA","Integrated or specialist degree","Diploma or certificate followed by further study"]',
      '["Software and engineering","Healthcare and research","Finance, accounting and business","Law, education, design and public service"]',
      '[{"label":"TG EAPCET","url":"https://eapcet.tgche.ac.in/"},{"label":"JEE Main","url":"https://jeemain.nta.nic.in/"},{"label":"NEET UG","url":"https://neet.nta.nic.in/"},{"label":"CUET UG","url":"https://cuet.nta.nic.in/"}]'
    ),
    (
      'after-diploma',
      'After a Diploma',
      'A diploma can lead to employment, advanced certification or degree study. Engineering diploma holders may be eligible for lateral entry, subject to the current state admission rules.',
      '["Engineering lateral entry","Applied technology","Business and management","Specialist vocational training"]',
      '["B.E. or B.Tech lateral-entry degree","Advanced diploma or specialist certification","BCA, applied science or management degree where eligible","Apprenticeship and industry certification"]',
      '[2]',
      '["Lateral-entry undergraduate degree","Advanced technical qualification","Apprenticeship followed by specialist certifications","Employment with ongoing professional learning"]',
      '["Engineering and manufacturing","IT and software support","Infrastructure and technical services","Applied design and operations"]',
      '[{"label":"TG ECET","url":"https://ecet.tgche.ac.in/"},{"label":"Telangana POLYCET","url":"https://www.polycet.sbtet.telangana.gov.in/"}]'
    ),
    (
      'after-graduation',
      'After Graduation',
      'Graduates can deepen a subject, move into a professional qualification, prepare for public service or build experience through work and projects. Admission and exam requirements vary by programme.',
      '["Technology and engineering","Science and research","Finance and business","Law and public service","Education and social impact"]',
      '["Master degree or research programme","MBA and management programmes","Professional qualifications and certifications","Teacher training, law or public-service preparation"]',
      '[9,10,11]',
      '["Postgraduate degree","Research and doctoral study","Professional certification","Employment, public-service or entrepreneurship route"]',
      '["Specialist and leadership roles","Research and higher education","Public administration and policy","Finance, law, business and technology"]',
      '[{"label":"GATE","url":"https://gate2026.iitg.ac.in/"},{"label":"CAT","url":"https://iimcat.ac.in/"},{"label":"UPSC","url":"https://upsc.gov.in/"}]'
    )
ON CONFLICT (stage) DO NOTHING;

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Python and Problem Solving Foundations', 'SmartCareer Guide Learning Lab', 'Programming', 'beginner', '["Python","Problem Solving","Git"]', '8 weeks', 'Free', 'Self-paced', 'Build the programming foundation used across software, data, and AI pathways with guided practice projects.', '["Science-MPC","Science-MPC+CS","Commerce"]', '[1,2,6,9]', 'https://www.python.org/about/gettingstarted/'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Python and Problem Solving Foundations');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'SQL, Excel and Data Storytelling', 'SmartCareer Guide Learning Lab', 'Data and Analytics', 'beginner', '["SQL","Excel","Statistics","Data Visualization"]', '6 weeks', 'Free', 'Project-based', 'Learn to turn messy data into clear decisions through spreadsheets, SQL queries, and a practical dashboard project.', '["Science-MPC","Science-MPC+CS","Commerce"]', '[2,6]', 'https://sqlbolt.com/'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'SQL, Excel and Data Storytelling');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Web Development with React', 'SmartCareer Guide Learning Lab', 'Web Development', 'intermediate', '["HTML","CSS","JavaScript","React"]', '10 weeks', 'Free', 'Project-based', 'Create responsive web products and a portfolio project that demonstrates practical frontend skills.', '["Science-MPC","Science-MPC+CS","Commerce","Arts"]', '[1,8]', 'https://react.dev/learn'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Web Development with React');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Machine Learning and Model Thinking', 'SmartCareer Guide Learning Lab', 'Artificial Intelligence', 'advanced', '["Python","Statistics","Machine Learning","Model Evaluation"]', '12 weeks', 'Free', 'Guided projects', 'Understand how predictive models are trained, evaluated, and used responsibly in real-world decisions.', '["Science-MPC","Science-MPC+CS"]', '[6]', 'https://developers.google.com/machine-learning/crash-course'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Machine Learning and Model Thinking');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Cybersecurity Essentials', 'SmartCareer Guide Learning Lab', 'Cybersecurity', 'intermediate', '["Networking","Linux","Security Basics","Threat Awareness"]', '8 weeks', 'Free', 'Self-paced', 'Learn how networks, systems, and common threats work before progressing to ethical security practice.', '["Science-MPC","Science-MPC+CS"]', '[9]', 'https://www.cisa.gov/resources-tools/resources/cyber-safety'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Cybersecurity Essentials');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Accounting, GST and Financial Reporting', 'SmartCareer Guide Learning Lab', 'Finance', 'beginner', '["Accounting","GST","Tally","Financial Reporting"]', '8 weeks', 'Free', 'Practice-led', 'Build a practical base for commerce careers with bookkeeping, GST concepts, and financial reporting exercises.', '["Commerce","Science-MPC"]', '[5]', 'https://www.icai.org/'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Accounting, GST and Financial Reporting');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Digital Marketing and Portfolio Building', 'SmartCareer Guide Learning Lab', 'Marketing', 'beginner', '["Content","SEO","Analytics","Social Media"]', '6 weeks', 'Free', 'Portfolio-led', 'Plan campaigns, measure outcomes, and assemble a portfolio that demonstrates creative and analytical thinking.', '["Commerce","Arts","Science-MPC","Science-BiPC"]', '[8]', 'https://skillshop.withgoogle.com/'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Digital Marketing and Portfolio Building');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Communication and Presentation for Careers', 'SmartCareer Guide Learning Lab', 'Professional Skills', 'beginner', '["Communication","Presentation","Interview Skills"]', '4 weeks', 'Free', 'Practice-led', 'Strengthen the communication skills that help in interviews, college applications, teamwork, and early career roles.', '["Science-MPC","Science-MPC+CS","Science-BiPC","Commerce","Arts"]', '[1,2,4,5,7,8]', 'https://www.ncs.gov.in/'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Communication and Presentation for Careers');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Biology and Human Health Foundations', 'SmartCareer Guide Learning Lab', 'Health Sciences', 'beginner', '["Cell Biology","Human Physiology","Scientific Literacy"]', '8 weeks', 'Free', 'Guided study', 'Build a strong biology foundation and learn to read health and life-science information critically before choosing a clinical or research pathway.', '["Science-BiPC"]', '[4,10]', 'https://www.khanacademy.org/science/biology'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Biology and Human Health Foundations');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Pharmacy and Medicines Safety Basics', 'SmartCareer Guide Learning Lab', 'Health Sciences', 'beginner', '["Pharmacology Basics","Medicine Safety","Patient Communication"]', '6 weeks', 'Free', 'Case-based', 'Explore how medicines are used safely, how pharmacists support patients, and what to study before entering pharmacy training.', '["Science-BiPC"]', '[4,10]', 'https://www.nptel.ac.in/'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Pharmacy and Medicines Safety Basics');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Agriculture, Food Systems and Sustainability', 'SmartCareer Guide Learning Lab', 'Agriculture and Environment', 'beginner', '["Plant Science","Food Systems","Sustainability","Research"]', '7 weeks', 'Free', 'Project-based', 'Study how science supports farming, food security, and sustainable communities, then create a small local observation project.', '["Science-BiPC","Arts"]', '[4,7]', 'https://www.fao.org/education/'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Agriculture, Food Systems and Sustainability');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Engineering Mathematics and Applied Problem Solving', 'SmartCareer Guide Learning Lab', 'Engineering', 'beginner', '["Algebra","Trigonometry","Calculus","Problem Solving"]', '8 weeks', 'Free', 'Practice-led', 'Refresh the mathematics used in engineering study through applied problems, visual explanations, and a short design challenge.', '["Science-MPC","Science-MPC+CS"]', '[1,3,6]', 'https://www.khanacademy.org/math'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Engineering Mathematics and Applied Problem Solving');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Electronics, Circuits and Arduino Prototyping', 'SmartCareer Guide Learning Lab', 'Engineering', 'intermediate', '["Electronics","Circuits","Arduino","Prototyping"]', '8 weeks', 'Free', 'Hands-on projects', 'Learn basic circuits and prototype a small working device, building evidence of practical problem-solving for engineering pathways.', '["Science-MPC","Science-MPC+CS"]', '[1,3]', 'https://docs.arduino.cc/learn/'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Electronics, Circuits and Arduino Prototyping');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Cloud Computing and Linux Essentials', 'SmartCareer Guide Learning Lab', 'Technology', 'intermediate', '["Linux","Networking","Cloud Concepts","Command Line"]', '6 weeks', 'Free', 'Lab-based', 'Get familiar with command-line tools, networking, and cloud concepts that support software, infrastructure, and cybersecurity careers.', '["Science-MPC","Science-MPC+CS"]', '[1,6,9]', 'https://linuxjourney.com/'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Cloud Computing and Linux Essentials');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Business, Entrepreneurship and Startup Basics', 'SmartCareer Guide Learning Lab', 'Business', 'beginner', '["Business Models","Market Research","Budgeting","Pitching"]', '6 weeks', 'Free', 'Project-based', 'Turn a simple idea into a one-page business plan by researching a customer need, testing assumptions, and preparing a short pitch.', '["Commerce","Arts"]', '[5,8]', 'https://www.startupindia.gov.in/'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Business, Entrepreneurship and Startup Basics');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Personal Finance and Financial Planning', 'SmartCareer Guide Learning Lab', 'Finance', 'beginner', '["Budgeting","Saving","Interest","Financial Decisions"]', '4 weeks', 'Free', 'Scenario-based', 'Practice everyday money decisions, compare saving and borrowing choices, and build a personal budget using realistic scenarios.', '["Commerce","Arts","Science-MPC","Science-BiPC"]', '[5]', 'https://www.rbi.org.in/'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Personal Finance and Financial Planning');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Economics and Data for Business Decisions', 'SmartCareer Guide Learning Lab', 'Economics and Analytics', 'intermediate', '["Economics","Statistics","Excel","Decision Making"]', '7 weeks', 'Free', 'Case-based', 'Use simple economic ideas and data to explain business choices, compare alternatives, and communicate a clear recommendation.', '["Commerce","Arts","Science-MPC"]', '[2,5]', 'https://www.khanacademy.org/economics-finance-domain'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Economics and Data for Business Decisions');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Legal Reasoning, Civics and Case Research', 'SmartCareer Guide Learning Lab', 'Law and Public Service', 'beginner', '["Legal Reasoning","Civics","Research","Writing"]', '6 weeks', 'Free', 'Reading and writing practice', 'Explore legal reasoning and civic systems through structured reading, case summaries, and evidence-based argument practice.', '["Arts","Commerce"]', '[7,8]', 'https://legislative.gov.in/'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Legal Reasoning, Civics and Case Research');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Creative Writing, Journalism and Research', 'SmartCareer Guide Learning Lab', 'Arts and Communication', 'beginner', '["Writing","Interviewing","Research","Editing"]', '6 weeks', 'Free', 'Portfolio-led', 'Develop clear reporting and research habits, then create a short portfolio piece based on an interview or local topic.', '["Arts","Commerce"]', '[7,8]', 'https://www.poynter.org/'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Creative Writing, Journalism and Research');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Graphic Design and Visual Communication', 'SmartCareer Guide Learning Lab', 'Design', 'beginner', '["Visual Design","Typography","Layout","Portfolio"]', '7 weeks', 'Free', 'Portfolio-led', 'Learn visual hierarchy and layout, then create a small set of original posters or social graphics for a portfolio.', '["Arts","Commerce","Science-MPC"]', '[8]', 'https://www.canva.com/designschool/'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Graphic Design and Visual Communication');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Psychology and Human Behaviour Foundations', 'SmartCareer Guide Learning Lab', 'Psychology and Social Sciences', 'beginner', '["Psychology","Observation","Ethics","Communication"]', '6 weeks', 'Free', 'Reading and reflection', 'Explore core ideas about human behaviour and learn to distinguish evidence-based psychology from common myths.', '["Arts","Science-BiPC","Commerce"]', '[7,8]', 'https://www.apa.org/education-career/k12'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Psychology and Human Behaviour Foundations');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Architecture, Drawing and Sustainable Spaces', 'SmartCareer Guide Learning Lab', 'Architecture and Design', 'beginner', '["Technical Drawing","Spatial Thinking","Sustainability","Design"]', '7 weeks', 'Free', 'Studio exercises', 'Practice spatial observation and basic drawing while considering how buildings can respond to climate, people, and place.', '["Science-MPC","Arts"]', '[3,8]', 'https://www.archdaily.com/tag/architecture-education'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Architecture, Drawing and Sustainable Spaces');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Teaching Skills and Lesson Design', 'SmartCareer Guide Learning Lab', 'Education', 'beginner', '["Lesson Planning","Communication","Assessment","Digital Learning"]', '5 weeks', 'Free', 'Practice-led', 'Learn to explain a concept, design a short lesson, and check whether learners understood it through a simple teaching demonstration.', '["Science-MPC","Science-BiPC","Commerce","Arts"]', '[7]', 'https://diksha.gov.in/'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Teaching Skills and Lesson Design');

INSERT INTO courses (title, provider, category, level, skills, duration, cost, format, description, streams, career_ids, url)
SELECT 'Project Management and Teamwork Essentials', 'SmartCareer Guide Learning Lab', 'Professional Skills', 'beginner', '["Planning","Teamwork","Time Management","Risk Awareness"]', '4 weeks', 'Free', 'Team challenge', 'Plan a small project from goal to delivery, practice team coordination, and reflect on what changed along the way.', '["Science-MPC","Science-BiPC","Commerce","Arts"]', '[1,2,3,4,5,6,7,8,9,10]', 'https://www.pmi.org/about/learn-about-pmi'
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Project Management and Teamwork Essentials');
