CREATE TABLE IF NOT EXISTS careers (
    id SERIAL PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    cluster VARCHAR(100) NOT NULL,
    streams JSONB NOT NULL DEFAULT '[]',
    salary_range VARCHAR(100),
    demand_level VARCHAR(20),
    description TEXT,
    icon_emoji VARCHAR(10),
    tags JSONB DEFAULT '[]',
    skills JSONB DEFAULT '[]',
    entry_paths JSONB DEFAULT '[]',
    local_opportunities JSONB DEFAULT '[]',
    average_salary_lpa DECIMAL(10,2),
    growth_rate VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS assessments (
    id SERIAL PRIMARY KEY,
    user_name VARCHAR(200) NOT NULL,
    status VARCHAR(20) DEFAULT 'in_progress',
    preferred_language VARCHAR(20) DEFAULT 'english',
    current_class VARCHAR(50),
    result JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);

ALTER TABLE assessments ADD COLUMN IF NOT EXISTS student_stream VARCHAR(120);

CREATE TABLE IF NOT EXISTS jobs (
    id SERIAL PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    company VARCHAR(200) NOT NULL,
    type VARCHAR(20) NOT NULL,
    location VARCHAR(200),
    remote BOOLEAN DEFAULT FALSE,
    stipend VARCHAR(100),
    description TEXT,
    eligibility TEXT,
    apply_url VARCHAR(500),
    deadline VARCHAR(100),
    trust_score INTEGER DEFAULT 80
);

CREATE TABLE IF NOT EXISTS scholarships (
    id SERIAL PRIMARY KEY,
    name VARCHAR(300) NOT NULL,
    provider VARCHAR(200) NOT NULL,
    level JSONB DEFAULT '[]',
    categories JSONB DEFAULT '[]',
    amount VARCHAR(200),
    description TEXT,
    eligibility TEXT,
    deadline VARCHAR(100),
    deadline_note TEXT,
    apply_url VARCHAR(500),
    state VARCHAR(100)
);

ALTER TABLE scholarships ADD COLUMN IF NOT EXISTS eligibility TEXT;
ALTER TABLE scholarships ADD COLUMN IF NOT EXISTS deadline_note TEXT;

CREATE TABLE IF NOT EXISTS courses (
    id SERIAL PRIMARY KEY,
    title VARCHAR(300) NOT NULL,
    provider VARCHAR(200) NOT NULL,
    category VARCHAR(120) NOT NULL,
    level VARCHAR(30) NOT NULL,
    skills JSONB DEFAULT '[]',
    duration VARCHAR(100),
    cost VARCHAR(100),
    format VARCHAR(100),
    description TEXT,
    streams JSONB DEFAULT '[]',
    career_ids JSONB DEFAULT '[]',
    url VARCHAR(500)
);

CREATE TABLE IF NOT EXISTS entrance_exams (
    id INTEGER PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    levels JSONB NOT NULL DEFAULT '[]',
    streams JSONB NOT NULL DEFAULT '[]',
    eligibility TEXT NOT NULL,
    deadline VARCHAR(100),
    deadline_note TEXT NOT NULL,
    application_url VARCHAR(500) NOT NULL,
    conducting_authority VARCHAR(200) NOT NULL
);

CREATE TABLE IF NOT EXISTS study_guidance (
    stage VARCHAR(40) PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    overview TEXT NOT NULL,
    stream_options JSONB NOT NULL DEFAULT '[]',
    course_options JSONB NOT NULL DEFAULT '[]',
    entrance_exam_ids JSONB NOT NULL DEFAULT '[]',
    higher_education_options JSONB NOT NULL DEFAULT '[]',
    career_paths JSONB NOT NULL DEFAULT '[]',
    official_links JSONB NOT NULL DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS student_workspaces (
    student_id VARCHAR(36) PRIMARY KEY,
    workspace_json JSONB NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS chat_sessions (
    id VARCHAR(100) PRIMARY KEY,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS chat_messages (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL,
    role VARCHAR(20) NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);
