import { Switch, Route, Router as WouterRouter, Link, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useState } from "react";
import { ProfileProvider, useProfile } from "@/context/ProfileContext";
import ProfileModal from "@/components/ProfileModal";
import NotificationsPanel from "@/components/NotificationsPanel";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home";
import AssessmentPage from "@/pages/assessment";
import CareersPage from "@/pages/careers";
import CareerDetailPage from "@/pages/career-detail";
import RoadmapPage from "@/pages/roadmap";
import JobsPage from "@/pages/jobs";
import ScholarshipsPage from "@/pages/scholarships";
import ChatPage from "@/pages/chat";
import DashboardPage from "@/pages/dashboard";
import IntelligencePage from "@/pages/intelligence";
import CoursesPage from "@/pages/courses";
import GuidancePage from "@/pages/guidance";
import SkillGapPage from "@/pages/skill-gap";
import ExamsPage from "@/pages/exams";

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, staleTime: 30000 } },
});

const NAV_ITEMS = [
  { path: "/", label: "Home", icon: "◎" },
  { path: "/dashboard", label: "Dashboard", icon: "▦" },
  { path: "/guidance", label: "Study guidance", icon: "↗" },
  { path: "/skill-gap", label: "Skill gap", icon: "◇" },
  { path: "/exams", label: "Entrance exams", icon: "▤" },
  { path: "/intelligence", label: "Career Intelligence", icon: "◒" },
  { path: "/courses", label: "Learning Studio", icon: "◇" },
  { path: "/assessment", label: "Career Quiz", icon: "✦" },
  { path: "/careers", label: "Explore Careers", icon: "⊞" },
  { path: "/roadmap/1", label: "Roadmaps", icon: "→" },
  { path: "/jobs", label: "Jobs & Internships", icon: "⊡" },
  { path: "/scholarships", label: "Scholarships", icon: "⊛" },
  { path: "/chat", label: "AI Counselor", icon: "◈" },
];

function ProfileBanner({ onOpen }: { onOpen: () => void }) {
  const [dismissed, setDismissed] = useState(false);
  const { profile } = useProfile();

  if (profile.completed || dismissed) return null;

  return (
    <div className="mx-4 mt-4 mb-0 rounded-2xl bg-gradient-to-r from-primary to-primary/80 text-primary-foreground shadow-sm overflow-hidden">
      <div className="flex items-center gap-4 px-5 py-3.5">
        {/* Icon */}
        <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center shrink-0 text-base font-bold">
          SC
        </div>

        {/* Text */}
        <div className="flex-1 min-w-0">
          <div className="font-semibold text-sm leading-tight">Set up your profile</div>
          <div className="text-xs text-primary-foreground/80 mt-0.5 leading-snug">
            Tell us your class & stream for personalised careers, scholarships and advice.
          </div>
        </div>

        {/* CTA */}
        <button
          data-testid="button-setup-profile"
          onClick={onOpen}
          className="shrink-0 bg-white text-primary font-semibold text-xs px-4 py-2 rounded-xl hover:bg-white/90 transition-colors whitespace-nowrap"
        >
          Set up →
        </button>

        {/* Dismiss */}
        <button
          onClick={() => setDismissed(true)}
          className="shrink-0 text-primary-foreground/60 hover:text-primary-foreground transition-colors text-lg leading-none ml-1"
          aria-label="Dismiss"
        >
          ×
        </button>
      </div>

      {/* Progress dots */}
      <div className="flex gap-1 px-5 pb-2.5">
        {["Name", "Class", "Stream", "District"].map((step, i) => (
          <div key={step} className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-white/30" />
            {i < 3 && <div className="w-4 h-px bg-white/20" />}
          </div>
        ))}
        <span className="text-xs text-primary-foreground/60 ml-1">4 quick steps</span>
      </div>
    </div>
  );
}

function Sidebar({
  open,
  onClose,
  onOpenProfile,
}: {
  open: boolean;
  onClose: () => void;
  onOpenProfile: () => void;
}) {
  const [location] = useLocation();
  const { profile, syncStatus } = useProfile();

  return (
    <>
      {open && (
        <div className="fixed inset-0 bg-black/40 z-40 lg:hidden" onClick={onClose} />
      )}
      <aside
        className={`fixed top-0 left-0 h-full w-64 z-50 bg-sidebar border-r border-sidebar-border transition-transform duration-300 flex flex-col
          ${open ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0 lg:static lg:z-auto`}
      >
        {/* Brand */}
        <div className="px-5 py-5 border-b border-sidebar-border">
          <Link href="/" onClick={onClose}>
            <div className="flex items-center gap-2 cursor-pointer">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-bold text-sm">
                SC
              </div>
              <div>
                <div className="font-bold text-sidebar-foreground text-sm leading-none">SmartCareer Guide</div>
                <div className="text-xs text-muted-foreground mt-0.5">Your Career Guide</div>
              </div>
            </div>
          </Link>
        </div>

        {/* Profile chip */}
        <div className="px-3 pt-3">
          {profile.completed ? (
            <button
              data-testid="button-edit-profile"
              onClick={() => { onOpenProfile(); onClose(); }}
              className="w-full flex items-center gap-2.5 bg-muted/60 hover:bg-muted rounded-xl px-3 py-2.5 text-left transition-colors group"
            >
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-sm shrink-0">
                {profile.name.charAt(0).toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs font-semibold text-foreground truncate">{profile.name}</div>
                <div className="text-xs text-muted-foreground truncate">{profile.stream || profile.currentClass}</div>
              </div>
              <span className="text-xs text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0">Edit</span>
            </button>
          ) : (
            <button
              data-testid="button-setup-profile-sidebar"
              onClick={() => { onOpenProfile(); onClose(); }}
              className="w-full flex items-center gap-2.5 border border-dashed border-primary/40 hover:border-primary hover:bg-primary/5 rounded-xl px-3 py-2.5 text-left transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary text-sm shrink-0">
                  SC
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs font-semibold text-primary">Set up profile</div>
                <div className="text-xs text-muted-foreground">Personalise your experience</div>
              </div>
            </button>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-3 overflow-y-auto">
          <div className="space-y-0.5">
            {NAV_ITEMS.map((item) => {
              const isActive = item.path === "/"
                ? location === "/"
                : location.startsWith(item.path.split("/").slice(0, 2).join("/"));
              return (
                <Link key={item.path} href={item.path} onClick={onClose}>
                  <div
                    className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer
                      ${isActive
                        ? "bg-primary text-primary-foreground"
                        : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                      }`}
                  >
                    <span className="text-base leading-none">{item.icon}</span>
                    <span>{item.label}</span>
                  </div>
                </Link>
              );
            })}
          </div>
        </nav>

        {/* Footer */}
        <div className="px-5 py-4 border-t border-sidebar-border">
          <div className="text-xs text-muted-foreground">Explore careers, skills &amp; opportunities</div>
          <div className="mt-2 flex items-center gap-2 text-[11px]" role="status" aria-live="polite" data-testid="status-workspace-sync">
            <span className={`h-1.5 w-1.5 rounded-full ${syncStatus === "synced" ? "bg-emerald-600" : syncStatus === "syncing" ? "bg-amber-500" : syncStatus === "error" ? "bg-destructive" : "bg-muted-foreground"}`} />
            {syncStatus === "synced" ? "Workspace synced" : syncStatus === "syncing" ? "Syncing workspace…" : syncStatus === "error" ? "Offline · changes saved on this device" : "Local workspace"}
          </div>
        </div>
      </aside>
    </>
  );
}

function Layout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [profileModalOpen, setProfileModalOpen] = useState(false);

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        onOpenProfile={() => setProfileModalOpen(true)}
      />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Mobile header */}
        <header className="lg:hidden flex items-center gap-3 px-4 py-3 border-b border-border bg-background sticky top-0 z-30">
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-1.5 rounded-md hover:bg-muted transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
          <span className="font-bold text-foreground flex-1">SmartCareer Guide</span>
          <NotificationsPanel />
        </header>

        {/* Desktop top bar */}
        <div className="hidden lg:flex items-center justify-end px-6 py-2.5 border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-30">
          <NotificationsPanel />
        </div>

        <main className="flex-1 overflow-y-auto">
          <ProfileBanner onOpen={() => setProfileModalOpen(true)} />
          {children}
        </main>
      </div>

      <ProfileModal open={profileModalOpen} onClose={() => setProfileModalOpen(false)} />
    </div>
  );
}

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/dashboard" component={DashboardPage} />
        <Route path="/guidance" component={GuidancePage} />
        <Route path="/skill-gap" component={SkillGapPage} />
        <Route path="/exams" component={ExamsPage} />
        <Route path="/intelligence" component={IntelligencePage} />
        <Route path="/courses" component={CoursesPage} />
        <Route path="/assessment" component={AssessmentPage} />
        <Route path="/careers" component={CareersPage} />
        <Route path="/careers/:id" component={CareerDetailPage} />
        <Route path="/roadmap/:careerId" component={RoadmapPage} />
        <Route path="/jobs" component={JobsPage} />
        <Route path="/scholarships" component={ScholarshipsPage} />
        <Route path="/chat" component={ChatPage} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <ProfileProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </ProfileProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
