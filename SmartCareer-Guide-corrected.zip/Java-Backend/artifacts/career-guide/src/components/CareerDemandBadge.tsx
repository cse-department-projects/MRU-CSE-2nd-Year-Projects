import { Badge } from "@/components/ui/badge";

const LABELS: Record<string, string> = {
  high: "High Demand",
  medium: "Growing",
  low: "Steady",
  varies: "Outlook varies",
};

const STYLES: Record<string, string> = {
  high: "bg-green-100 text-green-700 border-green-200",
  medium: "bg-yellow-100 text-yellow-700 border-yellow-200",
  low: "bg-gray-100 text-gray-600 border-gray-200",
  varies: "bg-slate-100 text-slate-600 border-slate-200",
};

export function CareerDemandBadge({
  level,
  className = "",
}: {
  level?: string | null;
  className?: string;
}) {
  const normalizedLevel = level?.toLowerCase() ?? "varies";
  const label = LABELS[normalizedLevel] ?? LABELS.varies;
  const style = STYLES[normalizedLevel] ?? STYLES.varies;

  return (
    <Badge variant="secondary" className={`${style} ${className}`}>
      {label}
    </Badge>
  );
}
