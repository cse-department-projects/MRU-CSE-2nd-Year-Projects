import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import { useGetDashboard } from "@workspace/api-client-react";

interface DeadlineItem {
  id: string;
  title: string;
  subtitle: string;
  date: string;
  isoDate: string;
  type: "scholarship" | "exam" | "job" | "application";
  link: string;
  urgent?: boolean;
}

const STATIC_DEADLINES: DeadlineItem[] = [
  {
    id: "ts-epass-2026",
    title: "TS ePass Scholarship",
    subtitle: "Apply for SC/ST/BC/EWS fee reimbursement",
    date: "Sep 30, 2026",
    isoDate: "2026-09-30",
    type: "scholarship",
    link: "/scholarships",
  },
  {
    id: "pm-yasasvi-2026",
    title: "PM Yasasvi Scholarship",
    subtitle: "OBC/EBC students — ₹75,000–1,25,000/year",
    date: "Oct 31, 2026",
    isoDate: "2026-10-31",
    type: "scholarship",
    link: "/scholarships",
  },
  {
    id: "jee-main-reg-2027",
    title: "JEE Mains Registration",
    subtitle: "Session 1 registration opens — IIT/NIT/IIIT",
    date: "Nov 15, 2026",
    isoDate: "2026-11-15",
    type: "exam",
    link: "/scholarships",
  },
  {
    id: "neet-reg-2027",
    title: "NEET UG Registration",
    subtitle: "Medical entrance — MBBS/BDS/BAMS",
    date: "Feb 7, 2027",
    isoDate: "2027-02-07",
    type: "exam",
    link: "/scholarships",
  },
  {
    id: "eamcet-reg-2027",
    title: "TS EAMCET Registration",
    subtitle: "Telangana Engineering & Medical entrance",
    date: "Mar 1, 2027",
    isoDate: "2027-03-01",
    type: "exam",
    link: "/scholarships",
  },
  {
    id: "tspsc-group2-2026",
    title: "TSPSC Group-2 Exam",
    subtitle: "Telangana state government jobs",
    date: "Oct 20, 2026",
    isoDate: "2026-10-20",
    type: "application",
    link: "/jobs",
  },
];

export function getDaysRemaining(isoDate: string): number {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(isoDate);
  target.setHours(0, 0, 0, 0);
  return Math.ceil((target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

export function getUrgencyLevel(days: number): "critical" | "urgent" | "upcoming" | "future" {
  if (days <= 7) return "critical";
  if (days <= 30) return "urgent";
  if (days <= 90) return "upcoming";
  return "future";
}

const URGENCY_STYLES = {
  critical: { dot: "bg-red-500", badge: "bg-red-100 text-red-700 border-red-200", label: "days left!" },
  urgent: { dot: "bg-orange-500", badge: "bg-orange-100 text-orange-700 border-orange-200", label: "days left" },
  upcoming: { dot: "bg-primary", badge: "bg-primary/10 text-primary border-primary/20", label: "days" },
  future: { dot: "bg-muted-foreground/30", badge: "bg-muted text-muted-foreground border-border", label: "days" },
};

const TYPE_ICONS: Record<string, string> = {
  scholarship: "⊛",
  exam: "✦",
  job: "⊡",
  application: "⊡",
};

const SEEN_KEY = "scg_seen_notifications";

function getSeenIds(): Set<string> {
  try { return new Set(JSON.parse(localStorage.getItem(SEEN_KEY) ?? "[]")); }
  catch { return new Set(); }
}

function markAllSeen(ids: string[]) {
  localStorage.setItem(SEEN_KEY, JSON.stringify(ids));
}

export function useNotifications() {
  const activeDeadlines = STATIC_DEADLINES.filter((d) => getDaysRemaining(d.isoDate) >= 0)
    .sort((a, b) => getDaysRemaining(a.isoDate) - getDaysRemaining(b.isoDate));

  const seenIds = getSeenIds();
  const unseenCount = activeDeadlines.filter((d) => !seenIds.has(d.id)).length;

  return { activeDeadlines, unseenCount };
}

export default function NotificationsPanel() {
  const [open, setOpen] = useState(false);
  const [seenIds, setSeenIds] = useState<Set<string>>(getSeenIds);
  const panelRef = useRef<HTMLDivElement>(null);

  const { activeDeadlines, unseenCount } = useNotifications();
  const badgeCount = unseenCount;

  // Close on outside click
  useEffect(() => {
    function handle(e: MouseEvent) {
      if (panelRef.current && !panelRef.current.contains(e.target as Node)) setOpen(false);
    }
    if (open) document.addEventListener("mousedown", handle);
    return () => document.removeEventListener("mousedown", handle);
  }, [open]);

  const handleOpen = () => {
    setOpen((v) => !v);
    if (!open) {
      const allIds = activeDeadlines.map((d) => d.id);
      markAllSeen(allIds);
      setSeenIds(new Set(allIds));
    }
  };

  return (
    <div ref={panelRef} className="relative">
      {/* Bell button */}
      <button
        data-testid="btn-notifications"
        onClick={handleOpen}
        className="relative w-9 h-9 rounded-xl bg-muted hover:bg-muted/80 flex items-center justify-center transition-colors shrink-0"
        title="Upcoming deadlines"
      >
        <svg className="w-4.5 h-4.5 text-muted-foreground" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
        </svg>
        {badgeCount > 0 && (
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
            {badgeCount > 9 ? "9+" : badgeCount}
          </span>
        )}
      </button>

      {/* Dropdown panel */}
      {open && (
        <div className="absolute right-0 top-11 w-80 bg-card border border-card-border rounded-2xl shadow-xl z-50 overflow-hidden">
          {/* Header */}
          <div className="px-4 py-3.5 border-b border-border flex items-center justify-between">
            <div>
              <div className="font-semibold text-foreground text-sm">Upcoming Deadlines</div>
              <div className="text-xs text-muted-foreground mt-0.5">Scholarships & exam dates</div>
            </div>
            <Link href="/scholarships" onClick={() => setOpen(false)}>
              <button className="text-xs text-primary hover:underline">View all</button>
            </Link>
          </div>

          {/* List */}
          <div className="max-h-[420px] overflow-y-auto divide-y divide-border">
            {activeDeadlines.map((d) => {
              const days = getDaysRemaining(d.isoDate);
              const urgency = getUrgencyLevel(days);
              const styles = URGENCY_STYLES[urgency];
              const isNew = !seenIds.has(d.id);

              return (
                <Link key={d.id} href={d.link} onClick={() => setOpen(false)}>
                  <div
                    data-testid={`notif-${d.id}`}
                    className={`flex items-start gap-3 px-4 py-3.5 hover:bg-muted/40 transition-colors cursor-pointer
                      ${isNew ? "bg-primary/3" : ""}`}
                  >
                    {/* Icon */}
                    <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center text-sm shrink-0 mt-0.5">
                      {TYPE_ICONS[d.type]}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div className="text-sm font-medium text-foreground leading-tight">{d.title}</div>
                        {isNew && <span className="w-1.5 h-1.5 rounded-full bg-primary shrink-0 mt-1.5" />}
                      </div>
                      <div className="text-xs text-muted-foreground mt-0.5 leading-snug">{d.subtitle}</div>
                      <div className="flex items-center gap-2 mt-1.5">
                        <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${styles.badge}`}>
                          {days} {styles.label}
                        </span>
                        <span className="text-xs text-muted-foreground">{d.date}</span>
                      </div>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>

          {/* Footer */}
          <div className="px-4 py-3 border-t border-border bg-muted/20">
            <p className="text-xs text-muted-foreground text-center">
              Dates are approximate. Always verify on official sites.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
