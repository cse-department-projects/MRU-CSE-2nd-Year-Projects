import { useState, useEffect } from "react";
import { useProfile, CLASSES, STREAMS_BY_CLASS, DISTRICTS, type UserProfile } from "@/context/ProfileContext";

interface Props {
  open: boolean;
  onClose: () => void;
}

const STEPS = ["Your Name", "Class / Level", "Stream", "District"];
const splitItems = (value: string) => value.split(",").map((item) => item.trim()).filter(Boolean);

export default function ProfileModal({ open, onClose }: Props) {
  const { profile, updateProfile, resetProfile } = useProfile();
  const isSetup = !profile.completed;

  const [step, setStep] = useState(0);
  const [form, setForm] = useState<UserProfile>(profile);

  useEffect(() => {
    if (open) {
      setForm({ ...profile });
      setStep(0);
    }
  }, [open]);

  const streams = form.currentClass ? STREAMS_BY_CLASS[form.currentClass] ?? [] : [];

  const canProceed = () => {
    if (step === 0) return form.name.trim().length >= 2;
    if (step === 1) return !!form.currentClass;
    if (step === 2) return !!form.stream;
    if (step === 3) return !!form.district;
    return false;
  };

  const handleNext = () => {
    if (step === 1) setForm((f) => ({ ...f, stream: "" })); // reset stream when class changes
    if (step < STEPS.length - 1) {
      setStep((s) => s + 1);
    } else {
      updateProfile({ ...form, completed: true });
      onClose();
    }
  };

  const handleSave = () => {
    updateProfile({ ...form, completed: true });
    onClose();
  };

  if (!open) return null;

  // EDIT MODE — simple form, no steps
  if (!isSetup) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="absolute inset-0 bg-black/50" onClick={onClose} />
        <div className="relative bg-card border border-card-border rounded-2xl shadow-xl w-full max-w-sm max-h-[90vh] overflow-y-auto z-10">
          <div className="px-5 py-4 border-b border-card-border flex items-center justify-between">
            <h2 className="font-bold text-foreground">Edit Profile</h2>
            <button onClick={onClose} className="text-muted-foreground hover:text-foreground text-xl leading-none">×</button>
          </div>

          <div className="p-5 space-y-4">
            <div>
              <label className="block text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Name</label>
              <input
                data-testid="profile-input-name"
                type="text"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Class / Level</label>
              <div className="grid grid-cols-1 gap-1.5">
                {CLASSES.map((cls) => (
                  <button key={cls} onClick={() => setForm({ ...form, currentClass: cls, stream: "" })}
                    className={`text-left px-3 py-2 rounded-lg border text-sm transition-colors
                      ${form.currentClass === cls ? "border-primary bg-primary/10 text-primary font-medium" : "border-border text-muted-foreground hover:border-primary/30"}`}>
                    {cls}
                  </button>
                ))}
              </div>
            </div>

            {(STREAMS_BY_CLASS[form.currentClass] ?? []).length > 0 && (
              <div>
                <label className="block text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Stream</label>
                <div className="grid grid-cols-1 gap-1.5">
                  {(STREAMS_BY_CLASS[form.currentClass] ?? []).map((s) => (
                    <button key={s} onClick={() => setForm({ ...form, stream: s })}
                      className={`text-left px-3 py-2 rounded-lg border text-sm transition-colors
                        ${form.stream === s ? "border-primary bg-primary/10 text-primary font-medium" : "border-border text-muted-foreground hover:border-primary/30"}`}>
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">District</label>
              <div className="grid grid-cols-2 gap-1.5">
                {DISTRICTS.map((d) => (
                  <button key={d} onClick={() => setForm({ ...form, district: d })}
                    className={`text-left px-3 py-2 rounded-lg border text-xs transition-colors
                      ${form.district === d ? "border-primary bg-primary/10 text-primary font-medium" : "border-border text-muted-foreground hover:border-primary/30"}`}>
                    {d}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Interests</label>
              <input aria-label="Interests, comma separated" value={form.interests.join(", ")} onChange={(e) => setForm({ ...form, interests: splitItems(e.target.value) })} placeholder="Design, healthcare, technology" className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background text-foreground" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Skills</label>
              <input aria-label="Skills, comma separated" value={form.skills.join(", ")} onChange={(e) => setForm({ ...form, skills: splitItems(e.target.value) })} placeholder="Problem solving, writing" className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background text-foreground" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Goals</label>
              <input aria-label="Goals, comma separated" value={form.goals.join(", ")} onChange={(e) => setForm({ ...form, goals: splitItems(e.target.value) })} placeholder="Study engineering, find a scholarship" className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background text-foreground" />
            </div>
          </div>

          <div className="px-5 py-4 border-t border-card-border flex items-center justify-between gap-3">
            <button onClick={() => { resetProfile(); onClose(); }}
              className="text-xs text-muted-foreground hover:text-destructive transition-colors">
              Reset profile
            </button>
            <button data-testid="button-save-profile" onClick={handleSave}
              className="bg-primary text-primary-foreground px-5 py-2 rounded-lg font-semibold text-sm hover:bg-primary/90 transition-colors">
              Save Changes
            </button>
          </div>
        </div>
      </div>
    );
  }

  // SETUP MODE — stepped wizard inside a modal
  const progress = (step / (STEPS.length - 1)) * 100;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-card border border-card-border rounded-2xl shadow-2xl w-full max-w-md z-10 overflow-hidden">
        {/* Progress bar */}
        <div className="h-1 bg-muted">
          <div className="h-full bg-primary transition-all duration-500" style={{ width: `${progress}%` }} />
        </div>

        {/* Header */}
        <div className="px-6 pt-5 pb-0 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            {STEPS.map((s, i) => (
              <div key={s} className="flex items-center gap-1.5">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-colors
                  ${i < step ? "bg-primary text-primary-foreground" : i === step ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                  {i < step ? "✓" : i + 1}
                </div>
                {i < STEPS.length - 1 && (
                  <div className={`h-px w-5 ${i < step ? "bg-primary" : "bg-muted"}`} />
                )}
              </div>
            ))}
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground text-xl leading-none">×</button>
        </div>

        <div className="px-6 py-5">
          {/* Step 0: Name */}
          {step === 0 && (
            <div>
              <h2 className="text-xl font-bold text-foreground mb-1">What should we call you?</h2>
              <p className="text-sm text-muted-foreground mb-5">We'll use this to personalise your experience.</p>
              <input
                data-testid="input-name"
                type="text"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                onKeyDown={(e) => e.key === "Enter" && canProceed() && handleNext()}
                placeholder="Enter your name"
                autoFocus
                className="w-full border border-input rounded-xl px-4 py-3 text-sm bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
          )}

          {/* Step 1: Class */}
          {step === 1 && (
            <div>
              <h2 className="text-xl font-bold text-foreground mb-1">Hi, {form.name.split(" ")[0]}. Which class are you in?</h2>
              <p className="text-sm text-muted-foreground mb-4">This helps us show the right career paths for you.</p>
              <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1">
                {CLASSES.map((cls) => (
                  <button key={cls} onClick={() => setForm({ ...form, currentClass: cls, stream: "" })}
                    className={`w-full text-left px-4 py-2.5 rounded-xl border text-sm font-medium transition-all
                      ${form.currentClass === cls ? "border-primary bg-primary/10 text-primary" : "border-border bg-background text-foreground hover:border-primary/40 hover:bg-muted/50"}`}>
                    {cls}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 2: Stream */}
          {step === 2 && (
            <div>
              <h2 className="text-xl font-bold text-foreground mb-1">Your stream</h2>
              <p className="text-sm text-muted-foreground mb-4">Which subject group are you studying?</p>
              <div className="space-y-1.5">
                {streams.map((s) => (
                  <button key={s} onClick={() => setForm({ ...form, stream: s })}
                    className={`w-full text-left px-4 py-2.5 rounded-xl border text-sm font-medium transition-all
                      ${form.stream === s ? "border-primary bg-primary/10 text-primary" : "border-border bg-background text-foreground hover:border-primary/40 hover:bg-muted/50"}`}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 3: District */}
          {step === 3 && (
            <div>
              <h2 className="text-xl font-bold text-foreground mb-1">Where are you from?</h2>
              <p className="text-sm text-muted-foreground mb-4">Shows local scholarships and opportunities near you.</p>
              <div className="grid grid-cols-2 gap-1.5 max-h-64 overflow-y-auto pr-1">
                {DISTRICTS.map((d) => (
                  <button key={d} onClick={() => setForm({ ...form, district: d })}
                    className={`text-left px-3 py-2.5 rounded-xl border text-sm font-medium transition-all
                      ${form.district === d ? "border-primary bg-primary/10 text-primary" : "border-border bg-background text-foreground hover:border-primary/40 hover:bg-muted/50"}`}>
                    {d}
                  </button>
                ))}
              </div>
              <div className="mt-4 space-y-3">
                <input aria-label="Interests, comma separated" value={form.interests.join(", ")} onChange={(e) => setForm({ ...form, interests: splitItems(e.target.value) })} placeholder="Interests, separated by commas" className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background text-foreground" />
                <input aria-label="Skills, comma separated" value={form.skills.join(", ")} onChange={(e) => setForm({ ...form, skills: splitItems(e.target.value) })} placeholder="Skills you already have" className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background text-foreground" />
                <input aria-label="Goals, comma separated" value={form.goals.join(", ")} onChange={(e) => setForm({ ...form, goals: splitItems(e.target.value) })} placeholder="Goals for your next step" className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background text-foreground" />
              </div>
            </div>
          )}

          {/* Navigation */}
          <div className="flex items-center justify-between mt-6">
            {step > 0 ? (
              <button onClick={() => setStep((s) => s - 1)}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                ← Back
              </button>
            ) : (
              <p className="text-xs text-muted-foreground">Your name and district stay on this device.</p>
            )}
            <button
              data-testid="button-next"
              onClick={handleNext}
              disabled={!canProceed()}
              className="bg-primary text-primary-foreground px-6 py-2.5 rounded-xl font-semibold text-sm hover:bg-primary/90 transition-colors disabled:opacity-40"
            >
              {step === STEPS.length - 1 ? "Start Exploring →" : "Next →"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
