import { createContext, useContext, useState, useEffect, type ReactNode } from "react";
import { getGetStudentWorkspaceQueryKey, useGetStudentWorkspace, useSaveStudentWorkspace } from "@workspace/api-client-react";

export interface ViewedCareer {
  id: number;
  title: string;
  cluster: string;
  salaryRange: string;
  viewedAt: string;
}

export interface BookmarkedCareer {
  id: number;
  title: string;
  cluster: string;
  salaryRange: string;
}

export interface QuizResult {
  personalityLabel: string;
  description: string;
  careerClusters: string[];
  strengths: string[];
  takenAt: string;
  topCareers: BookmarkedCareer[];
}

export interface UserProfile {
  name: string;
  currentClass: string;
  stream: string;
  district: string;
  completed: boolean;
  viewedCareers: ViewedCareer[];
  bookmarkedCareers: BookmarkedCareer[];
  quizResults: QuizResult[];
  practicedSkills: string[];
  interests: string[];
  skills: string[];
  goals: string[];
  roadmapProgress: Record<string, string[]>;
  skillGapProgress: Record<string, string[]>;
}

const DEFAULT_PROFILE: UserProfile = {
  name: "",
  currentClass: "",
  stream: "",
  district: "",
  completed: false,
  viewedCareers: [],
  bookmarkedCareers: [],
  quizResults: [],
  practicedSkills: [],
  interests: [],
  skills: [],
  goals: [],
  roadmapProgress: {},
  skillGapProgress: {},
};

const STORAGE_KEY = "scg_profile";

interface ProfileContextValue {
  profile: UserProfile;
  updateProfile: (updates: Partial<UserProfile>) => void;
  resetProfile: () => void;
  trackViewedCareer: (career: Omit<ViewedCareer, "viewedAt">) => void;
  toggleBookmark: (career: BookmarkedCareer) => void;
  isBookmarked: (id: number) => boolean;
  saveQuizResult: (result: Omit<QuizResult, "takenAt">) => void;
  togglePracticedSkill: (skill: string) => void;
  studentId: string;
  syncStatus: "local" | "syncing" | "synced" | "error";
  toggleRoadmapStep: (careerId: number, stepId: string) => void;
  toggleSkillGapItem: (careerId: number, itemId: string) => void;
}

const ProfileContext = createContext<ProfileContextValue>({
  profile: DEFAULT_PROFILE,
  updateProfile: () => {},
  resetProfile: () => {},
  trackViewedCareer: () => {},
  toggleBookmark: () => {},
  isBookmarked: () => false,
  saveQuizResult: () => {},
  togglePracticedSkill: () => {},
  studentId: "",
  syncStatus: "local",
  toggleRoadmapStep: () => {},
  toggleSkillGapItem: () => {},
});

const STUDENT_ID_KEY = "scg_student_id";
function getStudentId() {
  try {
    let id = localStorage.getItem(STUDENT_ID_KEY);
    if (!id) {
      id = crypto.randomUUID();
      localStorage.setItem(STUDENT_ID_KEY, id);
    }
    return id;
  } catch {
    return "local-student";
  }
}

export function ProfileProvider({ children }: { children: ReactNode }) {
  const [studentId] = useState(getStudentId);
  const workspaceQuery = useGetStudentWorkspace(studentId, { query: { enabled: !!studentId, queryKey: getGetStudentWorkspaceQueryKey(studentId) } });
  const saveWorkspace = useSaveStudentWorkspace();
  const [hydrated, setHydrated] = useState(false);
  const [syncStatus, setSyncStatus] = useState<"local" | "syncing" | "synced" | "error">("local");
  const [profile, setProfile] = useState<UserProfile>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return {
          ...DEFAULT_PROFILE,
          viewedCareers: [],
          bookmarkedCareers: [],
          ...parsed,
          practicedSkills: Array.isArray(parsed.practicedSkills) ? parsed.practicedSkills : [],
          interests: Array.isArray(parsed.interests) ? parsed.interests : [],
          skills: Array.isArray(parsed.skills) ? parsed.skills : [],
          goals: Array.isArray(parsed.goals) ? parsed.goals : [],
          roadmapProgress: parsed.roadmapProgress && typeof parsed.roadmapProgress === "object" ? parsed.roadmapProgress : {},
          skillGapProgress: parsed.skillGapProgress && typeof parsed.skillGapProgress === "object" ? parsed.skillGapProgress : {},
          quizResults: Array.isArray(parsed.quizResults)
            ? parsed.quizResults.map((result: Partial<QuizResult>) => ({
                ...result,
                topCareers: Array.isArray(result.topCareers) ? result.topCareers : [],
              }))
            : [],
        };
      }
    } catch {}
    return DEFAULT_PROFILE;
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    if (workspaceQuery.data) {
      const workspace = workspaceQuery.data;
      setProfile((prev) => ({
        ...prev,
        currentClass: workspace.profile.currentClass || prev.currentClass,
        stream: workspace.profile.stream || prev.stream,
        interests: workspace.profile.interests?.length ? workspace.profile.interests : prev.interests,
        skills: workspace.profile.skills?.length ? workspace.profile.skills : prev.skills,
        goals: workspace.profile.goals?.length ? workspace.profile.goals : prev.goals,
        roadmapProgress: workspace.roadmapProgress || prev.roadmapProgress,
        skillGapProgress: workspace.skillGapProgress || prev.skillGapProgress,
      }));
      setHydrated(true);
      setSyncStatus("synced");
    } else if (workspaceQuery.isError) {
      setHydrated(true);
      setSyncStatus("error");
    }
  }, [workspaceQuery.data, workspaceQuery.isError]);

  useEffect(() => {
    if (!hydrated) return;
    const timer = window.setTimeout(() => {
      setSyncStatus("syncing");
      saveWorkspace.mutate(
        {
          studentId,
          data: {
            profile: {
              currentClass: profile.currentClass,
              stream: profile.stream,
              interests: profile.interests,
              skills: profile.skills,
              goals: profile.goals,
            },
            roadmapProgress: profile.roadmapProgress,
            skillGapProgress: profile.skillGapProgress,
          },
        },
        {
          onSuccess: () => setSyncStatus("synced"),
          onError: () => setSyncStatus("error"),
        },
      );
    }, 700);
    return () => window.clearTimeout(timer);
  }, [hydrated, profile.currentClass, profile.stream, profile.interests, profile.skills, profile.goals, profile.roadmapProgress, profile.skillGapProgress]);

  const updateProfile = (updates: Partial<UserProfile>) => {
    setProfile((prev) => ({ ...prev, ...updates }));
  };

  const resetProfile = () => {
    localStorage.removeItem(STORAGE_KEY);
    setProfile(DEFAULT_PROFILE);
  };

  const trackViewedCareer = (career: Omit<ViewedCareer, "viewedAt">) => {
    setProfile((prev) => {
      const already = prev.viewedCareers.find((c) => c.id === career.id);
      if (already) {
        return {
          ...prev,
          viewedCareers: [
            { ...career, viewedAt: new Date().toISOString() },
            ...prev.viewedCareers.filter((c) => c.id !== career.id),
          ].slice(0, 20),
        };
      }
      return {
        ...prev,
        viewedCareers: [
          { ...career, viewedAt: new Date().toISOString() },
          ...prev.viewedCareers,
        ].slice(0, 20),
      };
    });
  };

  const toggleBookmark = (career: BookmarkedCareer) => {
    setProfile((prev) => {
      const exists = prev.bookmarkedCareers.find((c) => c.id === career.id);
      return {
        ...prev,
        bookmarkedCareers: exists
          ? prev.bookmarkedCareers.filter((c) => c.id !== career.id)
          : [career, ...prev.bookmarkedCareers],
      };
    });
  };

  const isBookmarked = (id: number) =>
    profile.bookmarkedCareers.some((c) => c.id === id);

  const saveQuizResult = (result: Omit<QuizResult, "takenAt">) => {
    setProfile((prev) => ({
      ...prev,
      quizResults: [
        { ...result, takenAt: new Date().toISOString() },
        ...prev.quizResults,
      ].slice(0, 5),
    }));
  };

  const togglePracticedSkill = (skill: string) => {
    setProfile((prev) => ({
      ...prev,
      practicedSkills: prev.practicedSkills.includes(skill)
        ? prev.practicedSkills.filter((item) => item !== skill)
        : [...prev.practicedSkills, skill],
    }));
  };

  const toggleProgressItem = (collection: "roadmapProgress" | "skillGapProgress", careerId: number, itemId: string) => {
    setProfile((prev) => {
      const key = String(careerId);
      const items = prev[collection][key] ?? [];
      return {
        ...prev,
        [collection]: {
          ...prev[collection],
          [key]: items.includes(itemId) ? items.filter((item) => item !== itemId) : [...items, itemId],
        },
      };
    });
  };
  const toggleRoadmapStep = (careerId: number, stepId: string) => toggleProgressItem("roadmapProgress", careerId, stepId);
  const toggleSkillGapItem = (careerId: number, itemId: string) => toggleProgressItem("skillGapProgress", careerId, itemId);

  return (
    <ProfileContext.Provider value={{ profile, updateProfile, resetProfile, trackViewedCareer, toggleBookmark, isBookmarked, saveQuizResult, togglePracticedSkill, studentId, syncStatus, toggleRoadmapStep, toggleSkillGapItem }}>
      {children}
    </ProfileContext.Provider>
  );
}

export function useProfile() {
  return useContext(ProfileContext);
}

export const CLASSES = [
  "Class 8", "Class 9", "Class 10 (SSC)",
  "Class 11 (Inter 1st Year)", "Class 12 (Inter 2nd Year)",
  "Degree/College (UG)", "Post Graduate (PG)",
];

export const STREAMS_BY_CLASS: Record<string, string[]> = {
  "Class 8": ["Not decided yet"],
  "Class 9": ["Not decided yet"],
  "Class 10 (SSC)": ["Not decided yet"],
  "Class 11 (Inter 1st Year)": [
    "Science (MPC)",
    "Science (MPC + Computer Science)",
    "Science (BiPC)",
    "Commerce (MEC)",
    "Commerce (CEC)",
    "Arts / Humanities",
    "Vocational / Technical",
    "Not decided yet",
  ],
  "Class 12 (Inter 2nd Year)": [
    "Science (MPC)",
    "Science (MPC + Computer Science)",
    "Science (BiPC)",
    "Commerce (MEC)",
    "Commerce (CEC)",
    "Arts / Humanities",
    "Vocational / Technical",
    "Not decided yet",
  ],
  "Degree/College (UG)": [
    "Engineering / B.Tech",
    "Medical / B.Pharm",
    "Commerce / BBA / BCA",
    "Arts / BA / B.Sc",
    "Law / LLB",
    "Agriculture / Veterinary",
    "Design / Media",
    "Education / Teaching",
    "Other",
  ],
  "Post Graduate (PG)": [
    "Technology / M.Tech",
    "Management / MBA",
    "Science / M.Sc",
    "Health / M.Pharm / MD",
    "Law / LLM",
    "Education / M.Ed",
    "Arts / MA",
    "Other",
  ],
};

export const DISTRICTS = [
  "Hyderabad", "Rangareddy", "Medchal", "Sangareddy",
  "Warangal", "Karimnagar", "Nizamabad", "Khammam",
  "Nalgonda", "Mahbubnagar", "Adilabad", "Siddipet",
  "Suryapet", "Jagtial", "Peddapalli", "Outside Telangana",
];

export function streamToApiFilter(stream: string): string | undefined {
  if (!stream || stream === "Not decided yet") return undefined;
  if (stream.includes("MPC")) return "Science-MPC";
  if (stream.includes("BiPC") || stream.includes("Medical") || stream.includes("Health") || stream.includes("Agriculture") || stream.includes("Veterinary")) return "Science-BiPC";
  if (stream.includes("Commerce") || stream.includes("Management") || stream.includes("BBA") || stream.includes("BCA")) return "Commerce";
  if (stream.includes("Arts") || stream.includes("Humanities") || stream.includes("Law") || stream.includes("LLB") || stream.includes("LLM") || stream.includes("Design") || stream.includes("Media") || stream.includes("Education")) return "Arts";
  if (stream.includes("Engineering") || stream.includes("Technology") || stream.includes("Technical") || stream.includes("Science")) return "Science-MPC";
  return undefined;
}

export function timeAgo(iso: string): string {
  const ms = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(ms / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return `${days}d ago`;
  return new Date(iso).toLocaleDateString("en-IN", { day: "numeric", month: "short" });
}
