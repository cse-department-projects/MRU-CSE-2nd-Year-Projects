import { useState } from "react";
import { useStartAssessment, useSubmitAssessment } from "@workspace/api-client-react";
import type { Assessment, AssessmentResult } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useProfile } from "@/context/ProfileContext";

type Phase = "intro" | "quiz" | "result";

export default function AssessmentPage() {
  const { profile, saveQuizResult } = useProfile();

  const [phase, setPhase] = useState<Phase>("intro");
  const [userName, setUserName] = useState(profile.name || "");
  const [assessment, setAssessment] = useState<Assessment | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<{ questionId: number; optionId: string }[]>([]);
  const [result, setResult] = useState<AssessmentResult | null>(null);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);

  const startMutation = useStartAssessment();
  const submitMutation = useSubmitAssessment();

  const handleStart = () => {
    if (!userName.trim()) return;
    const hasProfileStream = profile.completed
      && !!profile.stream
      && profile.stream !== "Not decided yet";
    startMutation.mutate(
      {
        data: {
          userName,
          currentClass: profile.currentClass || undefined,
          studentStream: hasProfileStream ? profile.stream : undefined,
          preferredLanguage: "english",
        },
      },
      {
        onSuccess: (data) => {
          setAssessment(data);
          setPhase("quiz");
        },
      }
    );
  };

  const handleAnswer = (optionId: string) => {
    setSelectedOption(optionId);
  };

  const handleNext = () => {
    if (!selectedOption || !assessment) return;
    const q = assessment.questions[currentQuestion];
    const newAnswers = [...answers, { questionId: q.id, optionId: selectedOption }];
    setAnswers(newAnswers);
    setSelectedOption(null);

    if (currentQuestion + 1 >= assessment.questions.length) {
      submitMutation.mutate(
        { id: assessment.id, data: { answers: newAnswers } },
        {
          onSuccess: (res) => {
            setResult(res);
            setPhase("result");
            // Save quiz result to profile
            saveQuizResult({
              personalityLabel: res.personalityLabel ?? "",
              description: res.description ?? "",
              careerClusters: res.careerClusters ?? [],
              strengths: res.strengths ?? [],
                topCareers: (res.topCareers ?? []).map((career) => ({
                  id: career.id,
                  title: career.title,
                  cluster: career.cluster,
                  salaryRange: career.salaryRange,
                })),
            });
          },
        }
      );
    } else {
      setCurrentQuestion((p) => p + 1);
    }
  };

  const questions = assessment?.questions ?? [];
  const question = questions[currentQuestion];
  const progress = questions.length > 0 ? ((currentQuestion) / questions.length) * 100 : 0;

  if (phase === "intro") {
    const lastQuiz = profile.quizResults[0];
    return (
      <div className="p-6 lg:p-12 max-w-xl mx-auto">
        <div className="mb-8">
          <Badge variant="secondary" className="mb-4">5 Questions · ~3 minutes</Badge>
          <h1 className="text-3xl font-bold text-foreground">Career Personality Quiz</h1>
          <p className="text-muted-foreground mt-3 leading-relaxed">
            Answer 5 quick questions and discover your Career Personality — plus 3–5 career paths that match your strengths and interests.
          </p>
          {profile.completed && profile.stream && profile.stream !== "Not decided yet" ? (
            <div data-testid="text-quiz-profile-stream" className="mt-4 rounded-xl border border-primary/20 bg-primary/5 px-4 py-3 text-sm text-foreground">
              This quiz will use questions tailored to <strong>{profile.currentClass} · {profile.stream}</strong>.
            </div>
          ) : (
            <div data-testid="text-quiz-general" className="mt-4 rounded-xl border border-border bg-muted/40 px-4 py-3 text-sm text-muted-foreground">
              Set your class and stream in your profile to get questions tailored to your studies. You can take the general quiz now.
            </div>
          )}
        </div>

        {/* Show last result if exists */}
        {lastQuiz && (
          <div className="mb-5 bg-primary/5 border border-primary/20 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs text-muted-foreground mb-0.5">Your last result</div>
                <div className="font-semibold text-foreground">{lastQuiz.personalityLabel}</div>
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {lastQuiz.careerClusters.slice(0, 3).map((c) => (
                    <span key={c} className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">{c}</span>
                  ))}
                </div>
              </div>
              <Link href="/dashboard">
                <span className="text-xs text-primary hover:underline cursor-pointer ml-3">View →</span>
              </Link>
            </div>
          </div>
        )}

        <Card className="border-card-border">
          <CardContent className="pt-6">
            <label className="block text-sm font-medium text-foreground mb-2">
              What should we call you?
            </label>
            <input
              data-testid="input-username"
              type="text"
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              placeholder="Enter your name"
              className="w-full border border-input rounded-lg px-4 py-2.5 text-sm bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
              onKeyDown={(e) => e.key === "Enter" && handleStart()}
            />
            <button
              data-testid="button-start-quiz"
              onClick={handleStart}
              disabled={!userName.trim() || startMutation.isPending}
              className="w-full mt-4 bg-primary text-primary-foreground py-3 rounded-lg font-semibold hover:bg-primary/90 transition-colors disabled:opacity-50"
            >
              {startMutation.isPending ? "Starting..." : lastQuiz ? "Retake Quiz" : "Begin Quiz"}
            </button>
          </CardContent>
        </Card>

        <div className="mt-6 grid grid-cols-3 gap-3 text-center">
          {["5 minutes", "No signup needed", "Free forever"].map((t) => (
            <div key={t} className="bg-muted/50 rounded-lg px-3 py-2 text-xs text-muted-foreground">{t}</div>
          ))}
        </div>
      </div>
    );
  }

  if (phase === "quiz" && question) {
    return (
      <div className="p-6 lg:p-12 max-w-2xl mx-auto">
        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between text-sm text-muted-foreground mb-2">
            <span>Question {currentQuestion + 1} of {questions.length}</span>
            <span>{Math.round(progress)}% complete</span>
          </div>
          <div className="h-2 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-primary rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        <h2 className="text-xl lg:text-2xl font-bold text-foreground mb-6 leading-snug">
          {question.text}
        </h2>

        <div className="space-y-3">
          {question.options.map((opt) => (
            <button
              key={opt.id}
              data-testid={`option-${opt.id}`}
              onClick={() => handleAnswer(opt.id)}
              className={`w-full text-left px-5 py-4 rounded-xl border transition-all text-sm font-medium
                ${selectedOption === opt.id
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border bg-card text-foreground hover:border-primary/40 hover:bg-muted/50"
                }`}
            >
              <span className="font-bold mr-3 text-muted-foreground">{opt.id.toUpperCase()}.</span>
              {opt.text}
            </button>
          ))}
        </div>

        <button
          data-testid="button-next"
          onClick={handleNext}
          disabled={!selectedOption || submitMutation.isPending}
          className="w-full mt-6 bg-primary text-primary-foreground py-3 rounded-xl font-semibold hover:bg-primary/90 transition-colors disabled:opacity-50"
        >
          {submitMutation.isPending
            ? "Analyzing your answers..."
            : currentQuestion + 1 === questions.length
            ? "See My Results"
            : "Next Question →"}
        </button>
      </div>
    );
  }

  if (phase === "result" && result) {
    return (
      <div className="p-6 lg:p-12 max-w-3xl mx-auto">
        <div className="mb-8 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 text-primary text-2xl mb-4">
            ✦
          </div>
          <div className="inline-flex items-center gap-2 bg-green-100 text-green-700 border border-green-200 rounded-full px-3 py-1 text-xs font-medium mb-3">
            ✓ Result saved to your dashboard
          </div>
          <h1 className="text-3xl font-bold text-foreground">{result.personalityLabel}</h1>
          <p className="text-muted-foreground mt-3 max-w-lg mx-auto leading-relaxed">{result.description}</p>
        </div>

        {/* Strengths */}
        {result.strengths && result.strengths.length > 0 && (
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Your Strengths</h3>
            <div className="flex flex-wrap gap-2">
              {result.strengths.map((s) => (
                <span key={s} className="bg-primary/10 text-primary border border-primary/20 px-3 py-1 rounded-full text-sm font-medium">{s}</span>
              ))}
            </div>
          </div>
        )}

        {/* Career Clusters */}
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Best Career Clusters</h3>
          <div className="flex flex-wrap gap-2">
            {result.careerClusters?.map((c) => (
              <Badge key={c} variant="secondary" className="text-sm px-3 py-1">{c}</Badge>
            ))}
          </div>
        </div>

        {/* Top Careers */}
        {result.topCareers && result.topCareers.length > 0 && (
          <div>
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Recommended Careers For You</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {result.topCareers.map((career) => (
                <Link key={career.id} href={`/careers/${career.id}`}>
                  <div data-testid={`result-career-${career.id}`} className="bg-card border border-card-border rounded-xl p-4 cursor-pointer hover:border-primary/40 hover:shadow-sm transition-all">
                    <div className="font-semibold text-foreground">{career.title}</div>
                    <div className="text-sm text-muted-foreground mt-0.5">{career.cluster}</div>
                    <div className="text-sm font-medium text-primary mt-2">{career.salaryRange}</div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        <div className="mt-8 flex gap-3 flex-wrap">
          <button
            data-testid="button-retake"
            onClick={() => { setPhase("intro"); setAnswers([]); setCurrentQuestion(0); setResult(null); setAssessment(null); }}
            className="bg-muted text-foreground px-5 py-2.5 rounded-lg font-medium hover:bg-muted/80 transition-colors"
          >
            Retake Quiz
          </button>
          <Link href="/dashboard">
            <button className="bg-card border border-border text-foreground px-5 py-2.5 rounded-lg font-medium hover:bg-muted transition-colors">
              View Dashboard
            </button>
          </Link>
          <Link href="/careers">
            <button className="bg-primary text-primary-foreground px-5 py-2.5 rounded-lg font-medium hover:bg-primary/90 transition-colors">
              Explore All Careers →
            </button>
          </Link>
        </div>
      </div>
    );
  }

  return null;
}
