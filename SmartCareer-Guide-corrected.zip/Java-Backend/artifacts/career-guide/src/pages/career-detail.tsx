import { useRoute, Link } from "wouter";
import { useGetCareer, getGetCareerQueryKey } from "@workspace/api-client-react";
import { Badge } from "@/components/ui/badge";
import { CareerDemandBadge } from "@/components/CareerDemandBadge";
import { Skeleton } from "@/components/ui/skeleton";
import { useEffect } from "react";
import { useProfile } from "@/context/ProfileContext";

export default function CareerDetailPage() {
  const [, params] = useRoute("/careers/:id");
  const id = parseInt(params?.id ?? "0", 10);
  const { trackViewedCareer, toggleBookmark, isBookmarked } = useProfile();

  const { data: career, isLoading } = useGetCareer(id, {
    query: { enabled: !!id, queryKey: getGetCareerQueryKey(id) },
  });

  // Track this career as viewed once data loads
  useEffect(() => {
    if (career) {
      trackViewedCareer({
        id: career.id,
        title: career.title,
        cluster: career.cluster ?? "",
        salaryRange: career.salaryRange ?? "",
      });
    }
  }, [career?.id]);

  if (isLoading) {
    return (
      <div className="p-6 lg:p-12 max-w-4xl">
        <Skeleton className="h-8 w-64 mb-4" />
        <Skeleton className="h-4 w-48 mb-8" />
        <Skeleton className="h-32 mb-6" />
        <Skeleton className="h-32" />
      </div>
    );
  }

  if (!career) {
    return (
      <div className="p-6 text-center py-20">
        <p className="text-muted-foreground">Career not found.</p>
        <Link href="/careers"><button className="mt-4 text-primary hover:underline">Back to Careers</button></Link>
      </div>
    );
  }

  const bookmarked = isBookmarked(career.id);

  const handleBookmark = () => {
    toggleBookmark({
      id: career.id,
      title: career.title,
      cluster: career.cluster ?? "",
      salaryRange: career.salaryRange ?? "",
    });
  };

  return (
    <div className="p-6 lg:p-12 max-w-4xl">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
        <Link href="/careers"><span className="hover:text-foreground cursor-pointer">Careers</span></Link>
        <span>/</span>
        <span className="text-foreground font-medium">{career.title}</span>
      </div>

      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-wrap items-start gap-3 mb-3">
          <h1 className="text-3xl font-bold text-foreground flex-1">{career.title}</h1>
          <div className="flex items-center gap-2 shrink-0">
            <CareerDemandBadge level={career.demandLevel} className="text-sm px-3 py-1" />
            {/* Bookmark button */}
            <button
              data-testid="button-bookmark"
              onClick={handleBookmark}
              title={bookmarked ? "Remove bookmark" : "Save this career"}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-sm font-medium transition-all
                ${bookmarked
                  ? "bg-primary/10 border-primary/30 text-primary"
                  : "bg-card border-border text-muted-foreground hover:border-primary/30 hover:text-primary hover:bg-primary/5"
                }`}
            >
              <span className="text-base leading-none">{bookmarked ? "⊛" : "⊙"}</span>
              <span className="hidden sm:inline">{bookmarked ? "Saved" : "Save"}</span>
            </button>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
          <span className="font-medium">{career.cluster}</span>
          <span className="text-primary font-semibold text-base">{career.salaryRange}</span>
          {career.growthRate && <span className="text-green-600 font-medium">Growth: {career.growthRate}</span>}
        </div>
        {career.averageSalaryLPA && (
          <div className="mt-2 text-sm text-muted-foreground">
            Average package: <span className="text-foreground font-semibold">{career.averageSalaryLPA} LPA</span>
          </div>
        )}
        {bookmarked && (
          <div className="mt-3 inline-flex items-center gap-1.5 bg-primary/10 border border-primary/20 rounded-lg px-3 py-1.5 text-xs text-primary font-medium">
            ✓ Saved to your dashboard
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Description */}
          <div className="bg-card border border-card-border rounded-xl p-5">
            <h2 className="font-semibold text-foreground mb-3">About This Career</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">{career.description}</p>
          </div>

          {/* Skills */}
          {career.skills && career.skills.length > 0 && (
            <div className="bg-card border border-card-border rounded-xl p-5">
              <h2 className="font-semibold text-foreground mb-3">Skills Required</h2>
              <div className="flex flex-wrap gap-2">
                {career.skills.map((skill) => (
                  <span key={skill} className="bg-primary/10 text-primary border border-primary/20 px-3 py-1 rounded-full text-sm">{skill}</span>
                ))}
              </div>
            </div>
          )}

          {/* Entry Paths */}
          {career.entryPaths && career.entryPaths.length > 0 && (
            <div className="bg-card border border-card-border rounded-xl p-5">
              <h2 className="font-semibold text-foreground mb-3">How to Enter This Career</h2>
              <ul className="space-y-2">
                {career.entryPaths.map((path, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <span className="text-primary mt-0.5 shrink-0">→</span>
                    <span>{path}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        <div className="space-y-5">
          {/* Local Opportunities */}
          {career.localOpportunities && career.localOpportunities.length > 0 && (
            <div className="bg-card border border-card-border rounded-xl p-5">
              <h2 className="font-semibold text-foreground mb-3">Opportunities in Telangana</h2>
              <ul className="space-y-2">
                {career.localOpportunities.map((opp, i) => (
                  <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                    <span className="text-green-500 shrink-0">◉</span>
                    <span>{opp}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Streams */}
          {career.streams && career.streams.length > 0 && (
            <div className="bg-card border border-card-border rounded-xl p-5">
              <h2 className="font-semibold text-foreground mb-3">Recommended Streams</h2>
              <div className="space-y-1.5">
                {career.streams.map((s) => (
                  <div key={s} className="text-sm text-muted-foreground flex items-center gap-2">
                    <span className="text-primary">✓</span> {s}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="space-y-2">
            <Link href={`/roadmap/${career.id}`}>
              <button data-testid="button-view-roadmap" className="w-full bg-primary text-primary-foreground py-3 rounded-xl font-semibold hover:bg-primary/90 transition-colors">
                View Career Roadmap
              </button>
            </Link>
            <button
              onClick={handleBookmark}
              className={`w-full border py-3 rounded-xl font-medium transition-colors
                ${bookmarked
                  ? "bg-primary/10 border-primary/30 text-primary"
                  : "bg-card border-border text-foreground hover:bg-muted"
                }`}
            >
              {bookmarked ? "⊛ Saved to Dashboard" : "⊙ Save This Career"}
            </button>
            <Link href="/jobs">
              <button className="w-full bg-card border border-border text-foreground py-3 rounded-xl font-medium hover:bg-muted transition-colors">
                Find Related Jobs
              </button>
            </Link>
            <Link href="/chat">
              <button className="w-full bg-card border border-border text-foreground py-3 rounded-xl font-medium hover:bg-muted transition-colors">
                Ask AI Counselor
              </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
