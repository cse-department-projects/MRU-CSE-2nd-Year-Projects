import { useState } from "react";
import { useListCareers, getListCareersQueryKey } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { CareerDemandBadge } from "@/components/CareerDemandBadge";
import { useProfile, streamToApiFilter } from "@/context/ProfileContext";

const STREAMS = ["All", "Science-MPC", "Science-BiPC", "Commerce", "Arts"];
const CLUSTERS = [
  "All",
  "Technology",
  "Healthcare",
  "Engineering",
  "Finance",
  "Education",
  "Business",
  "Agriculture & Veterinary",
  "Law & Public Service",
  "Design & Media",
  "Science & Research",
];

export default function CareersPage() {
  const { profile } = useProfile();
  const profileStream = streamToApiFilter(profile.stream);

  const [search, setSearch] = useState("");
  const [stream, setStream] = useState(profileStream ?? "All");
  const [cluster, setCluster] = useState("All");
  const [demandFilter, setDemandFilter] = useState("All");

  const { data: careers, isLoading } = useListCareers(
    {
      search: search || undefined,
      stream: stream !== "All" ? stream : undefined,
      cluster: cluster !== "All" ? cluster : undefined,
    },
    {
      query: {
        queryKey: getListCareersQueryKey({
          search: search || undefined,
          stream: stream !== "All" ? stream : undefined,
          cluster: cluster !== "All" ? cluster : undefined,
        }),
      },
    }
  );

  const careerRecords: any[] = Array.isArray(careers)
    ? careers
    : Array.isArray((careers as any)?.data)
      ? (careers as any).data
      : [];

  const filtered = careerRecords.filter((c) =>
    demandFilter === "All" ? true : c.demandLevel === demandFilter.toLowerCase()
  );

  return (
    <div className="p-6 lg:p-12">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground">Explore Career Paths</h1>
        <p className="text-muted-foreground mt-1">Browse {careerRecords.length} careers with salaries, demand levels, and local opportunities</p>
      </div>

      {/* Search */}
      <div className="mb-5">
        <input
          data-testid="input-search"
          type="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search careers (e.g. Software Engineer, Doctor...)"
          className="w-full max-w-lg border border-input rounded-lg px-4 py-2.5 text-sm bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        />
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4 mb-8">
        <div>
          <div className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wide">Stream</div>
          <div className="flex flex-wrap gap-1.5">
            {STREAMS.map((s) => (
              <button
                key={s}
                data-testid={`filter-stream-${s}`}
                onClick={() => setStream(s)}
                className={`px-3 py-1 rounded-full text-xs font-medium transition-colors
                  ${stream === s ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"}`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
        <div>
          <div className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wide">Cluster</div>
          <div className="flex flex-wrap gap-1.5">
            {CLUSTERS.map((c) => (
              <button
                key={c}
                data-testid={`filter-cluster-${c}`}
                onClick={() => setCluster(c)}
                className={`px-3 py-1 rounded-full text-xs font-medium transition-colors
                  ${cluster === c ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"}`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
        <div>
          <div className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wide">Demand</div>
          <div className="flex gap-1.5">
            {["All", "High", "Medium", "Low", "Varies"].map((d) => (
              <button
                key={d}
                onClick={() => setDemandFilter(d)}
                className={`px-3 py-1 rounded-full text-xs font-medium transition-colors
                  ${demandFilter === d ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"}`}
              >
                {d}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Results */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => <Skeleton key={i} className="h-44 rounded-xl" />)}
        </div>
      ) : filtered && filtered.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((career) => (
            <Link key={career.id} href={`/careers/${career.id}`}>
              <Card data-testid={`card-career-${career.id}`} className="cursor-pointer hover:shadow-md transition-all border-card-border hover:border-primary/30 h-full">
                <CardContent className="p-5 flex flex-col h-full">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h3 className="font-semibold text-foreground leading-snug">{career.title}</h3>
                    <CareerDemandBadge level={career.demandLevel} className="shrink-0 text-xs" />
                  </div>
                  <div className="text-xs text-muted-foreground mb-1">{career.cluster}</div>
                  <div className="text-sm font-semibold text-primary mb-2">{career.salaryRange}</div>
                  <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2 flex-1">{career.description}</p>
                  <div className="flex flex-wrap gap-1 mt-3">
                    {career.tags?.slice(0, 3).map((tag) => (
                      <span key={tag} className="text-xs bg-muted px-2 py-0.5 rounded-full text-muted-foreground">{tag}</span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      ) : (
        <div className="text-center py-16 text-muted-foreground">
          <div className="text-4xl mb-3">⊠</div>
          <p className="font-medium">No careers found</p>
          <p className="text-sm mt-1">Try adjusting your filters</p>
        </div>
      )}
    </div>
  );
}
