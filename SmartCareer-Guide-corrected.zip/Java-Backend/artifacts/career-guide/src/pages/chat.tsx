import { useState, useRef, useEffect } from "react";
import { useSendChatMessage } from "@workspace/api-client-react";
import { useProfile } from "@/context/ProfileContext";

type Lang = "english" | "telugu" | "hindi";

interface Message {
  role: "user" | "assistant";
  content: string;
}

const LANG_LABELS: Record<Lang, string> = {
  english: "English",
  telugu: "తెలుగు",
  hindi: "हिंदी",
};

function buildGreeting(name: string, cls: string, stream: string, lang: Lang): string {
  const fn = name.split(" ")[0];
  const streamLine =
    stream && stream !== "Not decided yet"
      ? lang === "telugu"
        ? `\n\nమీరు ${stream} చదువుతున్నారు కాబట్టి, నేను మీ స్ట్రీమ్‌కు సంబంధించిన కెరీర్‌లు, పరీక్షలు మరియు కళాశాలల గురించి సలహా ఇవ్వగలను.`
        : lang === "hindi"
        ? `\n\nआप ${stream} पढ़ रहे हैं, इसलिए मैं आपकी stream के अनुसार career, exams और colleges के बारे में बेहतर सलाह दे सकता हूँ।`
        : `\n\nSince you're in **${stream}**, I can give you tailored advice on careers, entrance exams, and colleges that match your stream.`
      : "";

  if (lang === "telugu") {
    return `నమస్తే${fn ? `, ${fn}` : ""}! నేను SmartCareer Guide, మీ వ్యక్తిగత కెరీర్ కౌన్సెలర్.\n\nనేను మీకు ఇవి సహాయపడగలను:\n- 10వ, 12వ తరగతి లేదా డిగ్రీ తర్వాత కెరీర్ ఆప్షన్లు\n- TS ePass, PMKVY వంటి స్కాలర్‌షిప్‌లు\n- NEET, JEE, EAMCET, TSPSC పరీక్షలు\n- జీతాలు, కళాశాలలు, రోడ్‌మ్యాప్‌లు${streamLine}\n\nఏదైనా అడగండి — తెలుగు, ఇంగ్లీష్ లేదా హిందీలో!`;
  }
  if (lang === "hindi") {
    return `नमस्ते${fn ? `, ${fn}` : ""}! मैं SmartCareer Guide हूँ, आपका personal career counselor.\n\nमैं इनमें आपकी मदद कर सकता हूँ:\n- 10वीं, 12वीं या graduation के बाद career options\n- TS ePass, PMKVY जैसी scholarships\n- NEET, JEE, EAMCET, TSPSC परीक्षाएं\n- Salaries, colleges, और roadmaps${streamLine}\n\nकुछ भी पूछें — हिंदी, English या Telugu में!`;
  }
  return `Namaste${fn ? `, ${fn}` : ""}! I am SmartCareer Guide, your personal career counselor.\n\nI can help you with:\n- Career options after 10th, 12th, or graduation\n- Scholarships like TS ePass, PMKVY, PM Yasasvi\n- Entrance exams: NEET, JEE, EAMCET, TSPSC, UPSC\n- Salaries, colleges, and roadmaps${streamLine}\n\nAsk me anything — in English, Telugu, or Hindi!`;
}

function buildSuggestions(stream: string, lang: Lang): string[] {
  if (lang === "telugu") {
    if (stream?.includes("MPC")) return ["12వ MPC తర్వాత ఏమి చేయాలి?", "EAMCET కోసం ఎలా చదవాలి?", "ఉత్తమ B.Tech కళాశాలలు ఏవి?", "MPC విద్యార్థులకు స్కాలర్‌షిప్‌లు ఏవి?"];
    if (stream?.includes("BiPC")) return ["12వ BiPC తర్వాత ఏమి చేయాలి?", "NEET 2025 కోసం ఎలా చదవాలి?", "MBBS కు ప్రత్యామ్నాయాలు ఏవి?", "వైద్య విద్యార్థులకు స్కాలర్‌షిప్‌లు ఏవి?"];
    return ["12వ తర్వాత ఏమి చేయాలి?", "సాఫ్ట్‌వేర్ ఇంజనీర్ ఎలా అవ్వాలి?", "BC విద్యార్థులకు స్కాలర్‌షిప్‌లు ఏవి?", "హైదరాబాద్‌లో డేటా అనలిస్ట్ జీతం ఎంత?"];
  }
  if (lang === "hindi") {
    if (stream?.includes("MPC")) return ["12वीं MPC के बाद क्या करें?", "EAMCET की तैयारी कैसे करें?", "तेलंगाना में बेस्ट B.Tech कॉलेज कौन से हैं?", "MPC students के लिए scholarships कौन सी हैं?"];
    if (stream?.includes("BiPC")) return ["12वीं BiPC के बाद क्या करें?", "NEET 2025 की तैयारी कैसे करें?", "MBBS के अलावा और क्या options हैं?", "Medical students के लिए scholarships कौन सी हैं?"];
    return ["12वीं के बाद क्या करें?", "Software engineer कैसे बनें?", "BC students के लिए कौन सी scholarships हैं?", "Hyderabad में data analyst की salary कितनी है?"];
  }
  if (stream?.includes("MPC")) return ["What can I do after 12th MPC?", "Which B.Tech branch has the best salary?", "How to crack EAMCET from home?", "Which scholarships for MPC students?"];
  if (stream?.includes("BiPC")) return ["What can I do after 12th BiPC?", "How to prepare for NEET 2025?", "What are alternatives to MBBS?", "Which scholarships for medical students?"];
  return ["What can I do after 12th MPC?", "How to become a software engineer?", "Which scholarships for BC students?", "What is the salary of a data analyst?"];
}

export default function ChatPage() {
  const { profile } = useProfile();
  const [lang, setLang] = useState<Lang>("english");

  const initialGreeting = buildGreeting(profile.name, profile.currentClass, profile.stream, lang);

  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: initialGreeting },
  ]);
  const [input, setInput] = useState("");
  const [sessionId, setSessionId] = useState<string | undefined>(undefined);
  const [suggestions, setSuggestions] = useState<string[]>(buildSuggestions(profile.stream, lang));
  const bottomRef = useRef<HTMLDivElement>(null);
  const chatMutation = useSendChatMessage();

  // When language changes, reset the conversation with a new greeting
  const handleLangChange = (newLang: Lang) => {
    if (newLang === lang) return;
    setLang(newLang);
    setMessages([{ role: "assistant", content: buildGreeting(profile.name, profile.currentClass, profile.stream, newLang) }]);
    setSuggestions(buildSuggestions(profile.stream, newLang));
    setSessionId(undefined);
  };

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = (text: string) => {
    if (!text.trim() || chatMutation.isPending) return;
    setMessages((prev) => [...prev, { role: "user", content: text }]);
    setInput("");
    setSuggestions([]);

    chatMutation.mutate(
      {
        data: {
          message: text,
          sessionId,
          language: lang,
          studentName: profile.name || undefined,
          studentClass: profile.currentClass || undefined,
          studentStream: profile.stream || undefined,
          studentDistrict: profile.district || undefined,
        },
      },
      {
        onSuccess: (res) => {
          setSessionId(res.sessionId);
          setMessages((prev) => [...prev, { role: "assistant", content: res.message }]);
          if (res.suggestedQuestions && res.suggestedQuestions.length > 0) {
            setSuggestions(res.suggestedQuestions);
          }
        },
        onError: () => {
          setMessages((prev) => [...prev, { role: "assistant", content: lang === "telugu" ? "క్షమించండి, ఒక లోపం జరిగింది. మళ్ళీ ప్రయత్నించండి." : lang === "hindi" ? "माफ़ करें, एक error हुई। कृपया फिर से try करें।" : "Sorry, I encountered an error. Please try again." }]);
        },
      }
    );
  };

  const placeholder =
    lang === "telugu" ? "కెరీర్‌లు, పరీక్షలు, స్కాలర్‌షిప్‌ల గురించి అడగండి..."
    : lang === "hindi" ? "careers, exams, scholarships के बारे में पूछें..."
    : "Ask anything about careers, exams, scholarships...";

  const sendLabel = lang === "telugu" ? "పంపు" : lang === "hindi" ? "भेजें" : "Send";

  return (
    <div className="flex flex-col h-full max-h-[calc(100vh-56px)] lg:max-h-screen">
      {/* Header */}
      <div className="px-5 py-3.5 border-b border-border bg-card shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-primary text-lg shrink-0">
            ◈
          </div>
          <div className="flex-1 min-w-0">
            <div className="font-semibold text-foreground text-sm">AI Career Counselor</div>
            <div className="text-xs text-muted-foreground">Powered by SmartCareer Guide</div>
          </div>

          {/* Language toggle */}
          <div className="flex items-center bg-muted rounded-xl p-0.5 shrink-0">
            {(["english", "telugu", "hindi"] as Lang[]).map((l) => (
              <button
                key={l}
                data-testid={`lang-${l}`}
                onClick={() => handleLangChange(l)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all
                  ${lang === l
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                  }`}
              >
                {LANG_LABELS[l]}
              </button>
            ))}
          </div>
        </div>

        {/* Profile context strip */}
        {(profile.stream || profile.district) && profile.stream !== "Not decided yet" && (
          <div className="mt-2 flex items-center gap-1.5 flex-wrap">
            <span className="text-xs text-muted-foreground">Personalised for:</span>
            {profile.stream && <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">{profile.stream}</span>}
            {profile.currentClass && <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">{profile.currentClass}</span>}
            {profile.district && <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">{profile.district}</span>}
          </div>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-5 space-y-4">
        {messages.map((msg, i) => (
          <div key={i} data-testid={`message-${i}`} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            {msg.role === "assistant" && (
              <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center text-primary text-sm shrink-0 mr-2 mt-0.5">◈</div>
            )}
            <div className={`max-w-[80%] px-4 py-3 rounded-2xl text-sm leading-relaxed whitespace-pre-line
              ${msg.role === "user"
                ? "bg-primary text-primary-foreground rounded-br-md"
                : "bg-card border border-card-border text-foreground rounded-bl-md"
              }`}>
              {msg.content}
            </div>
          </div>
        ))}

        {chatMutation.isPending && (
          <div className="flex justify-start">
            <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center text-primary text-sm shrink-0 mr-2">◈</div>
            <div className="bg-card border border-card-border px-4 py-3 rounded-2xl rounded-bl-md">
              <div className="flex gap-1.5 items-center">
                {[0, 1, 2].map((i) => (
                  <div key={i} className="w-2 h-2 rounded-full bg-muted-foreground/40 animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                ))}
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Suggestions */}
      {suggestions.length > 0 && !chatMutation.isPending && (
        <div className="px-4 py-2 flex flex-wrap gap-2 shrink-0">
          {suggestions.map((s, i) => (
            <button key={i} data-testid={`suggestion-${i}`} onClick={() => sendMessage(s)}
              className="text-xs bg-muted text-muted-foreground border border-border px-3 py-1.5 rounded-full hover:bg-primary/10 hover:text-primary hover:border-primary/30 transition-colors text-left">
              {s}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <div className="px-4 py-4 border-t border-border bg-card shrink-0">
        <div className="flex gap-2">
          <input
            data-testid="input-chat"
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && sendMessage(input)}
            placeholder={placeholder}
            disabled={chatMutation.isPending}
            className="flex-1 border border-input rounded-xl px-4 py-2.5 text-sm bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-50"
          />
          <button
            data-testid="button-send"
            onClick={() => sendMessage(input)}
            disabled={!input.trim() || chatMutation.isPending}
            className="bg-primary text-primary-foreground px-4 py-2.5 rounded-xl font-medium hover:bg-primary/90 transition-colors disabled:opacity-50 whitespace-nowrap"
          >
            {sendLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
