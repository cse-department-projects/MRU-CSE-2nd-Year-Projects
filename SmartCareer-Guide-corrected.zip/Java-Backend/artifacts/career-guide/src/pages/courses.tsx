import { useMemo, useState } from "react";
import {
  ArrowUpRight,
  BookOpen,
  CheckCircle2,
  Clock3,
  ExternalLink,
  Filter,
  Layers3,
  RefreshCw,
  Search,
  Sparkles,
  Target,
  Wrench,
} from "lucide-react";
import type { Course } from "@workspace/api-client-react";
import {
  getListCoursesQueryKey,
  useListCourses,
} from "@workspace/api-client-react";
import { useProfile, streamToApiFilter } from "@/context/ProfileContext";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";

const LEVELS = [
  { value: "all", label: "All levels" },
  { value: "beginner", label: "Beginner" },
  { value: "intermediate", label: "Intermediate" },
  { value: "advanced", label: "Advanced" },
] as const;

function levelLabel(level: Course["level"]) {
  return level.charAt(0).toUpperCase() + level.slice(1);
}

function levelTone(level: Course["level"]) {
  if (level === "beginner") return "border-[#b8ddd6] bg-[#e9f7f3] text-[#176c63]";
  if (level === "intermediate") return "border-[#e7d7a9] bg-[#fff9e8] text-[#8a6b18]";
  return "border-[#c6d3dc] bg-[#edf4f7] text-[#284b63]";
}

function CourseMeta({
  course,
  compact = false,
}: {
  course: Course;
  compact?: boolean;
}) {
  return (
    <div className={`grid gap-3 ${compact ? "grid-cols-2" : "grid-cols-2 sm:grid-cols-4"}`}>
      <div className="min-w-0" data-testid={`meta-duration-${course.id}`}>
        <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.1em] text-[#7b8788]">
          <Clock3 className="h-3.5 w-3.5 text-[#0f766e]" />
          Duration
        </div>
        <div className="mt-1 truncate text-xs font-semibold text-[#274756]" data-testid={`text-duration-${course.id}`}>
          {course.duration}
        </div>
      </div>
      <div className="min-w-0" data-testid={`meta-cost-${course.id}`}>
        <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.1em] text-[#7b8788]">
          <Target className="h-3.5 w-3.5 text-[#dc6d39]" />
          Cost
        </div>
        <div className="mt-1 truncate text-xs font-semibold text-[#274756]" data-testid={`text-cost-${course.id}`}>
          {course.cost}
        </div>
      </div>
      {!compact && (
        <>
          <div className="min-w-0" data-testid={`meta-format-${course.id}`}>
            <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.1em] text-[#7b8788]">
              <Layers3 className="h-3.5 w-3.5 text-[#284b63]" />
              Format
            </div>
            <div className="mt-1 truncate text-xs font-semibold text-[#274756]" data-testid={`text-format-${course.id}`}>
              {course.format}
            </div>
          </div>
          <div className="min-w-0" data-testid={`meta-provider-${course.id}`}>
            <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.1em] text-[#7b8788]">
              <BookOpen className="h-3.5 w-3.5 text-[#a57a16]" />
              Provider
            </div>
            <div className="mt-1 truncate text-xs font-semibold text-[#274756]" data-testid={`text-provider-${course.id}`}>
              {course.provider}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function CourseCard({ course, featured = false }: { course: Course; featured?: boolean }) {
  return (
    <Card
      data-testid={`card-course-${course.id}`}
      className={`group h-full overflow-hidden border-[#dedbd3] bg-[#fbfaf7] shadow-none transition-transform duration-300 hover:-translate-y-1 hover:border-[#bdd0ca] ${
        featured ? "border-[#9ccbc0] bg-[#f4fbf8]" : ""
      }`}
    >
      <CardContent className={featured ? "p-5 sm:p-6" : "p-5"}>
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0">
            <Badge
              data-testid={`badge-category-${course.id}`}
              variant="outline"
              className="border-[#cfe3dc] bg-[#edf8f3] text-[10px] font-semibold uppercase tracking-[0.12em] text-[#176c63]"
            >
              {course.category}
            </Badge>
            <h3
              data-testid={`text-course-title-${course.id}`}
              className={`mt-3 font-semibold leading-tight tracking-[-0.025em] text-[#173047] ${
                featured ? "text-xl sm:text-2xl" : "text-lg"
              }`}
            >
              {course.title}
            </h3>
          </div>
          <span
            data-testid={`badge-level-${course.id}`}
            className={`shrink-0 rounded-full border px-2.5 py-1 text-[11px] font-semibold ${levelTone(course.level)}`}
          >
            {levelLabel(course.level)}
          </span>
        </div>

        <p
          data-testid={`text-course-description-${course.id}`}
          className={`mt-3 text-sm leading-6 text-[#687879] ${featured ? "line-clamp-3" : "line-clamp-3"}`}
        >
          {course.description}
        </p>

        <div className="mt-4 flex flex-wrap gap-1.5" data-testid={`list-course-skills-${course.id}`}>
          {course.skills.slice(0, featured ? 5 : 4).map((skill) => (
            <span
              key={skill}
              data-testid={`skill-${course.id}-${skill.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`}
              className="rounded-full bg-[#f1eee7] px-2.5 py-1 text-[11px] font-medium text-[#49646a]"
            >
              {skill}
            </span>
          ))}
        </div>

        <div className="my-5 border-t border-[#e8e4dc]" />
        <CourseMeta course={course} compact={false} />

        <div className="mt-5 flex items-center justify-between gap-3 border-t border-[#e8e4dc] pt-4">
          <div className="min-w-0 text-xs text-[#7b8788]">
            <span className="mr-1">For</span>
            <span className="font-semibold text-[#49646a]" data-testid={`text-course-streams-${course.id}`}>
              {course.streams.length ? course.streams.join(", ") : "multiple streams"}
            </span>
          </div>
          {course.url ? (
            <a
              data-testid={`link-course-external-${course.id}`}
              href={course.url}
              target="_blank"
              rel="noreferrer"
              className="inline-flex shrink-0 items-center gap-1.5 rounded-lg bg-[#173047] px-3 py-2 text-xs font-semibold text-[#fffaf0] transition-colors hover:bg-[#28536b]"
            >
              View pathway
              <ExternalLink className="h-3.5 w-3.5" />
            </a>
          ) : (
            <span data-testid={`text-course-link-unavailable-${course.id}`} className="text-right text-[11px] font-medium text-[#9aaba8]">
              SmartCareer pathway
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

function CourseSkeleton({ index }: { index: number }) {
  return (
    <Card data-testid={`skeleton-course-${index}`} className="border-[#e2ded5] bg-[#fbfaf7] shadow-none">
      <CardContent className="space-y-4 p-5">
        <div className="flex items-start justify-between gap-3">
          <Skeleton className="h-5 w-28 bg-[#e9e5dc]" />
          <Skeleton className="h-6 w-20 rounded-full bg-[#e9e5dc]" />
        </div>
        <Skeleton className="h-7 w-4/5 bg-[#e9e5dc]" />
        <Skeleton className="h-12 w-full bg-[#e9e5dc]" />
        <div className="flex gap-2">
          <Skeleton className="h-6 w-20 rounded-full bg-[#e9e5dc]" />
          <Skeleton className="h-6 w-24 rounded-full bg-[#e9e5dc]" />
        </div>
        <Skeleton className="h-px w-full bg-[#e9e5dc]" />
        <div className="grid grid-cols-2 gap-3">
          <Skeleton className="h-8 w-full bg-[#e9e5dc]" />
          <Skeleton className="h-8 w-full bg-[#e9e5dc]" />
        </div>
      </CardContent>
    </Card>
  );
}

function EmptyState({
  filtered,
  onReset,
}: {
  filtered: boolean;
  onReset: () => void;
}) {
  return (
    <Card data-testid="state-empty-courses" className="border-dashed border-[#cfd8d2] bg-[#fbfaf7] shadow-none">
      <CardContent className="flex flex-col items-center px-6 py-14 text-center">
        <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#e9f7f3] text-[#0f766e]">
          <Wrench className="h-6 w-6" />
        </div>
        <h3 data-testid="text-empty-courses-title" className="text-lg font-semibold text-[#173047]">
          {filtered ? "No pathways match this combination" : "The learning shelf is still growing"}
        </h3>
        <p data-testid="text-empty-courses-description" className="mt-2 max-w-md text-sm leading-6 text-[#718084]">
          {filtered
            ? "Try a wider search or another level. A useful next step is usually closer than the perfect course."
            : "There are no curated pathways available right now. Check back soon for new ways to build visible skills."}
        </p>
        {filtered && (
          <Button
            data-testid="button-reset-course-filters-empty"
            type="button"
            variant="outline"
            onClick={onReset}
            className="mt-5 border-[#c9d4d1] bg-[#fffdfa] text-[#285c5a] shadow-none hover:bg-[#e9f7f3]"
          >
            Reset filters
          </Button>
        )}
      </CardContent>
    </Card>
  );
}

export default function CoursesPage() {
  const { profile } = useProfile();
  const profileStream = streamToApiFilter(profile.stream);
  const [search, setSearch] = useState("");
  const [level, setLevel] = useState<(typeof LEVELS)[number]["value"]>("all");
  const [streamMode, setStreamMode] = useState<"all" | "profile">(profileStream ? "profile" : "all");
  const [recommendationFocus, setRecommendationFocus] = useState("all");

  const params = useMemo(
    () => ({
      search: search.trim() || undefined,
      level: level === "all" ? undefined : level,
      stream: streamMode === "profile" ? profileStream : undefined,
    }),
    [level, profileStream, search, streamMode],
  );
  const recommendationParams = useMemo(
    () => (profileStream ? { stream: profileStream } : undefined),
    [profileStream],
  );

  const coursesQuery = useListCourses(params, {
    query: {
      queryKey: getListCoursesQueryKey(params),
    },
  });
  const recommendationsQuery = useListCourses(recommendationParams, {
    query: {
      queryKey: getListCoursesQueryKey(recommendationParams),
      enabled: Boolean(profileStream),
      staleTime: 120000,
    },
  });

  const courses = coursesQuery.data ?? [];
  const recommendations = useMemo(() => {
    const source = recommendationsQuery.data ?? [];
    if (recommendationFocus === "all") return source.slice(0, 3);
    return source.filter((course) => course.category === recommendationFocus).slice(0, 3);
  }, [recommendationFocus, recommendationsQuery.data]);
  const focusAreas = useMemo(() => {
    const values = new Set((recommendationsQuery.data ?? []).map((course) => course.category));
    return [...values].slice(0, 4);
  }, [recommendationsQuery.data]);
  const isFiltered = Boolean(search.trim() || level !== "all" || streamMode === "profile");
  const resetFilters = () => {
    setSearch("");
    setLevel("all");
    setStreamMode("all");
  };

  return (
    <div className="min-h-[100dvh] bg-[#f7f6f2] text-[#173047]">
      <div className="mx-auto max-w-[1500px] px-4 py-6 sm:px-6 lg:px-10 lg:py-9">
        <header className="mb-8 border-b border-[#ddd9d0] pb-8">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
            <div className="max-w-3xl">
              <div className="mb-4 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-[#0f766e]">
                <span className="h-2 w-2 rounded-full bg-[#e77845]" />
                SmartCareer Guide <span className="text-[#abb2af]">/</span> Learning studio
              </div>
              <h1 data-testid="text-courses-heading" className="max-w-2xl text-4xl font-semibold leading-[1.04] tracking-[-0.045em] text-[#173047] sm:text-5xl">
                Turn curiosity into something you can show.
              </h1>
              <p data-testid="text-courses-intro" className="mt-4 max-w-2xl text-sm leading-6 text-[#65737b] sm:text-base">
                Find practical learning pathways that help you build a skill, make a project, and take a clearer next step toward work you care about.
              </p>
            </div>
            <div className="flex items-center gap-3 rounded-2xl border border-[#dedbd3] bg-[#fbfaf7] px-4 py-3 lg:max-w-xs">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#fff0e6] text-[#dc6d39]">
                <Sparkles className="h-5 w-5" />
              </div>
              <p data-testid="text-course-count" className="text-xs leading-5 text-[#65737b]">
                <span className="block text-sm font-semibold text-[#274756]">{coursesQuery.isLoading ? "Loading pathways" : `${courses.length} pathways in view`}</span>
                Curated for student-sized next steps
              </p>
            </div>
          </div>
        </header>

        <section className="mb-8 grid gap-6 xl:grid-cols-[0.78fr_1.22fr]">
          <Card className="overflow-hidden border-[#234b61] bg-[#173047] text-[#f6f4ed] shadow-none">
            <CardHeader className="border-b border-[#385668] px-6 pb-5 pt-6">
              <div className="mb-3 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.15em] text-[#f4b183]">
                <Sparkles className="h-4 w-4" />
                Your starting point
              </div>
              <CardTitle data-testid="text-recommendation-heading" className="text-2xl font-medium tracking-[-0.03em] text-[#fffaf0]">
                {profileStream ? `A few good moves for ${profile.stream}` : "A few good moves to begin"}
              </CardTitle>
              <p data-testid="text-recommendation-description" className="mt-2 text-sm leading-5 text-[#b9c9ca]">
                {profileStream
                  ? "These pathways are matched to your stream. Pick one that ends with a piece of proof you can keep."
                  : "Set a stream in your profile to see a more personal shortlist. For now, browse the full learning shelf."}
              </p>
            </CardHeader>
            <CardContent className="p-6">
              {recommendationsQuery.isLoading && profileStream ? (
                <div className="space-y-3" data-testid="state-loading-recommendations">
                  {[0, 1, 2].map((index) => <Skeleton key={index} className="h-16 rounded-xl bg-[#24445a]" />)}
                </div>
              ) : recommendationsQuery.error && profileStream ? (
                <div data-testid="state-error-recommendations" className="rounded-xl border border-[#6b5360] bg-[#24445a] p-4 text-sm leading-5 text-[#dbe5e2]">
                  We could not load your shortlist yet. The full shelf below is still available to explore.
                </div>
              ) : recommendations.length ? (
                <div className="space-y-3" data-testid="list-recommendations">
                  {recommendations.map((course, index) => (
                    <div key={course.id} className="rounded-xl border border-[#385668] bg-[#1e3c50] p-3.5" data-testid={`recommendation-${course.id}`}>
                      <div className="flex items-start gap-3">
                        <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-[#f4b183] text-xs font-bold text-[#173047]">{String(index + 1).padStart(2, "0")}</span>
                        <div className="min-w-0 flex-1">
                          <div data-testid={`text-recommendation-title-${course.id}`} className="truncate text-sm font-semibold text-[#fffaf0]">{course.title}</div>
                          <div data-testid={`text-recommendation-meta-${course.id}`} className="mt-1 truncate text-xs text-[#b9c9ca]">{course.category} · {course.duration} · {course.cost}</div>
                        </div>
                        {course.url && (
                          <a
                            data-testid={`link-recommendation-${course.id}`}
                            href={course.url}
                            target="_blank"
                            rel="noreferrer"
                            aria-label={`Open ${course.title}`}
                            className="rounded-lg p-1.5 text-[#f4b183] transition-colors hover:bg-[#385668] hover:text-[#fffaf0]"
                          >
                            <ArrowUpRight className="h-4 w-4" />
                          </a>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p data-testid="text-no-recommendations" className="rounded-xl border border-dashed border-[#385668] p-4 text-sm leading-5 text-[#b9c9ca]">
                  Your profile-based shortlist will appear when matching pathways are available.
                </p>
              )}
              {profileStream && focusAreas.length > 0 && (
                <div className="mt-5 border-t border-[#385668] pt-4">
                  <div className="mb-2 text-[11px] font-semibold uppercase tracking-[0.12em] text-[#87a0a5]">Focus by skill area</div>
                  <div className="flex flex-wrap gap-2" data-testid="list-recommendation-focus">
                    <button
                      type="button"
                      data-testid="button-focus-all"
                      onClick={() => setRecommendationFocus("all")}
                      className={`rounded-full border px-2.5 py-1 text-[11px] font-semibold transition-colors ${recommendationFocus === "all" ? "border-[#f4b183] bg-[#f4b183] text-[#173047]" : "border-[#527083] text-[#dbe5e2] hover:bg-[#385668]"}`}
                    >
                      All focus areas
                    </button>
                    {focusAreas.map((focus) => (
                      <button
                        type="button"
                        key={focus}
                        data-testid={`button-focus-${focus.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`}
                        onClick={() => setRecommendationFocus(focus)}
                        className={`rounded-full border px-2.5 py-1 text-[11px] font-semibold transition-colors ${recommendationFocus === focus ? "border-[#f4b183] bg-[#f4b183] text-[#173047]" : "border-[#527083] text-[#dbe5e2] hover:bg-[#385668]"}`}
                      >
                        {focus}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-[#dedbd3] bg-[#fbfaf7] shadow-none">
            <CardHeader className="border-b border-[#ebe7df] px-6 pb-5 pt-6">
              <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.15em] text-[#0f766e]">
                <Filter className="h-4 w-4" />
                Shape your shelf
              </div>
              <CardTitle className="text-xl text-[#173047]">Find a pathway that fits this season</CardTitle>
              <p className="mt-2 text-sm leading-5 text-[#718084]">Search by skill, provider, or project idea. Then choose a level you can start with.</p>
            </CardHeader>
            <CardContent className="space-y-5 p-6">
              <div>
                <label htmlFor="course-search" className="mb-2 block text-xs font-semibold uppercase tracking-[0.11em] text-[#607276]">Search learning pathways</label>
                <div className="relative">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#8da09e]" />
                  <Input
                    id="course-search"
                    data-testid="input-course-search"
                    type="search"
                    value={search}
                    onChange={(event) => setSearch(event.target.value)}
                    placeholder="Try Python, design, data, communication..."
                    className="h-11 border-[#d7dcd6] bg-[#fffdfa] pl-10 text-sm text-[#173047] shadow-none placeholder:text-[#9aaba8] focus-visible:ring-[#0f766e]"
                  />
                </div>
              </div>
              <div>
                <div className="mb-2 text-xs font-semibold uppercase tracking-[0.11em] text-[#607276]">Level</div>
                <div className="flex flex-wrap gap-2" data-testid="list-level-filters">
                  {LEVELS.map((item) => (
                    <button
                      key={item.value}
                      type="button"
                      data-testid={`button-level-${item.value}`}
                      onClick={() => setLevel(item.value)}
                      className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors ${level === item.value ? "border-[#0f766e] bg-[#0f766e] text-[#f5fcf9]" : "border-[#d4ddd8] bg-[#fffdfa] text-[#607276] hover:border-[#9ccbc0] hover:bg-[#e9f7f3] hover:text-[#176c63]"}`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex flex-col gap-3 border-t border-[#ebe7df] pt-5 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <div className="text-xs font-semibold uppercase tracking-[0.11em] text-[#607276]">Stream lens</div>
                  <div data-testid="text-stream-filter-status" className="mt-1 text-xs text-[#7b8788]">
                    {streamMode === "profile" && profileStream ? `Showing pathways for ${profile.stream}` : "Showing all available streams"}
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    data-testid="button-stream-all"
                    onClick={() => setStreamMode("all")}
                    className={`rounded-lg border px-3 py-2 text-xs font-semibold transition-colors ${streamMode === "all" ? "border-[#284b63] bg-[#284b63] text-[#fffaf0]" : "border-[#d4ddd8] bg-[#fffdfa] text-[#607276] hover:bg-[#edf4f7]"}`}
                  >
                    All streams
                  </button>
                  <button
                    type="button"
                    data-testid="button-stream-profile"
                    disabled={!profileStream}
                    onClick={() => setStreamMode("profile")}
                    className={`rounded-lg border px-3 py-2 text-xs font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-45 ${streamMode === "profile" && profileStream ? "border-[#e77845] bg-[#e77845] text-[#fffaf0]" : "border-[#efcbb7] bg-[#fff4ec] text-[#a34e29] hover:bg-[#ffeadc]"}`}
                  >
                    My stream
                  </button>
                </div>
              </div>
              <div className="flex items-start gap-2 rounded-xl bg-[#f1eee7] px-3.5 py-3 text-xs leading-5 text-[#687879]" data-testid="text-profile-filter-note">
                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#0f766e]" />
                <span>{profileStream ? "Your stream lens is ready. You can switch back to the full shelf at any time." : "Add your stream to your profile for a more useful shortlist and stream lens."}</span>
              </div>
            </CardContent>
          </Card>
        </section>

        <section aria-labelledby="all-pathways-heading">
          <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <div className="mb-2 text-xs font-semibold uppercase tracking-[0.15em] text-[#a57a16]">The learning shelf</div>
              <h2 id="all-pathways-heading" data-testid="text-all-pathways-heading" className="text-2xl font-semibold tracking-[-0.035em] text-[#173047]">Build the next visible skill</h2>
              <p data-testid="text-results-summary" className="mt-1 text-sm text-[#718084]">
                {coursesQuery.isLoading ? "Looking through the curated shelf..." : `${courses.length} pathway${courses.length === 1 ? "" : "s"} to explore`}
              </p>
            </div>
            <Button
              type="button"
              variant="outline"
              data-testid="button-refresh-courses"
              onClick={() => coursesQuery.refetch()}
              disabled={coursesQuery.isFetching}
              className="w-fit border-[#c9d4d1] bg-[#fbfaf7] text-[#285c5a] shadow-none hover:bg-[#e9f7f3]"
            >
              <RefreshCw className={`mr-2 h-4 w-4 ${coursesQuery.isFetching ? "animate-spin" : ""}`} />
              {coursesQuery.isFetching ? "Refreshing" : "Refresh shelf"}
            </Button>
          </div>

          {coursesQuery.isLoading ? (
            <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3" data-testid="state-loading-courses">
              {[0, 1, 2, 3, 4, 5].map((index) => <CourseSkeleton key={index} index={index} />)}
            </div>
          ) : coursesQuery.error ? (
            <Card data-testid="state-error-courses" className="border-[#f1c7aa] bg-[#fff7ef] shadow-none">
              <CardContent className="flex flex-col items-start gap-4 p-6 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h3 data-testid="text-error-courses-title" className="font-semibold text-[#8d4a29]">The learning shelf is taking a pause</h3>
                  <p data-testid="text-error-courses-description" className="mt-1 text-sm leading-5 text-[#a36242]">We could not load the pathways. Try again, or come back when your connection is steadier.</p>
                </div>
                <Button
                  type="button"
                  data-testid="button-retry-courses"
                  onClick={() => coursesQuery.refetch()}
                  className="shrink-0 bg-[#a34e29] text-[#fffaf0] hover:bg-[#8d4324]"
                >
                  Try again
                </Button>
              </CardContent>
            </Card>
          ) : courses.length ? (
            <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3" data-testid="list-courses">
              {courses.map((course) => <CourseCard key={course.id} course={course} />)}
            </div>
          ) : (
            <EmptyState filtered={isFiltered} onReset={resetFilters} />
          )}
        </section>

        <footer className="mt-10 flex flex-col gap-3 border-t border-[#ddd9d0] pt-5 text-xs leading-5 text-[#7b8788] sm:flex-row sm:items-start sm:justify-between">
          <p data-testid="text-curation-note" className="max-w-2xl">
            These are curated SmartCareer Guide learning pathways, not a live external course marketplace. Check each provider&apos;s own terms, schedule, and availability before you commit.
          </p>
          <div data-testid="text-studio-note" className="shrink-0 font-semibold text-[#49646a]">Learn a little. Make something real.</div>
        </footer>
      </div>
    </div>
  );
}