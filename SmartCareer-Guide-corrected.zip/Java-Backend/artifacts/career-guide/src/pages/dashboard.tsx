import { useMemo, useState } from "react";
import { Link } from "wouter";
import { ArrowRight, Bookmark, CalendarDays, Check, Circle, Compass, GraduationCap, PencilLine, Sparkles } from "lucide-react";
import { useGetDashboard, useListCareerRecommendations, getListCareerRecommendationsQueryKey, useListCourses, getListCoursesQueryKey } from "@workspace/api-client-react";
import type { Career } from "@workspace/api-client-react";
import { useProfile, streamToApiFilter, timeAgo } from "@/context/ProfileContext";

type Tab = "overview" | "saved" | "activity";
type CareerCard = Pick<Career, "id" | "title" | "cluster" | "salaryRange">;

function SectionTitle({ eyebrow, title, action }: { eyebrow?: string; title: string; action?: React.ReactNode }) {
  return (
    <div className="mb-4 flex items-end justify-between gap-4">
      <div>
        {eyebrow && <div className="mb-1 text-[10px] font-bold uppercase tracking-[0.18em] text-primary">{eyebrow}</div>}
        <h2 className="text-xl font-semibold tracking-tight text-foreground">{title}</h2>
      </div>
      {action}
    </div>
  );
}

function CareerRow({ career, index, label }: { career: CareerCard; index: number; label: string }) {
  return (
    <Link href={`/careers/${career.id}`} data-testid={`link-${label}-${career.id}`} className="group flex min-w-0 items-center gap-3 rounded-xl border border-border/70 bg-card p-3 transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-sm">
      <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-primary/10 font-mono text-sm font-bold text-primary">{String(index + 1).padStart(2, "0")}</div>
      <div className="min-w-0 flex-1">
        <div className="truncate text-sm font-semibold text-foreground">{career.title}</div>
        <div className="mt-0.5 truncate text-xs text-muted-foreground">{career.cluster} <span aria-hidden="true">·</span> {career.salaryRange}</div>
      </div>
      <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:text-primary" aria-hidden="true" />
    </Link>
  );
}

function SavedCareersTab() {
  const { profile, toggleBookmark } = useProfile();
  const bookmarks = profile.bookmarkedCareers;
  return (
    <section aria-labelledby="saved-heading">
      <SectionTitle eyebrow="Your shortlist" title="Saved careers" action={<Link href="/careers" className="text-sm font-semibold text-primary hover:underline">Explore careers <span aria-hidden="true">→</span></Link>} />
      {bookmarks.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border bg-card/60 px-6 py-14 text-center">
          <Bookmark className="mx-auto mb-3 h-8 w-8 text-primary/70" aria-hidden="true" />
          <h3 id="saved-heading" className="font-semibold">Your shortlist starts here</h3>
          <p className="mx-auto mt-1 max-w-sm text-sm text-muted-foreground">Save a career while exploring and it will stay close at hand.</p>
          <Link href="/careers" className="mt-5 inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground">Explore careers <ArrowRight className="h-4 w-4" /></Link>
        </div>
      ) : (
        <div className="space-y-2">
          {bookmarks.map((career, i) => (
            <div key={career.id} className="flex items-center gap-2">
              <div className="min-w-0 flex-1"><CareerRow career={career} index={i} label="saved-career" /></div>
              <Link href={`/roadmap/${career.id}`} className="hidden rounded-lg border border-border px-3 py-2 text-xs font-semibold text-foreground hover:border-primary/40 sm:block">Roadmap</Link>
              <button type="button" onClick={() => toggleBookmark(career)} aria-label={`Remove ${career.title} from saved careers`} data-testid={`button-remove-saved-${career.id}`} className="rounded-lg border border-border px-3 py-2 text-xs font-medium text-muted-foreground hover:border-destructive/50 hover:text-destructive">Remove</button>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

function ActivityTab() {
  const { profile } = useProfile();
  return (
    <section>
      <SectionTitle eyebrow="Your trail" title="Recent activity" />
      {profile.viewedCareers.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border bg-card/60 px-6 py-14 text-center">
          <Compass className="mx-auto mb-3 h-8 w-8 text-primary/70" aria-hidden="true" />
          <h3 className="font-semibold">Nothing explored yet</h3>
          <p className="mx-auto mt-1 max-w-sm text-sm text-muted-foreground">The careers you visit will appear here for an easy return.</p>
          <Link href="/careers" className="mt-5 inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground">Browse careers <ArrowRight className="h-4 w-4" /></Link>
        </div>
      ) : (
        <div className="space-y-2">
          {profile.viewedCareers.map((career, i) => (
            <Link key={career.id} href={`/careers/${career.id}`} className="flex items-center gap-3 rounded-xl border border-border/70 bg-card p-3 hover:border-primary/40">
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-muted font-mono text-xs text-muted-foreground">{String(i + 1).padStart(2, "0")}</span>
              <span className="min-w-0 flex-1"><span className="block truncate text-sm font-semibold">{career.title}</span><span className="text-xs text-muted-foreground">{career.cluster} · {timeAgo(career.viewedAt)}</span></span>
              <ArrowRight className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
            </Link>
          ))}
        </div>
      )}
    </section>
  );
}

function OverviewTab() {
  const { profile, togglePracticedSkill } = useProfile();
  const dashboardQuery = useGetDashboard();
  const streamFilter = streamToApiFilter(profile.stream);
  const courseParams = { stream: streamFilter };
  const recommendationParams = {
    currentClass: profile.currentClass || undefined,
    stream: streamFilter,
    interests: profile.interests,
    skills: profile.skills,
    goals: profile.goals,
  };
  const recommendationQuery = useListCareerRecommendations(recommendationParams, {
    query: { queryKey: getListCareerRecommendationsQueryKey(recommendationParams), enabled: Boolean(profile.currentClass || profile.stream || profile.interests.length || profile.skills.length || profile.goals.length) },
  });
  const courseQuery = useListCourses(courseParams, { query: { queryKey: getListCoursesQueryKey(courseParams), enabled: true } });
  const quiz = profile.quizResults[0];
  const recommendationResponse = recommendationQuery.data;
  const recommendationRecords: any[] = Array.isArray(recommendationResponse) ? recommendationResponse : Array.isArray((recommendationResponse as any)?.data) ? (recommendationResponse as any).data : [];
  const matches = recommendationRecords.filter((match) => match?.career?.id).slice(0, 3);
  const allSkills = useMemo(() => {
    const response = courseQuery.data;
    const courses: any[] = Array.isArray(response) ? response : Array.isArray((response as any)?.data) ? (response as any).data : [];
    return Array.from(new Set(courses.flatMap((course) => Array.isArray(course?.skills) ? course.skills : []))).filter(Boolean);
  }, [courseQuery.data]);
  const skills = allSkills.slice(0, 8);
  const practiced = skills.filter((skill) => profile.practicedSkills.includes(skill)).length;
  const futureExams = (dashboardQuery.data?.upcomingDeadlines ?? [])
    .filter((deadline) => deadline.type === "exam" && Number.isFinite(new Date(deadline.date).getTime()) && new Date(deadline.date).getTime() >= new Date().setHours(0, 0, 0, 0))
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  const steps = [
    !profile.completed ? { title: "Complete your student profile", detail: "Add your education level and stream for more relevant guidance.", href: "/", action: "Open profile setup" } : null,
    !quiz ? { title: "Take the career assessment", detail: "Get career matches based on your answers.", href: "/assessment", action: "Start assessment" } : null,
    quiz && !matches.length ? { title: "Refresh your career matches", detail: "Retake the assessment to explore another direction.", href: "/assessment", action: "Retake assessment" } : null,
    matches.length > 0 && profile.bookmarkedCareers.length === 0 ? { title: "Save one career to compare", detail: "Keep a promising path on your shortlist.", href: "/careers", action: "Explore careers" } : null,
    skills.length > 0 && practiced < skills.length ? { title: "Practice a course skill", detail: `${skills.length - practiced} course skill${skills.length - practiced === 1 ? "" : "s"} not checked in yet.`, href: "#skills", action: "See skills" } : null,
    profile.completed && (profile.bookmarkedCareers.length > 0 || practiced === skills.length) ? { title: "Turn a career into a plan", detail: "Open a roadmap to see useful milestones and learning paths.", href: matches[0]?.career?.id ? `/roadmap/${matches[0].career.id}` : "/careers", action: "View roadmap" } : null,
  ].filter((step): step is NonNullable<typeof step> => !!step).slice(0, 4);

  return (
    <div className="space-y-6">
      <section className="relative overflow-hidden rounded-[1.5rem] border border-primary/15 bg-[linear-gradient(115deg,hsl(var(--primary)/.12),hsl(var(--card))_58%,hsl(var(--accent)))] p-5 sm:p-7">
        <div className="pointer-events-none absolute -right-12 -top-16 h-56 w-56 rounded-full border-[1px] border-primary/15" />
        <div className="pointer-events-none absolute -right-3 -top-7 h-36 w-36 rounded-full border-[1px] border-primary/20" />
        <div className="relative flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
          <div>
            <div className="mb-3 flex items-center gap-2 text-xs font-bold uppercase tracking-[0.17em] text-primary"><span className="h-1.5 w-1.5 rounded-full bg-primary" /> Your student snapshot</div>
            <h1 className="max-w-xl text-3xl font-semibold leading-tight tracking-[-0.04em] sm:text-4xl">{profile.name ? `Good to see you, ${profile.name.split(" ")[0]}.` : "Your next step, in focus."}</h1>
            <p className="mt-2 max-w-lg text-sm leading-relaxed text-muted-foreground">A clear view of where you are and what to do next in your career plan.</p>
          </div>
          <div id="profile" className="flex min-w-[190px] items-center gap-3 rounded-xl border border-border/70 bg-card/80 p-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary"><GraduationCap className="h-5 w-5" /></div>
            <div className="min-w-0 flex-1"><div className="text-[10px] font-bold uppercase tracking-[0.15em] text-muted-foreground">Education level</div><div className="mt-0.5 truncate text-sm font-semibold">{profile.currentClass || "Not set"}</div>{profile.stream && <div className="truncate text-xs text-muted-foreground">{profile.stream}</div>}</div>
            <span className="sr-only">Use the profile control in the sidebar to edit education details.</span>
          </div>
        </div>
        <div className="relative mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-primary/10 pt-4 text-xs text-muted-foreground">
          <span>{profile.completed ? "Profile details saved" : "Profile needs a few details"}</span>
          <span>{quiz ? `Assessment ${timeAgo(quiz.takenAt)}` : "No assessment completed"}</span>
          <span>{profile.bookmarkedCareers.length} saved career{profile.bookmarkedCareers.length === 1 ? "" : "s"}</span>
        </div>
      </section>

      <section className="grid gap-6 lg:grid-cols-[1.2fr_.8fr]">
        <div className="rounded-2xl border border-border/80 bg-card p-5">
          <SectionTitle eyebrow="Career direction" title="Your top career matches" action={<Link href="/careers" className="text-xs font-semibold text-primary hover:underline">Explore all</Link>} />
          <p className="mb-3 text-xs text-muted-foreground">Matched using your saved education, interests, skills and goals.</p>
          {recommendationQuery.isLoading ? <div className="space-y-2" aria-label="Loading personalized career matches"><div className="h-20 animate-pulse rounded-xl bg-muted" /><div className="h-20 animate-pulse rounded-xl bg-muted" /><div className="h-20 animate-pulse rounded-xl bg-muted" /></div> :
            matches.length ? <div className="space-y-2">{matches.map((match, i) => <article key={match.career.id} className="rounded-xl border border-border/70 bg-card p-3" data-testid={`career-match-${match.career.id}`}><div className="flex items-start gap-3"><span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-primary/10 font-mono text-sm font-bold text-primary">{String(i + 1).padStart(2, "0")}</span><div className="min-w-0 flex-1"><Link href={`/careers/${match.career.id}`} className="text-sm font-semibold hover:text-primary">{match.career.title}</Link><div className="mt-0.5 text-xs text-muted-foreground">{match.career.cluster} · {match.career.salaryRange}</div></div><span className="shrink-0 rounded-full bg-primary/10 px-2.5 py-1 font-mono text-sm font-bold text-primary">{match.matchPercentage}%</span></div>{match.reasons.length > 0 && <ul className="mt-3 space-y-1 border-t border-border pt-2">{match.reasons.slice(0, 2).map((reason, index) => <li key={`${index}-${reason}`} className="flex gap-2 text-xs leading-5 text-muted-foreground"><span className="text-primary">•</span>{reason}</li>)}</ul>}</article>)}</div> :
            <div className="rounded-xl border border-dashed border-border px-4 py-7 text-center"><Sparkles className="mx-auto mb-2 h-5 w-5 text-primary/70" /><p className="text-sm font-medium">{recommendationQuery.isError ? "Career matches are unavailable right now." : "Add education, interests, skills or goals to get personalized matches."}</p><p className="mt-1 text-xs text-muted-foreground">{recommendationQuery.isError ? "Your saved profile remains available. Try again or explore careers." : "Matches appear only when returned by the career guidance service."}</p>{recommendationQuery.isError && <button type="button" onClick={() => recommendationQuery.refetch()} className="mt-3 mr-3 text-xs font-semibold text-primary underline">Retry</button>}<Link href="/careers" className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-primary">Explore careers <ArrowRight className="h-3 w-3" /></Link></div>}
        </div>

        <div className="rounded-2xl border border-border/80 bg-card p-5">
          <SectionTitle eyebrow="Keep momentum" title="Recommended next steps" />
          {steps.length ? <ol className="space-y-1">
            {steps.map((step, i) => <li key={step.title} className="flex gap-3 rounded-xl p-2.5 transition-colors hover:bg-muted/60"><span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full border border-primary/25 bg-primary/5 font-mono text-[11px] font-bold text-primary">{i + 1}</span><div className="min-w-0 flex-1"><div className="text-sm font-semibold">{step.title}</div><p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{step.detail}</p><Link href={step.href} className="mt-1.5 inline-flex items-center gap-1 text-xs font-bold text-primary">{step.action} <ArrowRight className="h-3 w-3" /></Link></div></li>)}
          </ol> : <div className="rounded-xl bg-muted/50 p-4 text-sm text-muted-foreground">You have checked in on every available step. Keep exploring courses and careers as your interests evolve.</div>}
        </div>
      </section>

      <section id="skills" className="grid gap-6 lg:grid-cols-[1.2fr_.8fr]">
        <div className="rounded-2xl border border-border/80 bg-card p-5">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div><div className="mb-1 text-[10px] font-bold uppercase tracking-[0.18em] text-primary">Learning practice</div><h2 className="text-xl font-semibold">Skill check-ins</h2><p className="mt-1 text-xs text-muted-foreground">Mark a skill only after you have practised it. This is your own check-in, not an automatic course completion.</p></div>
            <div className="rounded-xl bg-primary/8 px-3 py-2 text-right"><div className="font-mono text-xl font-semibold text-primary">{practiced}<span className="text-sm text-muted-foreground">/{skills.length}</span></div><div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">checked in</div></div>
          </div>
          {courseQuery.isLoading ? <div className="mt-4 space-y-2"><div className="h-10 animate-pulse rounded-lg bg-muted" /><div className="h-10 animate-pulse rounded-lg bg-muted" /></div> : courseQuery.isError ? <div className="mt-4 rounded-lg bg-muted p-3 text-sm text-muted-foreground">Course skills could not be loaded. <button type="button" onClick={() => courseQuery.refetch()} className="font-semibold text-primary underline">Try again</button></div> : skills.length ? <div className="mt-4 grid gap-2 sm:grid-cols-2">{skills.slice(0, 8).map((skill) => {
            const done = profile.practicedSkills.includes(skill);
            return <button key={skill} type="button" aria-pressed={done} onClick={() => togglePracticedSkill(skill)} data-testid={`button-practice-${skill.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`} className={`flex items-center gap-2.5 rounded-xl border px-3 py-2.5 text-left text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${done ? "border-primary/30 bg-primary/5 text-foreground" : "border-border/80 hover:border-primary/40"}`}><span className={`grid h-5 w-5 shrink-0 place-items-center rounded-full border ${done ? "border-primary bg-primary text-primary-foreground" : "border-muted-foreground/40 text-transparent"}`}>{done ? <Check className="h-3 w-3" /> : <Circle className="h-2 w-2" />}</span><span className="flex-1">{skill}</span><span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{done ? "Practised" : "Check in"}</span></button>;
          })}</div> : <div className="mt-4 rounded-xl border border-dashed border-border p-4 text-sm text-muted-foreground">{profile.stream ? "No course skill names are available for your stream yet." : "Set a stream in your profile to see relevant course skills."}</div>}
          {allSkills.length > skills.length && <Link href="/courses" className="mt-3 inline-flex text-xs font-semibold text-primary hover:underline">Browse courses and more skills <ArrowRight className="ml-1 h-3 w-3" /></Link>}
        </div>

        <div className="rounded-2xl border border-border/80 bg-card p-5">
          <SectionTitle eyebrow="Plan ahead" title="Upcoming exams" action={<CalendarDays className="h-4 w-4 text-primary" aria-hidden="true" />} />
          {dashboardQuery.isLoading ? <div className="space-y-2"><div className="h-14 animate-pulse rounded-xl bg-muted" /><div className="h-14 animate-pulse rounded-xl bg-muted" /></div> : dashboardQuery.isError ? <div className="rounded-xl bg-muted/60 p-4 text-sm text-muted-foreground">Exam deadlines are unavailable right now. <button type="button" onClick={() => dashboardQuery.refetch()} className="font-semibold text-primary underline">Try again</button></div> : futureExams.length ? <ul className="space-y-2">{futureExams.slice(0, 5).map((exam) => <li key={exam.id} className="flex items-center gap-3 rounded-xl bg-muted/45 p-3" data-testid={`exam-deadline-${exam.id}`}><div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary"><CalendarDays className="h-4 w-4" /></div><div className="min-w-0 flex-1"><div className="truncate text-sm font-semibold">{exam.title}</div><div className="mt-0.5 text-xs text-muted-foreground">{new Date(exam.date).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</div></div></li>)}</ul> : <div className="rounded-xl border border-dashed border-border px-4 py-8 text-center"><CalendarDays className="mx-auto mb-2 h-5 w-5 text-muted-foreground" /><p className="text-sm font-medium">No upcoming exam deadlines</p><p className="mt-1 text-xs text-muted-foreground">Only upcoming exam dates from the dashboard are shown here.</p></div>}
        </div>
      </section>
    </div>
  );
}

const TABS: { id: Tab; label: string }[] = [
  { id: "overview", label: "Overview" },
  { id: "saved", label: "Saved Careers" },
  { id: "activity", label: "Recent Activity" },
];

export default function DashboardPage() {
  const { profile } = useProfile();
  const [activeTab, setActiveTab] = useState<Tab>("overview");
  const bookmarkCount = profile.bookmarkedCareers.length;
  const viewedCount = profile.viewedCareers.length;
  return (
    <div className="mx-auto min-h-full max-w-6xl px-4 py-5 sm:px-6 sm:py-7 lg:px-9">
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div><div className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground">Student workspace / dashboard</div><p className="mt-1 text-sm text-muted-foreground">One useful next move at a time.</p></div>
        <div className="hidden items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-medium text-muted-foreground sm:flex"><PencilLine className="h-3.5 w-3.5" /> Profile settings in the sidebar</div>
      </div>
      <div role="tablist" aria-label="Dashboard sections" className="mb-5 flex w-full gap-1 overflow-x-auto rounded-xl border border-border/80 bg-muted/50 p-1 sm:w-fit">
        {TABS.map((tab) => {
          const count = tab.id === "saved" ? bookmarkCount : tab.id === "activity" ? viewedCount : undefined;
          return <button key={tab.id} role="tab" id={`tab-${tab.id}`} aria-selected={activeTab === tab.id} aria-controls={`panel-${tab.id}`} data-testid={`tab-${tab.id}`} onClick={() => setActiveTab(tab.id)} className={`flex shrink-0 items-center gap-2 rounded-lg px-3.5 py-2 text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:px-4 ${activeTab === tab.id ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}>{tab.label}{count !== undefined && <span className={`rounded-full px-1.5 py-0.5 font-mono text-[10px] ${activeTab === tab.id ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>{count}</span>}</button>;
        })}
      </div>
      <div role="tabpanel" id={`panel-${activeTab}`} aria-labelledby={`tab-${activeTab}`}>
        {activeTab === "overview" && <OverviewTab />}
        {activeTab === "saved" && <SavedCareersTab />}
        {activeTab === "activity" && <ActivityTab />}
      </div>
    </div>
  );
}
