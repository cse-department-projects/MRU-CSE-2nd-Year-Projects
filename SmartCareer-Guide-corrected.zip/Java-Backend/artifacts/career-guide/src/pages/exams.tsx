import { useMemo, useState } from "react";
import { ExternalLink, Search } from "lucide-react";
import { getListEntranceExamsQueryKey, useListEntranceExams } from "@workspace/api-client-react";
import { useProfile, streamToApiFilter } from "@/context/ProfileContext";
import { Skeleton } from "@/components/ui/skeleton";

const LEVELS = ["All levels", "10th", "12th", "Diploma", "UG", "PG"];
function isExpired(deadline: string | null) {
  if (!deadline) return false;
  const parsed = new Date(deadline);
  return Number.isFinite(parsed.getTime()) && parsed.getTime() < new Date(new Date().toDateString()).getTime();
}
export default function ExamsPage() {
  const { profile } = useProfile();
  const [level, setLevel] = useState("All levels");
  const [stream, setStream] = useState("Profile stream");
  const [search, setSearch] = useState("");
  const selectedStream = stream === "Profile stream" ? streamToApiFilter(profile.stream) : stream === "All streams" ? undefined : stream;
  const params = { level: level === "All levels" ? undefined : level, stream: selectedStream, search: search.trim() || undefined };
  const query = useListEntranceExams(params, { query: { queryKey: getListEntranceExamsQueryKey(params) } });
  const exams = useMemo(() => {
    const response = query.data;
    const records: any[] = Array.isArray(response) ? response : Array.isArray((response as any)?.data) ? (response as any).data : [];
    return records.slice().sort((a, b) => {
    const aExpired = isExpired(a.deadline), bExpired = isExpired(b.deadline);
    if (aExpired !== bExpired) return aExpired ? 1 : -1;
    if (!a.deadline || !b.deadline) return a.deadline ? -1 : b.deadline ? 1 : a.name.localeCompare(b.name);
    return new Date(a.deadline).getTime() - new Date(b.deadline).getTime();
    });
  }, [query.data]);
  return <main className="mx-auto max-w-5xl px-4 py-6 sm:px-6 lg:px-10 lg:py-9">
    <header className="mb-7"><p className="text-xs font-bold uppercase tracking-[.16em] text-primary">Plan with official sources</p><h1 className="mt-2 text-3xl font-semibold sm:text-4xl">Entrance exams</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">Filter exams by education level and stream. Deadlines are shown only when present in the source records.</p></header>
    <section aria-label="Exam filters" className="mb-6 grid gap-4 rounded-2xl border border-border bg-card p-4 sm:grid-cols-3">
      <label className="text-xs font-semibold text-muted-foreground">Education level<select value={level} onChange={(e) => setLevel(e.target.value)} className="mt-1.5 h-10 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground">{LEVELS.map((item) => <option key={item}>{item}</option>)}</select></label>
      <label className="text-xs font-semibold text-muted-foreground">Stream<select value={stream} onChange={(e) => setStream(e.target.value)} className="mt-1.5 h-10 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground"><option>Profile stream</option><option>All streams</option><option value="Science-MPC">Science (MPC)</option><option value="Science-BiPC">Science (BiPC)</option><option value="Commerce">Commerce</option><option value="Arts">Arts / Humanities</option></select></label>
      <label className="text-xs font-semibold text-muted-foreground">Search exams<span className="relative mt-1.5 block"><Search className="absolute left-3 top-3 h-4 w-4" /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Exam name or authority" className="h-10 w-full rounded-lg border border-input bg-background pl-9 pr-3 text-sm text-foreground" /></span></label>
    </section>
    {query.isLoading ? <div className="space-y-3" aria-label="Loading entrance exams">{[1, 2, 3].map((x) => <Skeleton key={x} className="h-44 rounded-2xl" />)}</div> : query.isError ? <section role="alert" className="rounded-2xl border border-destructive/30 bg-card p-6"><h2 className="font-semibold">Exam records could not be loaded</h2><button onClick={() => query.refetch()} className="mt-3 text-sm font-semibold text-primary underline">Try again</button></section> : exams.length ? <div className="space-y-3">{exams.map((exam) => {
      const expired = isExpired(exam.deadline);
      return <article key={exam.id} className="rounded-2xl border border-border bg-card p-5">
        <div className="flex flex-col justify-between gap-4 sm:flex-row"><div className="min-w-0"><h2 className="text-lg font-semibold">{exam.name}</h2><p className="mt-1 text-sm leading-5 text-muted-foreground">{exam.eligibility}</p></div><span className={`h-fit rounded-full px-3 py-1 text-xs font-bold ${!exam.deadline ? "bg-muted text-muted-foreground" : expired ? "bg-destructive/10 text-destructive" : "bg-primary/10 text-primary"}`}>{!exam.deadline ? "Deadline not announced" : expired ? "Deadline passed" : "Application window in source"}</span></div>
        <div className="mt-4 grid gap-3 border-t border-border pt-4 text-sm sm:grid-cols-3"><div><span className="block text-xs font-semibold uppercase tracking-wide text-muted-foreground">Deadline</span>{exam.deadline ? <span className="font-medium">{exam.deadline}</span> : <span className="font-medium">Not announced by source</span>}{exam.deadlineNote && <span className="block text-xs text-muted-foreground">{exam.deadlineNote}</span>}</div><div><span className="block text-xs font-semibold uppercase tracking-wide text-muted-foreground">Conducting authority</span><span className="font-medium">{exam.conductingAuthority}</span></div><div><span className="block text-xs font-semibold uppercase tracking-wide text-muted-foreground">Level and stream</span><span className="font-medium">{exam.levels.join(", ")} · {exam.streams.join(", ")}</span></div></div>
        <a href={exam.applicationUrl} target="_blank" rel="noreferrer" className="mt-4 inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">Official application information <ExternalLink className="h-4 w-4" /></a>
      </article>;
    })}</div> : <div className="rounded-2xl border border-dashed border-border p-10 text-center"><h2 className="font-semibold">No exams match these filters</h2><p className="mt-1 text-sm text-muted-foreground">Try another level, stream or search term. No records have been added to fill the gap.</p></div>}
  </main>;
}
