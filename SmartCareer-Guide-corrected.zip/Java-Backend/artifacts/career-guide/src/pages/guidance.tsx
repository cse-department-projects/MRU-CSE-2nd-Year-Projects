import { useState } from "react";
import { Link } from "wouter";
import { ArrowUpRight, BookOpen, GraduationCap, RefreshCw } from "lucide-react";
import { getListStudyGuidanceQueryKey, getListCareersQueryKey, getListCoursesQueryKey, getListEntranceExamsQueryKey, useListStudyGuidance, useListCareers, useListCourses, useListEntranceExams } from "@workspace/api-client-react";
import type { ListStudyGuidanceStage } from "@workspace/api-client-react";
import { useProfile, streamToApiFilter } from "@/context/ProfileContext";
import { Skeleton } from "@/components/ui/skeleton";

const STAGES: { value: ListStudyGuidanceStage; label: string }[] = [
  { value: "after-10th", label: "After 10th" },
  { value: "after-12th", label: "After 12th" },
  { value: "after-diploma", label: "After Diploma" },
  { value: "after-graduation", label: "After Graduation" },
];

export default function GuidancePage() {
  const [stage, setStage] = useState<ListStudyGuidanceStage>("after-10th");
  const { profile } = useProfile();
  const guidanceQuery = useListStudyGuidance({ stage }, { query: { queryKey: getListStudyGuidanceQueryKey({ stage }) } });
  const stream = streamToApiFilter(profile.stream);
  const careerParams = { stream };
  const courseParams = { stream };
  const examParams = { level: stage === "after-10th" ? "10th" : stage === "after-graduation" ? "UG" : stage === "after-diploma" ? "Diploma" : "12th", stream };
  const careersQuery = useListCareers(careerParams, { query: { queryKey: getListCareersQueryKey(careerParams) } });
  const coursesQuery = useListCourses(courseParams, { query: { queryKey: getListCoursesQueryKey(courseParams) } });
  const examsQuery = useListEntranceExams(examParams, { query: { queryKey: getListEntranceExamsQueryKey(examParams) } });
  const guidanceResponse = guidanceQuery.data;
  const guidance = Array.isArray(guidanceResponse) ? guidanceResponse[0] : (guidanceResponse as any)?.data?.[0] ?? guidanceResponse;
  const careerResponse = careersQuery.data;
  const courseResponse = coursesQuery.data;
  const examResponse = examsQuery.data;
  const careerRecords: any[] = Array.isArray(careerResponse) ? careerResponse : Array.isArray((careerResponse as any)?.data) ? (careerResponse as any).data : [];
  const courseRecords: any[] = Array.isArray(courseResponse) ? courseResponse : Array.isArray((courseResponse as any)?.data) ? (courseResponse as any).data : [];
  const examRecords: any[] = Array.isArray(examResponse) ? examResponse : Array.isArray((examResponse as any)?.data) ? (examResponse as any).data : [];

  return <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6 lg:px-10 lg:py-9">
    <header className="mb-7 border-b border-border pb-6">
      <p className="mb-2 text-xs font-bold uppercase tracking-[.16em] text-primary">Education pathways · Telangana</p>
      <h1 className="text-3xl font-semibold tracking-tight sm:text-4xl">Choose your next study step.</h1>
      <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">Compare options for the point you are at now. Details come from available study guidance and published records.</p>
    </header>
    <div role="tablist" aria-label="Education stage" className="mb-6 flex gap-2 overflow-x-auto pb-1">
      {STAGES.map((item) => <button key={item.value} role="tab" aria-selected={stage === item.value} onClick={() => setStage(item.value)} className={`shrink-0 rounded-full border px-4 py-2 text-sm font-semibold ${stage === item.value ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-muted-foreground hover:border-primary/40"}`}>{item.label}</button>)}
    </div>
    {guidanceQuery.isLoading ? <div className="space-y-3" aria-label="Loading study guidance">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-24 rounded-2xl" />)}</div> :
      guidanceQuery.isError ? <section role="alert" className="rounded-2xl border border-destructive/30 bg-destructive/5 p-5"><h2 className="font-semibold">Study guidance is unavailable</h2><p className="mt-1 text-sm text-muted-foreground">Your selected stage could not be loaded. Try again in a moment.</p><button onClick={() => guidanceQuery.refetch()} className="mt-3 text-sm font-semibold text-primary underline">Retry</button></section> :
        !guidance ? <section className="rounded-2xl border border-dashed border-border p-8 text-center"><h2 className="font-semibold">No published guidance for this stage yet</h2><p className="mt-1 text-sm text-muted-foreground">Try another stage or explore the records available below.</p></section> :
          <div className="space-y-6">
            <section className="rounded-2xl border border-primary/15 bg-card p-5 sm:p-7">
              <div className="flex items-start gap-3"><div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary"><GraduationCap className="h-5 w-5" /></div><div><p className="text-xs font-bold uppercase tracking-wider text-primary">{guidance.title}</p><h2 className="mt-1 text-xl font-semibold">A pathway, not a one-size-fits-all answer</h2><p className="mt-2 max-w-3xl text-sm leading-6 text-muted-foreground">{guidance.overview}</p></div></div>
            </section>
            <div className="grid gap-4 md:grid-cols-2">
              <InfoBlock title="Stream options" entries={guidance.streamOptions} />
              <InfoBlock title="Course options" entries={guidance.courseOptions} />
              <InfoBlock title="Higher education" entries={guidance.higherEducationOptions} />
              <InfoBlock title="Career directions" entries={guidance.careerPaths} />
            </div>
            <section className="rounded-2xl border border-border bg-card p-5">
              <h2 className="mb-3 flex items-center gap-2 text-lg font-semibold"><BookOpen className="h-4 w-4 text-primary" /> Published records to explore</h2>
              <div className="grid gap-4 lg:grid-cols-3">
                <RecordList title="Careers" loading={careersQuery.isLoading} error={careersQuery.isError} retry={() => careersQuery.refetch()} empty={!careerRecords.length} items={careerRecords.slice(0, 4).map((c) => <Link key={c.id} href={`/careers/${c.id}`} className="block rounded-lg border border-border p-3 hover:border-primary/40"><b className="text-sm">{c.title}</b><span className="mt-1 block text-xs text-muted-foreground">{c.cluster} · {c.demandLevel} demand</span></Link>)} />
                <RecordList title="Courses" loading={coursesQuery.isLoading} error={coursesQuery.isError} retry={() => coursesQuery.refetch()} empty={!courseRecords.length} items={courseRecords.slice(0, 4).map((c) => <div key={c.id} className="rounded-lg border border-border p-3"><b className="text-sm">{c.title}</b><span className="mt-1 block text-xs text-muted-foreground">{c.provider} · {c.duration}</span></div>)} />
                <RecordList title="Entrance exams" loading={examsQuery.isLoading} error={examsQuery.isError} retry={() => examsQuery.refetch()} empty={!examRecords.length} items={examRecords.slice(0, 4).map((exam) => <div key={exam.id} className="rounded-lg border border-border p-3"><b className="text-sm">{exam.name}</b><span className="mt-1 block text-xs text-muted-foreground">{exam.deadline ? `Deadline: ${exam.deadline}` : "Deadline not announced"}</span></div>)} />
              </div>
            </section>
            {(Array.isArray(guidance.officialLinks) ? guidance.officialLinks : []).length > 0 && <section className="rounded-2xl border border-border bg-muted/35 p-5"><h2 className="mb-3 text-sm font-bold uppercase tracking-wider">Official information</h2><div className="flex flex-wrap gap-2">{(Array.isArray(guidance.officialLinks) ? guidance.officialLinks : []).map((link) => <a key={link.url} href={link.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 text-sm font-semibold text-primary hover:border-primary/40">{link.label}<ArrowUpRight className="h-4 w-4" /></a>)}</div></section>}
            <div className="flex flex-wrap gap-3"><Link href="/exams" className="rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground">Compare entrance exams</Link><Link href="/careers" className="rounded-lg border border-border bg-card px-4 py-2.5 text-sm font-semibold">Browse careers</Link></div>
          </div>}
  </main>;
}

function InfoBlock({ title, entries }: { title: string; entries?: string[] }) {
  const safeEntries = Array.isArray(entries) ? entries : [];
  return <section className="rounded-2xl border border-border bg-card p-5"><h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-primary">{title}</h2>{safeEntries.length ? <ul className="space-y-2">{safeEntries.map((entry) => <li key={entry} className="flex gap-2 text-sm leading-5"><span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />{entry}</li>)}</ul> : <p className="text-sm text-muted-foreground">No options listed in the current source.</p>}</section>;
}
function RecordList({ title, loading, error, retry, empty, items }: { title: string; loading: boolean; error: boolean; retry: () => void; empty: boolean; items: React.ReactNode[] }) {
  return <div><h3 className="mb-2 text-sm font-semibold">{title}</h3>{loading ? <div className="space-y-2"><Skeleton className="h-14" /><Skeleton className="h-14" /></div> : error ? <div className="text-sm text-muted-foreground">Records unavailable. <button onClick={retry} className="font-semibold text-primary underline">Retry</button></div> : empty ? <p className="text-sm text-muted-foreground">No matching records available.</p> : <div className="space-y-2">{items}</div>}</div>;
}
