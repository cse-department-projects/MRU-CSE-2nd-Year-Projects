import { Link } from "wouter";
import { useGetTrendingCareers, useGetDashboard, useListCareers, getListCareersQueryKey } from "@workspace/api-client-react";
import { Badge } from "@/components/ui/badge";
import { CareerDemandBadge } from "@/components/CareerDemandBadge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useProfile, streamToApiFilter } from "@/context/ProfileContext";
import { getDaysRemaining, getUrgencyLevel } from "@/components/NotificationsPanel";

const HOME_DEADLINES = [
  { id: "ts-epass-2026", title: "TS ePass Scholarship", subtitle: "SC/ST/BC/EWS fee reimbursement", date: "Sep 30, 2026", isoDate: "2026-09-30", type: "scholarship" as const, href: "/scholarships" },
  { id: "pm-yasasvi-2026", title: "PM Yasasvi Scholarship", subtitle: "OBC/EBC students — ₹75k–1.25L/yr", date: "Oct 31, 2026", isoDate: "2026-10-31", type: "scholarship" as const, href: "/scholarships" },
  { id: "tspsc-group2-2026", title: "TSPSC Group-2 Exam", subtitle: "Telangana government jobs", date: "Oct 20, 2026", isoDate: "2026-10-20", type: "exam" as const, href: "/jobs" },
  { id: "jee-main-reg-2027", title: "JEE Mains Registration", subtitle: "IIT/NIT/IIIT — Session 1", date: "Nov 15, 2026", isoDate: "2026-11-15", type: "exam" as const, href: "/careers" },
  { id: "neet-reg-2027", title: "NEET UG Registration", subtitle: "MBBS/BDS medical entrance", date: "Feb 7, 2027", isoDate: "2027-02-07", type: "exam" as const, href: "/careers" },
  { id: "eamcet-reg-2027", title: "TS EAMCET Registration", subtitle: "Engineering & Medical — Telangana", date: "Mar 1, 2027", isoDate: "2027-03-01", type: "exam" as const, href: "/careers" },
];

const URGENCY_COLORS = {
  critical: { bar: "bg-red-500", badge: "bg-red-100 text-red-700 border-red-200" },
  urgent:   { bar: "bg-orange-500", badge: "bg-orange-100 text-orange-700 border-orange-200" },
  upcoming: { bar: "bg-primary", badge: "bg-primary/10 text-primary border-primary/20" },
  future:   { bar: "bg-muted-foreground/30", badge: "bg-muted text-muted-foreground border-border" },
};

const TYPE_LABELS: Record<string, string> = { scholarship: "Scholarship", exam: "Exam", job: "Job" };

function DeadlinesList() {
  const active = HOME_DEADLINES.filter((d) => getDaysRemaining(d.isoDate) >= 0);
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
      {active.map((d) => {
        const days = getDaysRemaining(d.isoDate);
        const urgency = getUrgencyLevel(days);
        const colors = URGENCY_COLORS[urgency];
        return (
          <Link key={d.id} href={d.href}>
            <div
              data-testid={`deadline-home-${d.id}`}
              className="bg-card border border-card-border rounded-xl p-4 cursor-pointer hover:border-primary/30 hover:shadow-sm transition-all overflow-hidden relative"
            >
              {/* Left urgency stripe */}
              <div className={`absolute left-0 top-0 bottom-0 w-1 ${colors.bar}`} />
              <div className="pl-2">
                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <div className="text-sm font-semibold text-foreground leading-tight">{d.title}</div>
                  <Badge variant="secondary" className={`text-xs shrink-0 capitalize border ${colors.badge}`}>
                    {TYPE_LABELS[d.type] ?? d.type}
                  </Badge>
                </div>
                <div className="text-xs text-muted-foreground mb-2 leading-snug">{d.subtitle}</div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">{d.date}</span>
                  <span className={`text-xs font-bold px-2 py-0.5 rounded-full border ${colors.badge}`}>
                    {days}d left
                  </span>
                </div>
              </div>
            </div>
          </Link>
        );
      })}
    </div>
  );
}

function StatCard({ value, label }: { value: string | number; label: string }) {
  return (
    <div className="bg-card border border-card-border rounded-xl p-5 text-center">
      <div className="text-3xl font-bold text-primary">{value}+</div>
      <div className="text-sm text-muted-foreground mt-1">{label}</div>
    </div>
  );
}

export default function HomePage() {
  const { profile } = useProfile();
  const { data: trending, isLoading: trendingLoading } = useGetTrendingCareers();
  const { data: dashboard } = useGetDashboard();

  const streamFilter = streamToApiFilter(profile.stream);
  const { data: personalizedCareers, isLoading: personalizedLoading } = useListCareers(
    { stream: streamFilter },
    { query: { enabled: !!streamFilter, queryKey: getListCareersQueryKey({ stream: streamFilter }) } }
  );

  const stats = dashboard?.quickStats;
  const personalizedCareerRecords: any[] = Array.isArray(personalizedCareers) ? personalizedCareers : Array.isArray((personalizedCareers as any)?.data) ? (personalizedCareers as any).data : [];
  const showPersonalized = !!streamFilter && personalizedCareerRecords.length > 0;

  const greeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 17) return "Good afternoon";
    return "Good evening";
  };

  return (
    <div className="min-h-full">
      {/* Hero */}
      <div className="relative bg-gradient-to-br from-primary/10 via-background to-accent/10 px-6 py-12 lg:px-12 lg:py-20">
        <div className="max-w-4xl">
          {/* Personalized greeting */}
          {profile.name && (
            <div className="flex items-center gap-2 mb-4">
              <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-sm">
                {profile.name.charAt(0).toUpperCase()}
              </div>
              <span className="text-sm font-medium text-muted-foreground">
                {greeting()}, <span className="text-foreground font-semibold">{profile.name}</span>
                {profile.currentClass && <span className="text-muted-foreground"> · {profile.currentClass}</span>}
                {profile.district && <span className="text-muted-foreground"> · {profile.district}</span>}
              </span>
            </div>
          )}

          <h1 className="text-4xl lg:text-6xl font-bold text-foreground leading-tight">
            Your career starts<br />
            <span className="text-primary">with the right guide.</span>
          </h1>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl leading-relaxed">
            Discover careers that match your strengths, get step-by-step roadmaps, find scholarships,
            and connect with opportunities — all in one place.
          </p>
          <div className="flex flex-wrap gap-3 mt-7">
            <Link href="/assessment">
              <button data-testid="button-start-quiz" className="bg-primary text-primary-foreground px-6 py-3 rounded-xl font-semibold hover:bg-primary/90 transition-colors">
                Take Career Quiz
              </button>
            </Link>
            <Link href="/careers">
              <button data-testid="button-explore-careers" className="bg-card border border-border text-foreground px-6 py-3 rounded-xl font-semibold hover:bg-muted transition-colors">
                Explore Careers
              </button>
            </Link>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="px-6 py-10 lg:px-12">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 max-w-4xl">
          <StatCard value={stats?.totalCareers ?? "50"} label="Career Paths" />
          <StatCard value={stats?.totalJobs ?? "100"} label="Jobs & Internships" />
          <StatCard value={stats?.totalScholarships ?? "20"} label="Scholarships" />
          <StatCard value="3" label="Languages Supported" />
        </div>
      </div>

      {/* Personalized for your stream */}
      {showPersonalized && (
        <div className="px-6 pb-10 lg:px-12">
          <div className="flex items-center justify-between mb-5">
            <div>
              <div className="flex items-center gap-2 mb-0.5">
                <h2 className="text-xl font-bold text-foreground">Careers for {profile.stream}</h2>
                <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20 text-xs">For you</Badge>
              </div>
              <p className="text-sm text-muted-foreground">Best matches based on your stream</p>
            </div>
            <Link href="/careers">
              <button className="text-sm text-primary font-medium hover:underline">View all</button>
            </Link>
          </div>
          {personalizedLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3].map((i) => <Skeleton key={i} className="h-40 rounded-xl" />)}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {personalizedCareerRecords.slice(0, 6).map((career) => (
                <Link key={career.id} href={`/careers/${career.id}`}>
                  <Card className="cursor-pointer hover:shadow-md transition-all border-card-border hover:border-primary/30 border-l-2 border-l-primary">
                    <CardContent className="p-5">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <h3 className="font-semibold text-foreground leading-snug">{career.title}</h3>
                        <CareerDemandBadge level={career.demandLevel} className="shrink-0 text-xs" />
                      </div>
                      <div className="text-xs text-muted-foreground mb-1">{career.cluster}</div>
                      <div className="text-sm font-semibold text-primary">{career.salaryRange}</div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Trending Careers */}
      <div className="px-6 pb-12 lg:px-12">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-xl font-bold text-foreground">Trending Careers in Hyderabad</h2>
            <p className="text-sm text-muted-foreground mt-0.5">High demand, great salaries, growing fast</p>
          </div>
          <Link href="/careers">
            <button className="text-sm text-primary font-medium hover:underline">View all</button>
          </Link>
        </div>
        {trendingLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((i) => <Skeleton key={i} className="h-40 rounded-xl" />)}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {trending?.map((career) => (
              <Link key={career.id} href={`/careers/${career.id}`}>
                <Card data-testid={`card-career-${career.id}`} className="cursor-pointer hover:shadow-md transition-all border-card-border hover:border-primary/30">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between gap-2 mb-3">
                      <h3 className="font-semibold text-foreground leading-snug">{career.title}</h3>
                      <CareerDemandBadge level={career.demandLevel} className="shrink-0 text-xs" />
                    </div>
                    <div className="text-xs text-muted-foreground mb-1">{career.cluster}</div>
                    <div className="text-sm font-medium text-primary">{career.salaryRange}</div>
                    <div className="flex flex-wrap gap-1 mt-3">
                      {career.tags?.slice(0, 3).map((tag) => (
                        <span key={tag} className="text-xs bg-muted px-2 py-0.5 rounded-full text-muted-foreground">{tag}</span>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>

      {/* Features */}
      <div className="bg-muted/40 px-6 py-12 lg:px-12">
        <h2 className="text-xl font-bold text-foreground mb-7">Everything you need to plan your career</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {[
            { title: "Career Assessment", desc: "Discover your personality type and matching careers in 5 questions", href: "/assessment", icon: "✦" },
            { title: "Step-by-step Roadmaps", desc: "From Class 8 to first job — clear milestones for every career", href: "/roadmap/1", icon: "→" },
            { title: "Scholarship Finder", desc: "TS ePass, PM Yasasvi, PMKVY and 20+ more schemes", href: "/scholarships", icon: "⊛" },
            { title: "AI Career Counselor", desc: "Ask anything in English, Telugu, or Hindi. Get instant guidance.", href: "/chat", icon: "◈" },
          ].map((f) => (
            <Link key={f.title} href={f.href}>
              <div className="bg-card border border-card-border rounded-xl p-5 cursor-pointer hover:border-primary/30 hover:shadow-sm transition-all h-full">
                <div className="text-2xl mb-3">{f.icon}</div>
                <h3 className="font-semibold text-foreground mb-2">{f.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Upcoming deadlines — always shown with static data */}
      <div className="px-6 py-10 lg:px-12">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-lg font-bold text-foreground">Upcoming Deadlines</h2>
            <p className="text-sm text-muted-foreground mt-0.5">Scholarships, exams & applications</p>
          </div>
          <Link href="/scholarships">
            <span className="text-sm text-primary hover:underline cursor-pointer font-medium">View all →</span>
          </Link>
        </div>
        <DeadlinesList />
      </div>
    </div>
  );
}
