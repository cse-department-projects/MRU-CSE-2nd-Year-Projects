import { useMemo, useState } from "react";
import { Link } from "wouter";
import {
  ArrowUpRight,
  BookOpen,
  BriefcaseBusiness,
  CheckCircle2,
  ChevronRight,
  Clock3,
  Compass,
  GraduationCap,
  MapPin,
  RefreshCw,
  Route,
  Signal,
  Sparkles,
  Target,
  TrendingUp,
} from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  useGetJobStats,
  useGetTrendingCareers,
  useListCareers,
  useListJobs,
  useListScholarships,
  getGetJobStatsQueryKey,
  getGetTrendingCareersQueryKey,
  getListCareersQueryKey,
  getListJobsQueryKey,
  getListScholarshipsQueryKey,
} from "@workspace/api-client-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

const REFRESH_WINDOW = 300000;
const CLUSTER_COLORS = ["#e77845", "#0f766e", "#284b63", "#d6a23d", "#6c5ce7", "#b95c82"];

function LoadingBlock({ className = "" }: { className?: string }) {
  return <Skeleton className={`bg-[#e8e5dd] ${className}`} />;
}

function QueryState({
  loading,
  error,
  empty,
  children,
}: {
  loading: boolean;
  error: boolean;
  empty: boolean;
  children: React.ReactNode;
}) {
  if (loading) {
    return (
      <div className="space-y-3" data-testid="state-loading">
        <LoadingBlock className="h-5 w-40" />
        <LoadingBlock className="h-20 w-full rounded-2xl" />
        <LoadingBlock className="h-20 w-full rounded-2xl" />
      </div>
    );
  }
  if (error) {
    return (
      <div
        className="rounded-2xl border border-[#f1c7aa] bg-[#fff7ef] p-5 text-sm text-[#8d4a29]"
        data-testid="state-error"
      >
        This signal is taking a little longer to arrive. Try refreshing when you have a moment.
      </div>
    );
  }
  if (empty) {
    return (
      <div
        className="rounded-2xl border border-dashed border-[#d9d5cc] bg-[#fbfaf7] p-6 text-sm text-muted-foreground"
        data-testid="state-empty"
      >
        We do not have enough records here yet. Check the wider career and opportunity directories for the next step.
      </div>
    );
  }
  return <>{children}</>;
}

function demandScore(level?: string) {
  if (level === "high") return 86;
  if (level === "medium") return 62;
  return 38;
}

function formatDeadline(value?: string | null) {
  if (!value) return "Deadline not listed";
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value;
  return parsed.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

function SignalPill({ tone, children }: { tone: "warm" | "teal" | "ink"; children: React.ReactNode }) {
  const toneClass = {
    warm: "border-[#f4cfb8] bg-[#fff2e8] text-[#a34e29]",
    teal: "border-[#b8ddd6] bg-[#e9f7f3] text-[#176c63]",
    ink: "border-[#c3d3dc] bg-[#edf4f7] text-[#284b63]",
  }[tone];
  return <span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[11px] font-semibold ${toneClass}`}>{children}</span>;
}

export default function IntelligencePage() {
  const [lastRefreshed, setLastRefreshed] = useState<Date | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const careersQuery = useListCareers(undefined, { query: { staleTime: REFRESH_WINDOW, queryKey: getListCareersQueryKey() } });
  const trendingQuery = useGetTrendingCareers({ query: { staleTime: REFRESH_WINDOW, queryKey: getGetTrendingCareersQueryKey() } });
  const jobsQuery = useListJobs(undefined, { query: { staleTime: REFRESH_WINDOW, queryKey: getListJobsQueryKey() } });
  const statsQuery = useGetJobStats({ query: { staleTime: REFRESH_WINDOW, queryKey: getGetJobStatsQueryKey() } });
  const scholarshipsQuery = useListScholarships(undefined, { query: { staleTime: REFRESH_WINDOW, queryKey: getListScholarshipsQueryKey() } });

  const careerResponse = careersQuery.data;
  const trendingResponse = trendingQuery.data;
  const jobsResponse = jobsQuery.data;
  const careers: any[] = Array.isArray(careerResponse) ? careerResponse : Array.isArray((careerResponse as any)?.data) ? (careerResponse as any).data : [];
  const trending: any[] = Array.isArray(trendingResponse) ? trendingResponse : Array.isArray((trendingResponse as any)?.data) ? (trendingResponse as any).data : [];
  const jobs: any[] = Array.isArray(jobsResponse) ? jobsResponse : Array.isArray((jobsResponse as any)?.data) ? (jobsResponse as any).data : [];
  const scholarships = scholarshipsQuery.data ?? [];
  const jobStats = statsQuery.data;
  const isLoading = careersQuery.isLoading || trendingQuery.isLoading || jobsQuery.isLoading || statsQuery.isLoading || scholarshipsQuery.isLoading;
  const hasError = Boolean(careersQuery.error || trendingQuery.error || jobsQuery.error || statsQuery.error || scholarshipsQuery.error);

  const clusters = useMemo(() => {
    const map = new Map<string, { cluster: string; careers: number; highDemand: number }>();
    careers.forEach((career) => {
      const existing = map.get(career.cluster) ?? { cluster: career.cluster, careers: 0, highDemand: 0 };
      existing.careers += 1;
      if (career.demandLevel === "high") existing.highDemand += 1;
      map.set(career.cluster, existing);
    });
    return [...map.values()].sort((a, b) => b.highDemand - a.highDemand || b.careers - a.careers).slice(0, 6);
  }, [careers]);

  const forecast = useMemo(() => {
    const source = [...(trending.length ? trending : careers)]
      .filter((career) => career.demandLevel !== "varies")
      .slice(0, 12);
    const current = source.length
      ? Math.round(source.reduce((sum, career) => sum + demandScore(career.demandLevel), 0) / source.length)
      : 0;
    const highShare = source.length ? source.filter((career) => career.demandLevel === "high").length / source.length : 0;
    return [
      { horizon: "Today", value: current, note: "current signals" },
      { horizon: "2027", value: Math.min(100, Math.round(current + highShare * 7)), note: "near-term" },
      { horizon: "2030", value: Math.min(100, Math.round(current + highShare * 13)), note: "build depth" },
      { horizon: "2035", value: Math.min(100, Math.round(current + highShare * 18)), note: "long view" },
    ];
  }, [careers, trending]);

  const demandMix = useMemo(() => {
    const counts = careers.reduce(
      (acc, career) => {
        acc[career.demandLevel] += 1;
        return acc;
      },
      { high: 0, medium: 0, low: 0, varies: 0 },
    );
    return [
      { name: "High demand", value: counts.high, color: "#e77845" },
      { name: "Growing", value: counts.medium, color: "#0f766e" },
      { name: "Steady", value: counts.low, color: "#9aabb3" },
      { name: "Not rated", value: counts.varies, color: "#c5b8ab" },
    ];
  }, [careers]);

  const skillSignals = useMemo(() => {
    const tags = new Map<string, number>();
    [...trending, ...careers].forEach((career) => {
      (career.tags ?? []).forEach((tag) => tags.set(tag, (tags.get(tag) ?? 0) + (career.demandLevel === "high" ? 2 : 1)));
    });
    return [...tags.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5);
  }, [careers, trending]);

  const refreshAll = async () => {
    if (refreshing) return;
    setRefreshing(true);
    await Promise.all([
      careersQuery.refetch(),
      trendingQuery.refetch(),
      jobsQuery.refetch(),
      statsQuery.refetch(),
      scholarshipsQuery.refetch(),
    ]);
    setLastRefreshed(new Date());
    setRefreshing(false);
  };

  const totalOpportunities = jobStats ? jobStats.totalJobs + jobStats.totalInternships : jobs.length;
  const topLocation = jobStats?.topLocations?.[0] ?? "Telangana";
  const topRole = jobStats?.topRoles?.[0] ?? trending[0]?.title ?? "Explore roles";

  return (
    <div className="min-h-[100dvh] bg-[#f7f6f2] text-[#173047]">
      <div className="mx-auto max-w-[1500px] px-4 py-6 sm:px-6 lg:px-10 lg:py-9">
        <header className="mb-8 flex flex-col gap-5 border-b border-[#ddd9d0] pb-7 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <div className="mb-4 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-[#0f766e]">
              <span className="h-2 w-2 rounded-full bg-[#e77845]" />
              SmartCareer Guide <span className="text-[#abb2af]">/</span> Intelligence
            </div>
            <h1 className="max-w-3xl text-4xl font-semibold leading-[1.03] tracking-[-0.04em] text-[#173047] sm:text-5xl">
              A clearer map of the future.
            </h1>
            <p className="mt-3 max-w-2xl text-sm leading-6 text-[#65737b] sm:text-base">
              Career Intelligence turns the opportunities in our platform into useful signals for your next decision — grounded in demand, access, and preparation.
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-3">
            <div className="text-right text-xs text-[#7a878a]" data-testid="text-refresh-status">
              <div className="font-semibold text-[#49646a]">Research desk</div>
              <div>{lastRefreshed ? `Updated ${lastRefreshed.toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit" })}` : "Using the latest available data"}</div>
            </div>
            <Button
              variant="outline"
              onClick={refreshAll}
              disabled={refreshing}
              data-testid="button-refresh-intelligence"
              className="h-10 border-[#c9d4d1] bg-[#fbfaf7] text-[#285c5a] shadow-none hover:bg-[#e9f7f3]"
            >
              <RefreshCw className={`mr-2 h-4 w-4 ${refreshing ? "animate-spin" : ""}`} />
              {refreshing ? "Refreshing" : "Refresh signals"}
            </Button>
          </div>
        </header>

        <section className="mb-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4" aria-label="Market overview">
          {[
            { label: "Open opportunities", value: totalOpportunities, detail: `${jobStats?.totalInternships ?? jobs.filter((job) => job.type === "internship").length} internships included`, icon: BriefcaseBusiness, tone: "orange" },
            { label: "Careers tracked", value: careers.length, detail: `${trending.length} appearing in the demand view`, icon: Compass, tone: "teal" },
            { label: "Support pathways", value: scholarships.length, detail: "scholarships and schemes to explore", icon: GraduationCap, tone: "gold" },
            { label: "Strongest location signal", value: topLocation, detail: `${topRole} is the leading role signal`, icon: MapPin, tone: "ink" },
          ].map((item, index) => {
            const Icon = item.icon;
            return (
              <Card key={item.label} className={`overflow-hidden border-[#dedbd3] bg-[#fbfaf7] shadow-none transition-transform duration-300 hover:-translate-y-1 ${index === 0 ? "sm:col-span-2 xl:col-span-1" : ""}`} data-testid={`card-overview-${index}`}>
                <CardContent className="relative p-5">
                  <div className={`absolute right-0 top-0 h-20 w-20 rounded-bl-[42px] ${item.tone === "orange" ? "bg-[#fff0e6]" : item.tone === "teal" ? "bg-[#e3f4f0]" : item.tone === "gold" ? "bg-[#fbf2d6]" : "bg-[#e8f0f4]"}`} />
                  <Icon className={`relative mb-6 h-5 w-5 ${item.tone === "orange" ? "text-[#dc6d39]" : item.tone === "teal" ? "text-[#0f766e]" : item.tone === "gold" ? "text-[#a57a16]" : "text-[#284b63]"}`} />
                  <div className="relative flex items-end justify-between gap-3">
                    <div>
                      <div className="text-2xl font-semibold tracking-[-0.04em] text-[#173047]" data-testid={`text-overview-value-${index}`}>
                        {isLoading ? <LoadingBlock className="h-8 w-20" /> : item.value}
                      </div>
                      <div className="mt-1 text-xs font-semibold uppercase tracking-[0.1em] text-[#607276]">{item.label}</div>
                    </div>
                    <Signal className="mb-1 h-4 w-4 text-[#a9b7b4]" />
                  </div>
                  <p className="mt-3 text-xs leading-5 text-[#7b8788]">{item.detail}</p>
                </CardContent>
              </Card>
            );
          })}
        </section>

        <section className="mb-8 grid gap-6 xl:grid-cols-[1.45fr_0.85fr]">
          <Card className="overflow-hidden border-[#234b61] bg-[#173047] text-[#f6f4ed] shadow-none">
            <CardHeader className="flex flex-row items-start justify-between gap-4 border-b border-[#385668] px-6 pb-5 pt-6">
              <div>
                <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.15em] text-[#f4b183]">
                  <TrendingUp className="h-4 w-4" /> Demand horizon
                </div>
                <CardTitle className="text-2xl font-medium tracking-[-0.03em] text-[#fffaf0]">Where the signals are leaning</CardTitle>
                <p className="mt-2 max-w-lg text-sm leading-5 text-[#b9c9ca]">A planning view built from the careers currently marked as in demand in SmartCareer Guide.</p>
              </div>
              <SignalPill tone="warm">Planning index</SignalPill>
            </CardHeader>
            <CardContent className="p-6">
              <div className="h-[235px] w-full" data-testid="chart-demand-horizon">
                {isLoading ? <LoadingBlock className="h-full w-full rounded-xl bg-[#24445a]" /> : forecast[0].value === 0 ? <div className="flex h-full items-center justify-center text-sm text-[#b9c9ca]">Demand signals will appear once career records load.</div> : (
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={forecast} margin={{ top: 12, right: 8, left: -18, bottom: 0 }}>
                      <defs>
                        <linearGradient id="horizonFill" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#e77845" stopOpacity={0.42} />
                          <stop offset="100%" stopColor="#e77845" stopOpacity={0.02} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid stroke="#385668" vertical={false} />
                      <XAxis dataKey="horizon" tick={{ fill: "#b9c9ca", fontSize: 11 }} axisLine={false} tickLine={false} />
                      <YAxis domain={[0, 100]} tick={{ fill: "#87a0a5", fontSize: 10 }} axisLine={false} tickLine={false} />
                      <Tooltip contentStyle={{ background: "#f7f6f2", border: "1px solid #d9d5cc", borderRadius: 12, color: "#173047", fontSize: 12 }} formatter={(value) => [`${value} / 100`, "Signal strength"]} />
                      <Area type="monotone" dataKey="value" stroke="#f09a68" strokeWidth={3} fill="url(#horizonFill)" dot={{ r: 4, fill: "#f7f6f2", stroke: "#f09a68", strokeWidth: 2 }} activeDot={{ r: 6, fill: "#f09a68", stroke: "#fffaf0", strokeWidth: 2 }} />
                    </AreaChart>
                  </ResponsiveContainer>
                )}
              </div>
              <div className="mt-4 flex items-start gap-3 border-t border-[#385668] pt-4 text-xs leading-5 text-[#b9c9ca]">
                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#e8b05e]" />
                <span data-testid="text-horizon-note">A stronger line is a reason to investigate a path, not a promise of a job. Pair it with the skills and access signals below.</span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-[#dedbd3] bg-[#fbfaf7] shadow-none">
            <CardHeader className="border-b border-[#ebe7df] px-6 pb-4 pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="mb-2 text-xs font-semibold uppercase tracking-[0.15em] text-[#0f766e]">Market texture</div>
                  <CardTitle className="text-xl text-[#173047]">Demand mix</CardTitle>
                </div>
                <Target className="h-5 w-5 text-[#e77845]" />
              </div>
            </CardHeader>
            <CardContent className="px-6 pb-6 pt-4">
              <div className="h-[178px]" data-testid="chart-demand-mix">
                {isLoading ? <LoadingBlock className="h-full w-full rounded-xl" /> : (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={demandMix} layout="vertical" margin={{ top: 5, right: 12, left: 0, bottom: 0 }}>
                      <XAxis type="number" hide />
                      <YAxis type="category" dataKey="name" width={78} tick={{ fill: "#65737b", fontSize: 11 }} axisLine={false} tickLine={false} />
                      <Tooltip cursor={{ fill: "#f1eee7" }} contentStyle={{ background: "#f7f6f2", border: "1px solid #d9d5cc", borderRadius: 12, color: "#173047", fontSize: 12 }} />
                      <Bar dataKey="value" radius={[0, 5, 5, 0]} barSize={24}>
                        {demandMix.map((entry) => <Cell key={entry.name} fill={entry.color} />)}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </div>
              <div className="rounded-xl bg-[#f1eee7] px-3 py-2.5 text-xs leading-5 text-[#687879]" data-testid="text-demand-mix-note">
                This is the shape of the career catalogue today, not a ranking of your personal fit.
              </div>
            </CardContent>
          </Card>
        </section>

        <section className="mb-8 grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <Card className="border-[#dedbd3] bg-[#fbfaf7] shadow-none">
            <CardHeader className="flex flex-row items-start justify-between border-b border-[#ebe7df] px-6 pb-5 pt-6">
              <div>
                <div className="mb-2 text-xs font-semibold uppercase tracking-[0.15em] text-[#0f766e]">Industry signals</div>
                <CardTitle className="text-xl text-[#173047]">Clusters worth a closer look</CardTitle>
                <p className="mt-2 text-sm text-[#718084]">The areas with the most high-demand career records in this dataset.</p>
              </div>
              <Link href="/careers" data-testid="link-explore-all-careers" className="hidden items-center gap-1 text-xs font-semibold text-[#0f766e] transition-colors hover:text-[#e77845] sm:flex">
                Explore careers <ArrowUpRight className="h-3.5 w-3.5" />
              </Link>
            </CardHeader>
            <CardContent className="p-6">
              <QueryState loading={careersQuery.isLoading} error={Boolean(careersQuery.error)} empty={!clusters.length}>
                <div className="grid gap-3 sm:grid-cols-2">
                  {clusters.map((cluster, index) => (
                    <Link href={`/careers?cluster=${encodeURIComponent(cluster.cluster)}`} key={cluster.cluster} data-testid={`link-cluster-${index}`} className="group rounded-2xl border border-[#e4e0d7] bg-[#fffdfa] p-4 transition-all duration-200 hover:-translate-y-0.5 hover:border-[#c8dcd7] hover:bg-[#f0f8f5]">
                      <div className="mb-3 flex items-center justify-between">
                        <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: CLUSTER_COLORS[index % CLUSTER_COLORS.length] }} />
                        <ChevronRight className="h-4 w-4 text-[#a2adab] transition-transform group-hover:translate-x-1 group-hover:text-[#0f766e]" />
                      </div>
                      <div className="line-clamp-1 text-sm font-semibold text-[#274756]" data-testid={`text-cluster-name-${index}`}>{cluster.cluster}</div>
                      <div className="mt-1 text-xs text-[#7d8988]">{cluster.careers} careers · {cluster.highDemand} high-demand signal{cluster.highDemand === 1 ? "" : "s"}</div>
                    </Link>
                  ))}
                </div>
              </QueryState>
            </CardContent>
          </Card>

          <Card className="border-[#dedbd3] bg-[#fbfaf7] shadow-none">
            <CardHeader className="border-b border-[#ebe7df] px-6 pb-5 pt-6">
              <div className="mb-2 text-xs font-semibold uppercase tracking-[0.15em] text-[#a57a16]">Opportunity access</div>
              <CardTitle className="text-xl text-[#173047]">Where to look next</CardTitle>
              <p className="mt-2 text-sm text-[#718084]">Signals that make a career plan more practical, not just interesting.</p>
            </CardHeader>
            <CardContent className="space-y-3 p-6">
              <Link href="/jobs" data-testid="link-intelligence-jobs" className="group flex items-center gap-3 rounded-2xl border border-[#e4e0d7] bg-[#fffdfa] p-4 transition-colors hover:border-[#efcbb7] hover:bg-[#fff4ec]">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#fff0e6] text-[#dc6d39]"><BriefcaseBusiness className="h-5 w-5" /></span>
                <span className="min-w-0 flex-1"><span className="block text-sm font-semibold text-[#274756]">Jobs and internships</span><span className="mt-1 block text-xs text-[#7d8988]">{totalOpportunities} opportunities · {topLocation} leads locations</span></span>
                <ChevronRight className="h-4 w-4 text-[#9aaba8] transition-transform group-hover:translate-x-1" />
              </Link>
              <Link href="/scholarships" data-testid="link-intelligence-scholarships" className="group flex items-center gap-3 rounded-2xl border border-[#e4e0d7] bg-[#fffdfa] p-4 transition-colors hover:border-[#d6dfb8] hover:bg-[#f7fae9]">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#f4f5df] text-[#8b7b23]"><GraduationCap className="h-5 w-5" /></span>
                <span className="min-w-0 flex-1"><span className="block text-sm font-semibold text-[#274756]">Scholarships and schemes</span><span className="mt-1 block text-xs text-[#7d8988]">{scholarships.length} pathways in the directory</span></span>
                <ChevronRight className="h-4 w-4 text-[#9aaba8] transition-transform group-hover:translate-x-1" />
              </Link>
            </CardContent>
          </Card>
        </section>

        <section className="mb-8 grid gap-6 xl:grid-cols-[0.8fr_1.2fr]">
          <Card className="border-[#dedbd3] bg-[#e9f7f3] shadow-none">
            <CardHeader className="px-6 pb-3 pt-6">
              <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.15em] text-[#0f766e]"><Sparkles className="h-4 w-4" /> Skill signals</div>
              <CardTitle className="text-xl text-[#173047]">What to build deliberately</CardTitle>
              <p className="mt-2 text-sm leading-5 text-[#55716f]">Tags appearing most often across the current career and trending-career records.</p>
            </CardHeader>
            <CardContent className="px-6 pb-6">
              <QueryState loading={careersQuery.isLoading || trendingQuery.isLoading} error={Boolean(careersQuery.error || trendingQuery.error)} empty={!skillSignals.length}>
                <div className="space-y-3">
                  {skillSignals.map(([skill, score], index) => (
                    <div key={skill} className="flex items-center gap-3" data-testid={`row-skill-${index}`}>
                      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#d4eee7] text-xs font-bold text-[#176c63]">{String(index + 1).padStart(2, "0")}</div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-3 text-sm font-semibold text-[#274756]"><span className="truncate">{skill}</span><span className="text-xs font-medium text-[#658783]">{score} signals</span></div>
                        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-[#cfe7e1]"><div className="h-full rounded-full bg-[#0f766e] transition-all duration-700" style={{ width: `${Math.min(100, score * 10)}%` }} /></div>
                      </div>
                    </div>
                  ))}
                </div>
                <Link href="/careers" data-testid="link-build-skills" className="mt-5 flex items-center justify-center gap-2 rounded-xl border border-[#aad4ca] bg-[#f4fcf8] px-4 py-2.5 text-xs font-semibold text-[#176c63] transition-colors hover:bg-[#ffffff]">
                  Find careers that use these skills <ArrowUpRight className="h-3.5 w-3.5" />
                </Link>
              </QueryState>
            </CardContent>
          </Card>

          <Card className="border-[#dedbd3] bg-[#fbfaf7] shadow-none">
            <CardHeader className="flex flex-row items-start justify-between gap-4 border-b border-[#ebe7df] px-6 pb-5 pt-6">
              <div>
                <div className="mb-2 text-xs font-semibold uppercase tracking-[0.15em] text-[#284b63]">Trending right now</div>
                <CardTitle className="text-xl text-[#173047]">Paths students can investigate</CardTitle>
              </div>
              <SignalPill tone="ink">{trending.length} signals</SignalPill>
            </CardHeader>
            <CardContent className="p-6">
              <QueryState loading={trendingQuery.isLoading} error={Boolean(trendingQuery.error)} empty={!trending.length}>
                <div className="grid gap-3 sm:grid-cols-2">
                  {trending.slice(0, 6).map((career, index) => (
                    <Link href={`/careers/${career.id}`} key={career.id} data-testid={`link-trending-career-${career.id}`} className="group flex items-start gap-3 rounded-2xl border border-[#e4e0d7] bg-[#fffdfa] p-4 transition-all duration-200 hover:-translate-y-0.5 hover:border-[#bdd0d8] hover:bg-[#f2f7f8]">
                      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#e9f1f4] text-xs font-bold text-[#284b63]">{String(index + 1).padStart(2, "0")}</span>
                      <span className="min-w-0 flex-1"><span className="block truncate text-sm font-semibold text-[#274756]">{career.title}</span><span className="mt-1 block truncate text-xs text-[#7d8988]">{career.cluster} · {career.salaryRange}</span></span>
                      <ChevronRight className="mt-1 h-4 w-4 shrink-0 text-[#a2adab] transition-transform group-hover:translate-x-1" />
                    </Link>
                  ))}
                </div>
              </QueryState>
            </CardContent>
          </Card>
        </section>

        <section className="mb-8">
          <Card className="border-[#dedbd3] bg-[#fbfaf7] shadow-none">
            <CardHeader className="flex flex-col gap-3 border-b border-[#ebe7df] px-6 pb-5 pt-6 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.15em] text-[#a57a16]"><Route className="h-4 w-4" /> Long-term outlook</div>
                <CardTitle className="text-2xl text-[#173047]">Plan in chapters, not guesses</CardTitle>
                <p className="mt-2 max-w-2xl text-sm leading-5 text-[#718084]">Use the next 5–10 years as a sequence of skills, exposure, and choices. A first direction can change as you learn.</p>
              </div>
              <Badge variant="outline" className="w-fit border-[#e7d7a9] bg-[#fff9e8] text-[#8a6b18]">Scenario view, not a forecast</Badge>
            </CardHeader>
            <CardContent className="grid gap-5 p-6 lg:grid-cols-[1.2fr_0.8fr]">
              <div className="grid gap-3 sm:grid-cols-3" data-testid="outlook-chapters">
                {[
                  { year: "Now → 2027", title: "Get oriented", body: "Compare two or three paths and start one visible, useful project.", icon: Compass, tone: "bg-[#fff0e6] text-[#dc6d39]" },
                  { year: "2027 → 2030", title: "Build proof", body: "Stack the skills, internships, and mentors that make your direction real.", icon: BookOpen, tone: "bg-[#e9f7f3] text-[#0f766e]" },
                  { year: "2030 → 2035", title: "Choose leverage", body: "Move toward the work, place, and responsibility that fit your strengths.", icon: TrendingUp, tone: "bg-[#edf1f5] text-[#284b63]" },
                ].map((chapter, index) => {
                  const Icon = chapter.icon;
                  return <div key={chapter.year} className="rounded-2xl border border-[#e4e0d7] bg-[#fffdfa] p-4 transition-transform duration-300 hover:-translate-y-1" data-testid={`card-outlook-${index}`}>
                    <div className={`mb-4 flex h-9 w-9 items-center justify-center rounded-xl ${chapter.tone}`}><Icon className="h-4 w-4" /></div>
                    <div className="text-[11px] font-bold uppercase tracking-[0.1em] text-[#7b8788]">{chapter.year}</div>
                    <div className="mt-1 text-sm font-semibold text-[#274756]">{chapter.title}</div>
                    <p className="mt-2 text-xs leading-5 text-[#718084]">{chapter.body}</p>
                  </div>;
                })}
              </div>
              <div className="rounded-2xl border border-[#e7d7a9] bg-[#fff9e8] p-5">
                <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-[#795f1c]"><Clock3 className="h-4 w-4" /> Our honest method</div>
                <p className="text-xs leading-5 text-[#7f7044]" data-testid="text-methodology">
                  The horizon line is a planning index calculated from the demand levels of loaded career records and the share of high-demand paths. It does not predict salaries, hiring cycles, or your outcome. We show it to help you ask better questions, then point you back to real careers, opportunities, and support pathways.
                </p>
                <Link href="/assessment" data-testid="link-start-assessment" className="mt-4 inline-flex items-center gap-2 text-xs font-semibold text-[#8a6b18] transition-colors hover:text-[#dc6d39]">Find your starting point <ArrowUpRight className="h-3.5 w-3.5" /></Link>
              </div>
            </CardContent>
          </Card>
        </section>

        <footer className="flex flex-col gap-3 border-t border-[#ddd9d0] pt-5 text-xs text-[#7b8788] sm:flex-row sm:items-center sm:justify-between">
          <span data-testid="text-data-note">Signals are based on the SmartCareer Guide directory and may change as records are updated.</span>
          <div className="flex items-center gap-4">
            <Link href="/careers" data-testid="link-footer-careers" className="font-semibold text-[#285c5a] hover:text-[#e77845]">Careers</Link>
            <Link href="/jobs" data-testid="link-footer-jobs" className="font-semibold text-[#285c5a] hover:text-[#e77845]">Jobs</Link>
            <Link href="/scholarships" data-testid="link-footer-scholarships" className="font-semibold text-[#285c5a] hover:text-[#e77845]">Scholarships</Link>
          </div>
        </footer>
      </div>
    </div>
  );
}