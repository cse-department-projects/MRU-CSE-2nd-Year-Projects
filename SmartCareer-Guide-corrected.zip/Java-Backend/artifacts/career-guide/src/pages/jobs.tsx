import { useState } from "react";
import { useListJobs, useGetJobStats, getListJobsQueryKey } from "@workspace/api-client-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function JobsPage() {
  const [activeTab, setActiveTab] = useState<"all" | "job" | "internship" | "freelance">("all");
  const [location, setLocation] = useState("");
  const [remoteOnly, setRemoteOnly] = useState(false);

  const { data: jobs, isLoading } = useListJobs(
    {
      type: activeTab !== "all" ? activeTab : undefined,
      location: location || undefined,
      remote: remoteOnly || undefined,
    },
    {
      query: {
        queryKey: getListJobsQueryKey({
          type: activeTab !== "all" ? activeTab : undefined,
          location: location || undefined,
          remote: remoteOnly || undefined,
        }),
      },
    }
  );

  // The API may return either a jobs array or an object containing a data array.
  const jobRecords: any[] = Array.isArray(jobs)
    ? jobs
    : Array.isArray((jobs as any)?.data)
      ? (jobs as any).data
      : Array.isArray((jobs as any)?.jobs)
        ? (jobs as any).jobs
        : Array.isArray((jobs as any)?.results)
          ? (jobs as any).results
          : [];

  const { data: stats } = useGetJobStats();

  const trustColor = (score: number) => {
    if (score >= 90) return "text-green-600";
    if (score >= 75) return "text-yellow-600";
    return "text-red-500";
  };

  return (
    <div className="p-6 lg:p-12">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground">Jobs & Internships</h1>
        <p className="text-muted-foreground mt-1">
          {stats ? `${stats.totalJobs} jobs · ${stats.totalInternships} internships available` : "Loading opportunities..."}
        </p>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
          <div className="bg-card border border-card-border rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-primary">{stats.totalJobs}</div>
            <div className="text-xs text-muted-foreground mt-0.5">Full-time Jobs</div>
          </div>
          <div className="bg-card border border-card-border rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-primary">{stats.totalInternships}</div>
            <div className="text-xs text-muted-foreground mt-0.5">Internships</div>
          </div>
          <div className="bg-card border border-card-border rounded-xl p-4 text-center">
            <div className="text-sm font-bold text-primary">{stats.averageStipend}</div>
            <div className="text-xs text-muted-foreground mt-0.5">Avg. Stipend</div>
          </div>
          <div className="bg-card border border-card-border rounded-xl p-4 text-center">
            <div className="text-sm font-bold text-primary">Hyderabad+</div>
            <div className="text-xs text-muted-foreground mt-0.5">Top Location</div>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-1 mb-5 bg-muted rounded-lg p-1 w-fit">
        {(["all", "job", "internship", "freelance"] as const).map((tab) => (
          <button
            key={tab}
            data-testid={`tab-${tab}`}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors
              ${activeTab === tab ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
          >
            {tab === "all" ? "All" : tab.charAt(0).toUpperCase() + tab.slice(1) + "s"}
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-6">
        <input
          data-testid="input-location"
          type="text"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          placeholder="Filter by location..."
          className="border border-input rounded-lg px-3 py-2 text-sm bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring w-48"
        />
        <label className="flex items-center gap-2 text-sm text-muted-foreground cursor-pointer">
          <input
            data-testid="checkbox-remote"
            type="checkbox"
            checked={remoteOnly}
            onChange={(e) => setRemoteOnly(e.target.checked)}
            className="rounded border-input"
          />
          Remote only
        </label>
      </div>

      {/* Job listings */}
      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => <Skeleton key={i} className="h-32 rounded-xl" />)}
        </div>
      ) : jobRecords.length > 0 ? (
        <div className="space-y-3">
          {jobRecords.map((job) => (
            <Card data-testid={`card-job-${job.id}`} key={job.id} className="border-card-border hover:shadow-sm hover:border-primary/30 transition-all">
              <CardContent className="p-5">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <h3 className="font-semibold text-foreground">{job.title}</h3>
                      <Badge variant="secondary" className={`text-xs ${job.type === "internship" ? "bg-blue-100 text-blue-700" : job.type === "freelance" ? "bg-purple-100 text-purple-700" : "bg-green-100 text-green-700"}`}>
                        {job.type.charAt(0).toUpperCase() + job.type.slice(1)}
                      </Badge>
                      {job.remote && <Badge variant="secondary" className="text-xs bg-indigo-100 text-indigo-700">Remote</Badge>}
                    </div>
                    <div className="text-sm text-muted-foreground">{job.company} · {job.location}</div>
                    {job.stipend && <div className="text-sm font-medium text-primary mt-1">{job.stipend}</div>}
                    <p className="text-sm text-muted-foreground mt-2 leading-relaxed line-clamp-2">{job.description}</p>
                    <div className="text-xs text-muted-foreground mt-2">
                      <span className="font-medium">Eligibility:</span> {job.eligibility}
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2 shrink-0">
                    <div className={`text-xs font-semibold flex items-center gap-1 ${trustColor(job.trustScore ?? 80)}`}>
                      <span>Trust</span>
                      <span className="font-bold">{job.trustScore}%</span>
                    </div>
                    {job.deadline && (
                      <div className="text-xs text-muted-foreground">Deadline: {job.deadline}</div>
                    )}
                    {job.applyUrl && (
                      <a
                        href={job.applyUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        data-testid={`button-apply-${job.id}`}
                        className="text-xs bg-primary text-primary-foreground px-3 py-1.5 rounded-lg font-medium hover:bg-primary/90 transition-colors"
                      >
                        Apply
                      </a>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-16 text-muted-foreground">
          <div className="text-4xl mb-3">⊠</div>
          <p className="font-medium">No listings found</p>
          <p className="text-sm mt-1">Try adjusting your filters</p>
        </div>
      )}
    </div>
  );
}
