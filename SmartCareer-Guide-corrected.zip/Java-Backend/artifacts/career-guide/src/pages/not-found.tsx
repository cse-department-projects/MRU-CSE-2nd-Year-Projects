import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="min-h-full flex flex-col items-center justify-center py-24 px-6 text-center">
      <div className="text-6xl text-muted-foreground/30 font-bold mb-4">404</div>
      <h1 className="text-xl font-semibold text-foreground mb-2">Page not found</h1>
      <p className="text-sm text-muted-foreground mb-8">This page doesn't exist. Let's get you back on track.</p>
      <Link href="/">
        <button className="bg-primary text-primary-foreground px-6 py-2.5 rounded-lg font-medium hover:bg-primary/90 transition-colors">
          Go Home
        </button>
      </Link>
    </div>
  );
}
