import { useState } from "react";
import { useProfile, CLASSES, STREAMS_BY_CLASS, DISTRICTS } from "@/context/ProfileContext";

const STEPS = ["Welcome", "Your Class", "Your Stream", "Your Location"];

export default function OnboardingPage({ onComplete }: { onComplete: () => void }) {
  const { updateProfile } = useProfile();
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [currentClass, setCurrentClass] = useState("");
  const [stream, setStream] = useState("");
  const [district, setDistrict] = useState("");

  const streams = currentClass ? STREAMS_BY_CLASS[currentClass] ?? [] : [];

  const canNext = () => {
    if (step === 0) return name.trim().length >= 2;
    if (step === 1) return !!currentClass;
    if (step === 2) return !!stream;
    if (step === 3) return !!district;
    return false;
  };

  const handleNext = () => {
    if (step < STEPS.length - 1) {
      if (step === 1) setStream(""); // reset stream when class changes
      setStep((s) => s + 1);
    } else {
      updateProfile({ name, currentClass, stream, district, completed: true });
      onComplete();
    }
  };

  const progress = ((step) / (STEPS.length - 1)) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        {/* Brand */}
        <div className="flex items-center gap-2 mb-8 justify-center">
          <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center text-primary-foreground font-bold text-sm">
            SC
          </div>
          <span className="font-bold text-foreground text-lg">SmartCareer Guide</span>
        </div>

        {/* Card */}
        <div className="bg-card border border-card-border rounded-2xl shadow-sm overflow-hidden">
          {/* Progress bar */}
          <div className="h-1.5 bg-muted">
            <div
              className="h-full bg-primary transition-all duration-500 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>

          <div className="p-7">
            {/* Step indicator */}
            <div className="flex items-center gap-1.5 mb-6">
              {STEPS.map((s, i) => (
                <div key={s} className="flex items-center gap-1.5">
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-colors
                      ${i < step ? "bg-primary text-primary-foreground" : i === step ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
                  >
                    {i < step ? "✓" : i + 1}
                  </div>
                  {i < STEPS.length - 1 && (
                    <div className={`h-0.5 w-6 rounded ${i < step ? "bg-primary" : "bg-muted"}`} />
                  )}
                </div>
              ))}
            </div>

            {/* Step 0: Name */}
            {step === 0 && (
              <div>
                <h1 className="text-2xl font-bold text-foreground mb-1">Welcome</h1>
                <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
                  Let's set up your profile so we can show you the most relevant careers, scholarships, and opportunities.
                </p>
                <label className="block text-sm font-medium text-foreground mb-2">What's your name?</label>
                <input
                  data-testid="input-name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && canNext() && handleNext()}
                  placeholder="Enter your name"
                  autoFocus
                  className="w-full border border-input rounded-xl px-4 py-3 text-sm bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                />
              </div>
            )}

            {/* Step 1: Class */}
            {step === 1 && (
              <div>
                <h1 className="text-2xl font-bold text-foreground mb-1">Hi, {name}.</h1>
                <p className="text-sm text-muted-foreground mb-5">Which class or level are you currently in?</p>
                <div className="space-y-2">
                  {CLASSES.map((cls) => (
                    <button
                      key={cls}
                      data-testid={`option-class-${cls}`}
                      onClick={() => setCurrentClass(cls)}
                      className={`w-full text-left px-4 py-3 rounded-xl border text-sm font-medium transition-all
                        ${currentClass === cls
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border bg-background text-foreground hover:border-primary/40 hover:bg-muted/50"
                        }`}
                    >
                      {cls}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Step 2: Stream */}
            {step === 2 && (
              <div>
                <h1 className="text-2xl font-bold text-foreground mb-1">Your stream</h1>
                <p className="text-sm text-muted-foreground mb-5">
                  Which stream or field are you studying?
                </p>
                {streams.length > 0 ? (
                  <div className="space-y-2">
                    {streams.map((s) => (
                      <button
                        key={s}
                        data-testid={`option-stream-${s}`}
                        onClick={() => setStream(s)}
                        className={`w-full text-left px-4 py-3 rounded-xl border text-sm font-medium transition-all
                          ${stream === s
                            ? "border-primary bg-primary/10 text-primary"
                            : "border-border bg-background text-foreground hover:border-primary/40 hover:bg-muted/50"
                          }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">No streams available for this class.</p>
                )}
              </div>
            )}

            {/* Step 3: District */}
            {step === 3 && (
              <div>
                <h1 className="text-2xl font-bold text-foreground mb-1">Where are you from?</h1>
                <p className="text-sm text-muted-foreground mb-5">
                  This helps us show relevant local opportunities and scholarships.
                </p>
                <div className="grid grid-cols-2 gap-2">
                  {DISTRICTS.map((d) => (
                    <button
                      key={d}
                      data-testid={`option-district-${d}`}
                      onClick={() => setDistrict(d)}
                      className={`text-left px-3 py-2.5 rounded-xl border text-sm font-medium transition-all
                        ${district === d
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border bg-background text-foreground hover:border-primary/40 hover:bg-muted/50"
                        }`}
                    >
                      {d}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Navigation */}
            <div className="flex items-center justify-between mt-7">
              {step > 0 ? (
                <button
                  onClick={() => setStep((s) => s - 1)}
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  ← Back
                </button>
              ) : (
                <div />
              )}
              <button
                data-testid="button-next"
                onClick={handleNext}
                disabled={!canNext()}
                className="bg-primary text-primary-foreground px-6 py-2.5 rounded-xl font-semibold text-sm hover:bg-primary/90 transition-colors disabled:opacity-40"
              >
                {step === STEPS.length - 1 ? "Start Exploring →" : "Next →"}
              </button>
            </div>
          </div>
        </div>

        <p className="text-center text-xs text-muted-foreground mt-4">
          Your profile is saved on this device only. No account needed.
        </p>
      </div>
    </div>
  );
}
