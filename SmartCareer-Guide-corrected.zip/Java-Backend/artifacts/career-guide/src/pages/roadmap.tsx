import { useState } from "react";
import { useRoute, Link } from "wouter";
import { useGetRoadmap, getGetRoadmapQueryKey } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useProfile } from "@/context/ProfileContext";

export default function RoadmapPage() {
  const [, params] = useRoute("/roadmap/:careerId");
  const careerId = parseInt(params?.careerId ?? "1", 10);
  const [openPhase, setOpenPhase] = useState<number | null>(0);
  const [openStep, setOpenStep] = useState<number | null>(null);
  const { profile, toggleRoadmapStep } = useProfile();

  const { data: roadmap, isLoading, isError, refetch } = useGetRoadmap(careerId, {
    query: { enabled: !!careerId, queryKey: getGetRoadmapQueryKey(careerId) },
  });

  if (isLoading) {
    return (
      <div className="p-6 lg:p-12 max-w-3xl">
        <Skeleton className="h-8 w-64 mb-4" />
        {[1, 2, 3].map((i) => <Skeleton key={i} className="h-24 mb-4 rounded-xl" />)}
      </div>
    );
  }

  if (!roadmap) {
    return (
      <div className="p-6 text-center py-20">
        <p className="text-muted-foreground">{isError ? "Roadmap could not be loaded." : "Roadmap not found."}</p>
        {isError && <button onClick={() => refetch()} className="mt-3 text-primary underline">Try again</button>}
        <Link href="/careers" className="mt-4 inline-block text-primary hover:underline">Browse Careers</Link>
      </div>
    );
  }

  const difficultyColor = (d?: string | null) => {
    if (d === "beginner") return "bg-green-100 text-green-700";
    if (d === "intermediate") return "bg-yellow-100 text-yellow-700";
    if (d === "advanced") return "bg-red-100 text-red-700";
    return "bg-muted text-muted-foreground";
  };
  const roadmapPhases = Array.isArray((roadmap as any).phases) ? (roadmap as any).phases : [];
  const roadmapItems = roadmapPhases.flatMap((phase: any) =>
    (Array.isArray(phase?.steps) ? phase.steps : []).map((step: any) => `${phase.id}:${step.id}`)
  );
  const completedItems = roadmapItems.filter((stepId) => (profile.roadmapProgress[String(careerId)] ?? []).includes(stepId));
  const completion = roadmapItems.length ? Math.round(completedItems.length / roadmapItems.length * 100) : 0;
  const resume = () => {
    const next = roadmapPhases.findIndex((phase: any) => (Array.isArray(phase?.steps) ? phase.steps : []).some((step: any) => !(profile.roadmapProgress[String(careerId)] ?? []).includes(`${phase.id}:${step.id}`)));
    setOpenPhase(next >= 0 ? next : 0);
  };

  return (
    <div className="p-6 lg:p-12 max-w-3xl">
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
        <Link href="/careers"><span className="hover:text-foreground cursor-pointer">Careers</span></Link>
        <span>/</span>
        <span className="text-foreground font-medium">{roadmap.careerTitle} Roadmap</span>
      </div>

      <div className="mb-8 rounded-2xl border border-primary/15 bg-card p-5">
        <h1 className="text-2xl font-bold text-foreground">{roadmap.careerTitle}</h1>
        <p className="text-muted-foreground mt-1">Step-by-step career roadmap from school to professional growth</p>
        <div className="mt-4 flex flex-wrap items-center gap-3"><div className="h-2 min-w-40 flex-1 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-primary transition-all" style={{ width: `${completion}%` }} /></div><span className="font-mono text-sm font-bold text-primary" aria-live="polite">{completion}% complete</span><button type="button" onClick={resume} className="rounded-lg border border-border px-3 py-2 text-xs font-semibold hover:border-primary/40">Resume next step</button></div>
        <p className="mt-1 text-xs text-muted-foreground">{completedItems.length} of {roadmapItems.length} steps checked off. Progress is saved to your student workspace.</p>
      </div>

      {/* Timeline */}
      <div className="relative">
        <div className="absolute left-5 top-5 bottom-5 w-0.5 bg-border" />

        <div className="space-y-4">
          {roadmapPhases.map((phase: any, phaseIdx: number) => (
            <div key={phase.id} className="relative pl-12">
              {/* Phase indicator */}
              <div className="absolute left-2.5 top-4 w-5 h-5 rounded-full bg-primary border-2 border-background shadow-sm flex items-center justify-center">
                <span className="text-[9px] font-bold text-primary-foreground">{phaseIdx + 1}</span>
              </div>

              <div className="bg-card border border-card-border rounded-xl overflow-hidden">
                <button
                  data-testid={`phase-${phaseIdx}`}
                  onClick={() => setOpenPhase(openPhase === phaseIdx ? null : phaseIdx)}
                  className="w-full text-left px-5 py-4 flex items-center justify-between hover:bg-muted/40 transition-colors"
                >
                  <div>
                    <div className="font-semibold text-foreground">{phase.title}</div>
                    <div className="text-xs text-muted-foreground mt-0.5">{phase.duration} · {phase.steps?.length ?? 0} steps · {phase.steps.filter((step) => (profile.roadmapProgress[String(careerId)] ?? []).includes(`${phase.id}:${step.id}`)).length} complete</div>
                  </div>
                  <span className="text-muted-foreground text-lg">{openPhase === phaseIdx ? "−" : "+"}</span>
                </button>

                {openPhase === phaseIdx && (
                  <div className="border-t border-card-border">
                    {phase.steps?.map((step, stepIdx) => (
                      <div key={step.id} className="border-b border-card-border last:border-b-0">
                        <button
                          data-testid={`step-${phaseIdx}-${stepIdx}`}
                          onClick={() => setOpenStep(openStep === step.id ? null : step.id)}
                          className="w-full text-left px-5 py-3.5 flex items-start gap-3 hover:bg-muted/30 transition-colors"
                        >
                          <span className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-semibold shrink-0 mt-0.5 ${profile.roadmapProgress[String(careerId)]?.includes(`${phase.id}:${step.id}`) ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                            {profile.roadmapProgress[String(careerId)]?.includes(`${phase.id}:${step.id}`) ? "✓" : stepIdx + 1}
                          </span>
                          <div className="flex-1 min-w-0">
                            <div className="font-medium text-sm text-foreground">{step.title}</div>
                            <div className="flex items-center gap-2 mt-1 flex-wrap">
                              {step.difficulty && (
                                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${difficultyColor(step.difficulty)}`}>
                                  {step.difficulty}
                                </span>
                              )}
                              {step.estimatedHours && step.estimatedHours > 0 && (
                                <span className="text-xs text-muted-foreground">{step.estimatedHours}h</span>
                              )}
                            </div>
                          </div>
                          <span className="text-muted-foreground text-sm">{openStep === step.id ? "−" : "+"}</span>
                        </button>
                        <label className="mx-5 mb-3 flex cursor-pointer items-center gap-2 text-xs font-semibold text-primary">
                          <input type="checkbox" checked={profile.roadmapProgress[String(careerId)]?.includes(`${phase.id}:${step.id}`) ?? false} onChange={() => toggleRoadmapStep(careerId, `${phase.id}:${step.id}`)} aria-label={`${profile.roadmapProgress[String(careerId)]?.includes(`${phase.id}:${step.id}`) ? "Mark incomplete" : "Mark complete"}: ${step.title}`} />
                          Mark step complete
                        </label>

                        {openStep === step.id && (
                          <div className="px-5 pb-4 pl-13 ml-8">
                            <p className="text-sm text-muted-foreground leading-relaxed mb-3">{step.description}</p>
                            {step.resourceLinks && step.resourceLinks.length > 0 && (
                              <div>
                                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Resources</div>
                                <div className="flex flex-wrap gap-2">
                                  {step.resourceLinks.map((link, li) => (
                                    <a
                                      key={li}
                                      href={link}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="text-xs text-primary border border-primary/30 bg-primary/5 px-3 py-1 rounded-full hover:bg-primary/10 transition-colors"
                                    >
                                      {link.replace("https://", "").split("/")[0]}
                                    </a>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
