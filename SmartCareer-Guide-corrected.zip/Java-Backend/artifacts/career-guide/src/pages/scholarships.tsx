import { useMemo, useState } from "react";
import { ExternalLink } from "lucide-react";
import { useListScholarships, getListScholarshipsQueryKey } from "@workspace/api-client-react";
import { useProfile } from "@/context/ProfileContext";
import { Skeleton } from "@/components/ui/skeleton";

const CATEGORIES = ["All", "SC", "ST", "BC", "OBC", "EWS", "General"];
const LEVELS = ["All", "10th", "12th", "UG", "PG", "Diploma"];
function deadlineState(deadline?: string | null) {
  if (!deadline) return "unknown";
  const parsed = new Date(deadline);
  if (!Number.isFinite(parsed.getTime())) return "unknown";
  return parsed.getTime() < new Date(new Date().toDateString()).getTime() ? "expired" : "open";
}
function levelForClass(currentClass: string) {
  if (/10th|Class 10/i.test(currentClass)) return "10th";
  if (/12th|Class 11|Class 12|Inter/i.test(currentClass)) return "12th";
  if (/Diploma/i.test(currentClass)) return "Diploma";
  if (/Post Graduate|PG/i.test(currentClass)) return "PG";
  if (/Degree|College|UG/i.test(currentClass)) return "UG";
  return "";
}
export default function ScholarshipsPage() {
  const { profile } = useProfile();
  const [category, setCategory] = useState("All");
  const [level, setLevel] = useState("All");
  const [stateFilter, setStateFilter] = useState(profile.district && profile.district !== "Outside Telangana" ? "Telangana" : "All");
  const params = {
    category: category !== "All" ? category : undefined,
    level: level !== "All" ? level : undefined,
    state: stateFilter === "Telangana" ? "Telangana" : undefined,
  };
  const query = useListScholarships(params, { query: { queryKey: getListScholarshipsQueryKey(params) } });
  const profileLevel = levelForClass(profile.currentClass);
  const scholarships = useMemo(() => (query.data ?? []).slice().sort((a, b) => {
    const levelScore = (item: typeof a) => item.level.some((entry) => entry.toLowerCase() === profileLevel.toLowerCase()) ? 1 : 0;
    const suitableDelta = levelScore(b) - levelScore(a);
    if (suitableDelta) return suitableDelta;
    const score = (item: typeof a) => deadlineState(item.deadline) === "open" ? 0 : deadlineState(item.deadline) === "unknown" ? 1 : 2;
    return score(a) - score(b);
  }), [query.data, profileLevel]);
  return <main className="mx-auto max-w-5xl px-4 py-6 sm:px-6 lg:px-10 lg:py-9">
    <header className="mb-7"><p className="text-xs font-bold uppercase tracking-[.16em] text-primary">Funding options · verified source records</p><h1 className="mt-2 text-3xl font-semibold sm:text-4xl">Scholarships & funding</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">Check eligibility and application dates before applying. If a deadline is missing, it is labelled as not announced rather than guessed.</p></header>
    <section aria-label="Scholarship filters" className="mb-6 rounded-2xl border border-border bg-card p-4">
      <div className="grid gap-4"><FilterGroup title="Category" values={CATEGORIES} selected={category} onSelect={setCategory} /><FilterGroup title="Education level" values={LEVELS} selected={level} onSelect={setLevel} /><FilterGroup title="State" values={["All", "Telangana"]} selected={stateFilter} onSelect={setStateFilter} /></div>
    </section>
    {query.isLoading ? <div className="space-y-3" aria-label="Loading scholarships">{[1, 2, 3].map((index) => <Skeleton key={index} className="h-40 rounded-2xl" />)}</div> : query.isError ? <section role="alert" className="rounded-2xl border border-destructive/30 bg-card p-6"><h2 className="font-semibold">Scholarship records could not be loaded</h2><p className="mt-1 text-sm text-muted-foreground">Your local profile is still available. Try loading these opportunities again.</p><button onClick={() => query.refetch()} className="mt-3 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">Retry</button></section> : scholarships.length ? <div className="space-y-3">{scholarships.map((scholarship) => {
      const state = deadlineState(scholarship.deadline);
      const stateText = state === "expired" ? "Deadline passed" : state === "open" ? "In-date deadline" : "Deadline not announced";
      return <article key={scholarship.id} data-testid={`card-scholarship-${scholarship.id}`} className="rounded-2xl border border-border bg-card p-5 transition-colors hover:border-primary/35">
        <div className="flex flex-col justify-between gap-4 sm:flex-row"><div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><h2 className="text-lg font-semibold">{scholarship.name}</h2>{scholarship.state && <span className="rounded-full bg-accent px-2.5 py-1 text-xs font-semibold text-accent-foreground">{scholarship.state}</span>}</div><p className="mt-1 text-sm text-muted-foreground">{scholarship.provider}</p><p className="mt-2 text-base font-bold text-primary">{scholarship.amount}</p><p className="mt-2 text-sm leading-6 text-muted-foreground">{scholarship.description}</p></div><div className="sm:min-w-44 sm:text-right"><span className={`inline-flex rounded-full px-3 py-1 text-xs font-bold ${state === "open" ? "bg-primary/10 text-primary" : state === "expired" ? "bg-destructive/10 text-destructive" : "bg-muted text-muted-foreground"}`}>{stateText}</span><p className="mt-2 text-sm font-medium">{scholarship.deadline ?? "Not announced by source"}</p>{scholarship.deadlineNote && <p className="mt-1 text-xs leading-5 text-muted-foreground">{scholarship.deadlineNote}</p>}</div></div>
        {scholarship.eligibility && <div className="mt-4 rounded-xl bg-muted/45 p-3"><span className="block text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Eligibility</span><p className="mt-1 text-sm leading-5">{scholarship.eligibility}</p></div>}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-border pt-3"><div className="flex flex-wrap gap-1.5">{[...(scholarship.categories ?? []), ...(scholarship.level ?? [])].map((label) => <span key={label} className="rounded-full border border-border px-2.5 py-1 text-xs text-muted-foreground">{label}</span>)}</div>{scholarship.applyUrl && <a href={scholarship.applyUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-lg bg-primary px-3 py-2 text-xs font-semibold text-primary-foreground">Official application <ExternalLink className="h-3.5 w-3.5" /></a>}</div>
      </article>;
    })}</div> : <section className="rounded-2xl border border-dashed border-border p-10 text-center"><h2 className="font-semibold">No scholarships match these filters</h2><p className="mt-1 text-sm text-muted-foreground">Try a broader category, education level or state. We do not add placeholder opportunities.</p></section>}
  </main>;
}
function FilterGroup({ title, values, selected, onSelect }: { title: string; values: string[]; selected: string; onSelect: (value: string) => void }) {
  return <div><h2 className="mb-2 text-[10px] font-bold uppercase tracking-[.14em] text-muted-foreground">{title}</h2><div className="flex flex-wrap gap-2">{values.map((value) => <button key={value} type="button" aria-pressed={selected === value} onClick={() => onSelect(value)} className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors ${selected === value ? "border-primary bg-primary text-primary-foreground" : "border-border bg-background text-muted-foreground hover:border-primary/40"}`}>{value}</button>)}</div></div>;
}
