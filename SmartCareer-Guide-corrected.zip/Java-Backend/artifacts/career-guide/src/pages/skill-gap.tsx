import { useMemo, useState } from "react";
import { Link } from "wouter";
import { ArrowUpRight, Check, Circle, Target } from "lucide-react";
import { getListCareersQueryKey, getListCoursesQueryKey, useListCareers, useListCourses } from "@workspace/api-client-react";
import { useProfile, streamToApiFilter } from "@/context/ProfileContext";
import { Skeleton } from "@/components/ui/skeleton";

export default function SkillGapPage() {
  const { profile, toggleSkillGapItem } = useProfile();
  const [careerId, setCareerId] = useState<number | null>(null);
  const params = { stream: streamToApiFilter(profile.stream) };
  const careersQuery = useListCareers(params, { query: { queryKey: getListCareersQueryKey(params) } });
  const careerResponse = careersQuery.data;
  const careers: any[] = Array.isArray(careerResponse)
    ? careerResponse
    : Array.isArray((careerResponse as any)?.data)
      ? (careerResponse as any).data
      : [];
  const chosenId = careerId ?? careers[0]?.id ?? 0;
  const career = careers.find((item) => item.id === chosenId);
  const courseParams = { careerId: chosenId || undefined };
  const coursesQuery = useListCourses(courseParams, { query: { queryKey: getListCoursesQueryKey(courseParams), enabled: !!chosenId } });
  const required = career?.skills ?? [];
  const known = useMemo(() => new Set<string>([...profile.skills, ...profile.practicedSkills].map((skill: string) => skill.toLowerCase())), [profile.skills, profile.practicedSkills]);
  const missing = required.filter((skill: string) => !known.has(skill.toLowerCase()));
  const completed = profile.skillGapProgress[String(chosenId)] ?? [];
  const checkedCount = missing.filter((skill) => completed.includes(`skill:${skill}`)).length;
  const progress = missing.length ? Math.round(checkedCount / missing.length * 100) : required.length ? 100 : 0;
  const ideas = missing.slice(0, 4).map((skill) => ({ id: `project:${skill}`, skill, idea: `Create a small ${skill.toLowerCase()} demonstration: define one real problem, make a first version, and write a short note on what you learned.` }));
  return <main className="mx-auto max-w-5xl px-4 py-6 sm:px-6 lg:px-10 lg:py-9">
    <header className="mb-7"><p className="text-xs font-bold uppercase tracking-[.16em] text-primary">Skills to build next</p><h1 className="mt-2 text-3xl font-semibold sm:text-4xl">See the gap. Make a plan.</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">Compare the skills saved to your profile with a career's listed requirements. Checkoffs are your own progress notes.</p></header>
    <section className="mb-6 rounded-2xl border border-border bg-card p-4 sm:flex sm:items-end sm:justify-between sm:gap-5"><label className="block flex-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Choose a career<select aria-label="Choose a career" value={chosenId || ""} onChange={(event) => setCareerId(Number(event.target.value))} className="mt-1.5 h-11 w-full rounded-lg border border-input bg-background px-3 text-sm font-medium text-foreground" disabled={!careers.length}><option value="" disabled>{careersQuery.isLoading ? "Loading careers..." : "Select a career"}</option>{careers.map((item) => <option key={item.id} value={item.id}>{item.title}</option>)}</select></label>{career && <Link href={`/roadmap/${career.id}`} className="mt-3 inline-flex rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground sm:mt-0">Open career roadmap</Link>}</section>
    {careersQuery.isLoading ? <div className="space-y-3"><Skeleton className="h-24" /><Skeleton className="h-48" /></div> : careersQuery.isError ? <div role="alert" className="rounded-xl border border-destructive/30 p-5">Career requirements could not be loaded. <button onClick={() => careersQuery.refetch()} className="font-semibold text-primary underline">Retry</button></div> : !career ? <div className="rounded-2xl border border-dashed border-border p-8 text-center"><h2 className="font-semibold">No career records available</h2><p className="mt-1 text-sm text-muted-foreground">Try browsing all careers or update your profile stream.</p><Link href="/careers" className="mt-3 inline-block text-sm font-semibold text-primary underline">Browse careers</Link></div> : <>
      <section className="mb-6 rounded-2xl border border-primary/15 bg-[linear-gradient(115deg,hsl(var(--primary)/.09),hsl(var(--card))_65%)] p-5 sm:p-7">
        <div className="flex flex-wrap items-start justify-between gap-4"><div><p className="text-xs font-bold uppercase tracking-wider text-primary">{career.cluster}</p><h2 className="mt-1 text-2xl font-semibold">{career.title}</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">{career.description}</p></div><div className="rounded-xl border border-border bg-card px-4 py-3 text-center"><div className="font-mono text-2xl font-bold text-primary">{progress}%</div><div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">gap check-ins</div></div></div>
        <div className="mt-5 h-2 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-primary transition-all" style={{ width: `${progress}%` }} /></div>
      </section>
      <div className="grid gap-5 lg:grid-cols-[1.1fr_.9fr]">
        <section className="rounded-2xl border border-border bg-card p-5"><div className="mb-4 flex items-center justify-between gap-3"><div><h2 className="text-lg font-semibold">Requirements to build</h2><p className="mt-1 text-xs text-muted-foreground">Based on career skills and your saved profile.</p></div><Target className="h-5 w-5 text-primary" /></div>{required.length ? <div className="space-y-2">{required.map((skill) => {
          const alreadyHave = known.has(skill.toLowerCase());
          const id = `skill:${skill}`;
          const done = alreadyHave || completed.includes(id);
          return <button key={skill} type="button" aria-pressed={done} onClick={() => !alreadyHave && toggleSkillGapItem(chosenId, id)} disabled={alreadyHave} className={`flex w-full items-center gap-3 rounded-xl border p-3 text-left ${done ? "border-primary/30 bg-primary/5" : "border-border hover:border-primary/40"}`}><span className={`grid h-5 w-5 place-items-center rounded-full border ${done ? "border-primary bg-primary text-primary-foreground" : "border-muted-foreground/40"}`}>{done ? <Check className="h-3 w-3" /> : <Circle className="h-2.5 w-2.5 text-transparent" />}</span><span className="flex-1 text-sm font-medium">{skill}</span><span className="text-xs text-muted-foreground">{alreadyHave ? "In your profile" : done ? "Practised" : "Mark practised"}</span></button>;
        })}</div> : <p className="rounded-xl border border-dashed border-border p-4 text-sm text-muted-foreground">This career record does not list required skills yet.</p>}</section>
        <section className="rounded-2xl border border-border bg-card p-5"><h2 className="text-lg font-semibold">Returned courses</h2><p className="mb-4 mt-1 text-xs text-muted-foreground">Course records linked to this career.</p>{coursesQuery.isLoading ? <div className="space-y-2"><Skeleton className="h-16" /><Skeleton className="h-16" /></div> : coursesQuery.isError ? <div className="text-sm text-muted-foreground">Related courses are unavailable. <button onClick={() => coursesQuery.refetch()} className="font-semibold text-primary underline">Retry</button></div> : coursesQuery.data?.length ? <div className="space-y-2">{coursesQuery.data.slice(0, 6).map((course) => <article key={course.id} className="rounded-xl border border-border p-3"><h3 className="text-sm font-semibold">{course.title}</h3><p className="mt-1 text-xs text-muted-foreground">{course.provider} · {course.duration} · {course.cost}</p>{course.url && <a href={course.url} target="_blank" rel="noreferrer" className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-primary">View course <ArrowUpRight className="h-3.5 w-3.5" /></a>}</article>)}</div> : <p className="rounded-xl border border-dashed border-border p-4 text-sm text-muted-foreground">No course records are currently linked to this career.</p>}</section>
      </div>
      <section className="mt-5 rounded-2xl border border-border bg-card p-5"><h2 className="text-lg font-semibold">Project ideas to make progress visible</h2><p className="mb-4 mt-1 text-xs text-muted-foreground">Suggested activities from the listed skills, not external course records.</p>{ideas.length ? <div className="grid gap-3 md:grid-cols-2">{ideas.map((item: { id: string; skill: string; idea: string }) => { const done = completed.includes(item.id); return <button key={item.id} onClick={() => toggleSkillGapItem(chosenId, item.id)} aria-pressed={done} className={`rounded-xl border p-4 text-left ${done ? "border-primary/30 bg-primary/5" : "border-border hover:border-primary/40"}`}><span className="flex items-center justify-between gap-2"><span className="text-xs font-bold uppercase tracking-wide text-primary">{item.skill}</span><span className="text-xs font-semibold text-muted-foreground">{done ? "Done" : "Mark complete"}</span></span><span className="mt-2 block text-sm leading-5 text-foreground">{item.idea}</span></button>; })}</div> : <p className="text-sm text-muted-foreground">Project ideas will appear when this career has unpractised listed skills.</p>}</section>
    </>}
  </main>;
}
